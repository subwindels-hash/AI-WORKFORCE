# Sports Intelligence providers

Sports Intelligence can use API-Football, TheSportsDB, and SportMonks directly. Configure credentials only in the server environment; never put them in browser JavaScript or a committed `.env` file.

## Configuration

```env
WINDELS_SPORTS_ENABLED=1
WINDELS_SPORTS_MODE=PRODUCTION
WINDELS_SPORTS_HTTP_TIMEOUT=10

WINDELS_API_FOOTBALL_KEY=...
WINDELS_API_FOOTBALL_BASE_URL=https://v3.football.api-sports.io

WINDELS_THESPORTSDB_KEY=123
WINDELS_THESPORTSDB_BASE_URL=https://www.thesportsdb.com/api/v1/json

WINDELS_SPORTMONKS_TOKEN=...
WINDELS_SPORTMONKS_BASE_URL=https://api.sportmonks.com/v3/football
```

A provider is registered only when its credential exists. Multiple configured providers are retained in registration order and the provider manager falls back to the next provider after authentication, rate-limit, quota, network, or upstream data failures. Provider status is available through `GET /api_sports/providers` and the Sports Intelligence status endpoint; both carry a `readiness` block (`operational`, `total`, `engine`) — see *Provider health, circuit breaker and DATA_UNAVAILABLE* below.

## Capabilities

| Provider | Fixtures | Results | Odds | Top players |
|---|---:|---:|---:|---:|
| API-Football | Yes | Yes | Yes, via the odds endpoint | Yes (scorers / assists / yellow cards / red cards) |
| TheSportsDB | Yes | Yes | No bookmaker odds endpoint | No |
| SportMonks | Yes (incl. full-round bulk fetch) | Yes | Yes, per fixture and per round (odds add-on) | No |

All upstream responses are converted to the internal fixture, odds, and result shapes before they reach the normalizers and persistence layer. The provider adapters do not expose credentials to the frontend.

## API-Football notes

API-Football uses the `x-apisports-key` header. Its odds response is flattened into the internal market/selection/decimalOdds shape. The provider's plan and quota determine which leagues and odds markets are available.

**Pagination:** every v3 list response carries `paging: {current, total}`, but
only some endpoints actually paginate — `/players` at 20 rows/page and `/odds`
at 10 rows/page take a `page` parameter, while `/fixtures` (a whole day or a
whole season in one response) and `/leagues` return everything and reject an
explicit `page` with HTTP 200 and
`errors: {"page": "The Page field do not exist."}`.

`fetchAllPages()` therefore omits `page` on the first request (page 1 is the
provider default), sends `page=N` from 2 upwards only while
`paging.current < paging.total` (hard cap: 40 pages), and — if a follow-up page
is refused because the endpoint does not accept the parameter — keeps the rows
already fetched and records the truncation in `paginationNotes()` (also
reported by `health()` and by the live smoke test) instead of throwing the whole
pull away. Any other provider error still propagates.

> **History:** sending `page=1` on the first request made every non-paginated
> endpoint fail — `fixtures()` for a calendar day and `leagues()` both answered
> "The Page field do not exist.", the sync stored nothing and the dashboard
> reported `Sync pulled nothing.`

`ApiFootballProvider::topPlayers(leagueId, season, type)` wraps the four
top-player endpoints of the Players tag
(`/players/topscorers`, `/players/topassists`, `/players/topyellowcards`,
`/players/topredcards`). `league` and `season` are required upstream; the
response is normalized to ranked entries (`rank`, `playerId`, `name`,
`position`, `nationality`, `team`, `teamId`, `photo`) plus `value` — the
headline number for the ranked metric — and the full per-season `statistics`
profile as a keyed map. Unsupported `type` values throw instead of guessing a
path.

Exposed to the API as
`GET /api/sports/topplayers?league=61&season=2020&type=yellow_cards`
(`sports.view`). `provider` is optional — when omitted, the first configured
provider with top-player support serves the request (health-aware fallback),
and the response reports which provider answered. Results are cached per
(provider, league, season, type) for 15 minutes to protect the provider's
daily request quota (`?cache=0` bypasses).

## TheSportsDB notes

TheSportsDB uses the numeric key as part of the URL path (`/api/v1/json/{key}/...`). The adapter uses the soccer events-by-day endpoint and maps `idEvent`, `strHomeTeam`, `strAwayTeam`, `strLeague`, and `dateEvent`.

`searchTeams(name)` wraps `searchteams.php` (the endpoint from the
official API examples) and returns the internal team shape including the
vendor's `idAPIfootball` cross-reference. All TheSportsDB events also carry
`idAPIfootball`; the mappers surface it as `apiFootballId` on fixtures and
results so the same match/team can be matched across api-football and
TheSportsDB.

**Free key:** the documented free/test key is `123`. The old key `3` was
retired and the v1 endpoints now answer **HTTP 400** for it — that is what
produced `thesportsdb: HTTP 400` in the daily-ticket log. The adapter
normalises `1`/`2`/`3` (and an empty key) to `123`, and normalises a base URL that already
contains the key segment (`.../api/v1/json/3`) or points at the premium-only
v2 root back to `https://www.thesportsdb.com/api/v1/json`. Free tier is
limited to 30 requests/minute (HTTP 429 → `RATE_LIMITED`).

**Free tier limits, verified live:** list endpoints are capped —
`all_leagues.php` returns 5 leagues, `eventsday.php` a partial day, and
`eventsseason.php` a partial season. The adapter never fabricates the
missing rows; treat free-tier syncs as a sample of the day. v2 (livescore,
full seasons) requires a premium key.

## SportMonks notes

SportMonks uses the token query parameter (`api_token`) and the Football
API **v3** endpoints. Fixtures use participants, scores, and league
includes, and are mapped using participant location (`home`/`away`).
Ensure the token has access to the leagues and includes used by the
deployment.

> **v3 gotcha (audited against the official v3 docs, 2026-09):** the v2-era
> query parameters are **silently ignored** by the v3 API — a v2-style
> `filter[starts_between:...]` on `/fixtures` returns the API's oldest
> fixtures unfiltered, and a top-level `leagues=`/`season=` parameter
> filters nothing. All SportMonks requests below use the documented v3
> surface; do not "restore" the old parameter style.

### Date endpoints and filters (fixtures)

`SportMonksProvider::fixtures(['from' => 'Y-m-d', 'to' => 'Y-m-d',
'league' => id, 'season' => id])` maps to the v3 date endpoints:

- single day → `GET /fixtures/date/{date}`
- range → `GET /fixtures/between/{start}/{end}` (**max 100 days** — wider
  windows throw a `ProviderException` instead of hitting a limit the API
  enforces)
- league scope → `&filters=fixtureLeagues:{id}`
- season scope → `&filters=fixtureSeasons:{id}`

### Pagination

`SportMonksProvider::fixtures()` follows the v3 cursor pagination of the
date endpoints above (they default to 25 fixtures per page): the first
request sets `per_page=50`, subsequent requests pass `next_cursor` until
`has_more` is false, with a hard cap of 40 pages (2000 fixtures) so a
busy multi-league day is never silently truncated to the first page. The
round, standings and lineups endpoints do not paginate.

### Standings

`SportMonksProvider::standings($leagueId, $season)` calls
`GET /standings/seasons/{season}?filters=standingLeagues:{id}&include=participant;details`.
The base standing row only carries `position` and `points`; the team name
comes from the `participant` include and W/D/L/goals from the `details`
include (standing-detail type ids: 129 played, 130 won, 131 draw,
132 lost, 133 goals for, 134 conceded).

### Odds

`SportMonksProvider::odds($fixtureId)` calls
`GET /odds/pre-match/fixtures/{id}?include=market;bookmaker` (standard
odds feed — requires the odds add-on; failures degrade to an empty
array). The v2-era standalone path `/odds/fixtures/{id}` **does not
exist** in v3 (verified live: "The requested endpoint does not exist").
Round-embedded odds come from the same feed via the `fixtures.odds`
include on `GET /rounds/{id}`.

### Lineups

`SportMonksProvider::lineups($fixtureId)` calls
`GET /fixtures/{id}?include=lineups;participants;lineups.position` — v3
has no `/lineups/...` endpoint, lineups are a fixture include. Each
entry's `type_id` marks the role (11 = starting player, 12 = substitute)
and the nested `lineups.position` include provides the position name.
Failures degrade to an empty array (lineups are optional data).

### Round-based bulk fetch

`SportMonksProvider::round($roundExternalId)` retrieves an entire matchday in **one request** via `GET /rounds/{id}` with nested includes (`fixtures`, `fixtures.odds`, `fixtures.odds.market`, `fixtures.odds.bookmaker`, `fixtures.participants`, `fixtures.scores`, `fixtures.venue`, `fixtures.state`, `league`, `league.country`). It returns:

```php
[
    'roundId' => '396698', 'name' => '25', 'leagueId' => '648', 'league' => 'Serie A',
    'season' => '26763', 'startingAt' => '2026-08-29', 'endingAt' => '2026-08-31',
    'finished' => true,
    'fixtures' => [ /* internal fixture shape */ ],
    'odds'     => [ /* internal odds shape, + impliedProbability/updatedAt/winning when the vendor supplies them */ ],
    'results'  => [ /* internal result shape, from the embedded scores */ ],
]
```

- Round ids are resolved with `SportMonksProvider::seasonRounds($seasonId)` (`GET /rounds/seasons/{id}`).
- Round-embedded odds carry `original_label` (`1`/`Draw`/`2`) or a display `label` instead of a `selection` object; the mapper handles both shapes.
- Fixture status is resolved from the v3 `state` include object, then `state_id` (official v3 state table, e.g. `5` = FT), with the legacy v2 numeric `status` codes as a fallback.
- Consumer pattern through the fallback manager (rounds are a SportMonks-only capability, so guard with `method_exists`):

```php
$attempt = $providers->withFallback('round', function ($p) use ($roundId) {
    if (!method_exists($p, 'round')) throw new ProviderException('round endpoint not supported', ProviderException::DATA_ERROR);
    return $p->round($roundId);
});
```

The daily ticket engine uses this path: when the serving provider exposes
`round()` and the fetched fixtures carry a `roundId`, `DailyTicketService`
bulk-fetches each matchday's odds with one `round()` call per round
(`fetchRoundOdds`) and only falls back to the per-fixture `odds()` call for
fixtures the round fetch did not cover (no `roundId`, or a failed round
request). Odds already persisted for a match are never re-fetched.

### Round sync job

`SportsSyncService::syncRound($provider, $roundExternalId, $executionKey)`
bulk-syncs a whole matchday in one provider request — fixtures, odds and
results are persisted from the single `round()` payload (idempotent per
execution key, job type `ROUND`, audited as `SPORTS_ROUND_SYNC_*`). It is
exposed through the sync endpoint:

```
GET /api/sports/sync?provider=sportmonks&type=round&roundId=396698
```

Providers without a `round()` endpoint fail the job with an explicit
"does not support round sync" error instead of silently no-op'ing.

### Cron odds job on the round path

`sports_matches` stores `round_id` (nullable, indexed on `provider_id,
round_id` — new column added via the idempotent schema upgrade), populated
from the provider fixture payload at sync time. The cron `odds` job groups
the day's active matches by `(provider, round_id)`: every round on a
round-capable provider is synced once via `syncRound(..., ['results' => false])`
(one provider request per matchday, results skipped so verified results are
never re-written), and matches without a `round_id` — or on providers
without the round endpoint — keep the legacy per-fixture `syncOdds` call.

## Provider health, circuit breaker and DATA_UNAVAILABLE

### Why

On 2026-09-05 the daily ticket run reported `NO_QUALIFIED_TICKET` with
`0 matches evaluated`. Nothing was wrong with the prediction engine — every
data feed had failed: API-Football answered `You have reached the request
limit for the day` (and was still being re-called for `odds` / `fixtures`),
TheSportsDB returned HTTP 400 (retired free key `3`), SportMonks and the
generic HTTP provider returned HTTP 404 (wrong base URL). The engine treated
"no data" as "no qualified games". The provider layer now distinguishes the two.

### Provider states

Every adapter classifies each response through `ProviderHttp::classify()`:

| State | Trigger | Circuit behaviour |
|---|---|---|
| `ONLINE` (HEALTHY) | 2xx and usable body | closed |
| `DEGRADED` | partial data / 5xx | counts towards the 3-failure threshold |
| `RATE_LIMITED` | HTTP 429 per-minute throttle, api-football `errors.rateLimit` | opens for `Retry-After` (default 60 s) |
| `DAILY_QUOTA_EXHAUSTED` | api-football `errors.requests` ("request limit for the day"), `x-ratelimit-requests-remaining: 0`, `/status` `requests.current >= limit_day`, or a 429 whose body says the day is used up | **opens immediately until the next 00:00 UTC** — no retries before the vendor reset |
| `AUTHENTICATION_ERROR` (AUTH_FAILED) | HTTP 401/403, api-football `errors.token` | opens for 5 min (configuration error) |
| `BAD_REQUEST` | HTTP 400/422, api-football parameter errors | opens for 5 min (configuration error) |
| `NOT_FOUND` | HTTP 404/410 | opens for 5 min (configuration error) |
| `TIMEOUT` | cURL errno 28 | counts towards threshold |
| `OFFLINE` | no HTTP response (DNS/TLS/connect) | counts towards threshold |

`ProviderCircuitBreaker` (`Sports/Providers/ProviderCircuitBreaker.php`):
3 generic failures → `OPEN` for 10 minutes → `HALF_OPEN` (one probe) →
`CLOSED` on success / `OPEN` again on failure. Terminal states (quota, rate
limit, configuration) open the circuit at once with the state-specific
cooldown above. Circuits are re-hydrated from `sports_provider_health` at
startup, so a cron tick at 09:00 still knows the quota died at 08:40.

`SportsProviderManager::withFallback()` skips an `OPEN` provider **without
any network call** (not even `health()`), probes `health()` before the first
data call otherwise, feeds a non-`ONLINE` self-report to the breaker, and —
when every provider fails — returns
`{ok:false, failureStatuses:{id:STATE}, summary:"fixtures: all 4 provider(s) failed — api-football DAILY_QUOTA_EXHAUSTED, thesportsdb BAD_REQUEST, sportmonks NOT_FOUND, http-provider NOT_FOUND"}`.

### Diagnostics

Every `ProviderException` carries `details` with `method`, `endpoint`
(credential redacted), `query` (secret parameters replaced by `[redacted]`),
`httpStatus` and a 240-character `bodySnippet`. `ProviderHttp::redact()` also
strips bearer tokens, `x-apisports-key` values, TheSportsDB path keys and
32+-character opaque tokens from any free text before it reaches a log, the
audit trail, a flash message or the API. API keys are never logged.

### API-Football quota monitoring

`ApiFootballProvider::health()` calls `GET /status` (free — it does not count
against the quota) and reads `response.requests.current/limit_day` and the
`x-ratelimit-requests-remaining` / `x-ratelimit-requests-limit` headers. It
reports `rateLimitRemaining`, `limitDaily`, the plan, and returns
`DAILY_QUOTA_EXHAUSTED` with `retryAt` = next 00:00 UTC when nothing is left,
so the manager never spends a paid request to discover an empty quota. The
same headers are checked on every data response.

### DATA_UNAVAILABLE

When the fixtures pull fails on all providers the daily ticket engine no
longer evaluates zero matches and reports `NO_QUALIFIED_TICKET`. Instead:

* `DailyTicketService::runDaily()` returns
  `status: DATA_UNAVAILABLE`, `dataState`, `providerStatuses`,
  `rejection_summary["PROVIDER:<id>"]`, `retryable: true`, and releases the
  job run so the next tick can try again.
* `SportsCronService::jobTicket()` checks `readiness()` first; with
  `operational == 0` it emits the `SPORTS_DAILY_TICKET_BLOCKED` audit event
  and returns `DATA_UNAVAILABLE` without touching the engine.
* `POST /api_sports/run_ticket_engine` answers **HTTP 503** with
  `status: DATA_UNAVAILABLE`, `providerStatuses` and `readiness`.
* The dashboard shows `NO TICKET for <date> — STATUS: DATA_UNAVAILABLE` with
  the per-provider reasons, never "no qualified games".

### Dashboard

`GET /api_sports/providers` and the Sports Intelligence page expose
`readiness = {operational, total, engine: READY|BLOCKED|DISABLED_NO_PROVIDER, providers:{id:{status, detail, circuit, retryAt}}}`.
The page header reads **Operational providers: N/4 · Prediction Engine:
READY/BLOCKED**, the data-feed table has a *Circuit* column (state, reason,
retry time, quota usage) and a red banner lists every non-operational
provider with its state and `retryAt`.

## Live smoke test

`php index.php tools sports-live [provider]` proves the configured providers
actually work against the real APIs, layer by layer: health/auth (+ quota
usage) → today's fixtures → odds for the first fixture → top players where
supported. Read-only; costs a handful of requests per provider. Exit codes:
0 all pass, 1 one or more failed, 2 no providers configured. When a provider
"doesn't work", this tells you exactly which layer fails (bad key,
unreachable host, plan restriction) instead of guessing.

## Safe operation

Provider data is untrusted input. The existing normalizers, data-quality gates, confidence checks, and ticket governance remain in the pipeline. Missing odds from providers without an odds feed must not be treated as fabricated odds; those predictions should be rejected or supplied by a separately licensed odds source.
