# Sports Intelligence providers

Sports Intelligence can use API-Football, TheSportsDB, and SportMonks directly. Configure credentials only in the server environment; never put them in browser JavaScript or a committed `.env` file.

## Configuration

```env
WINDELS_SPORTS_ENABLED=1
WINDELS_SPORTS_MODE=PRODUCTION
WINDELS_SPORTS_HTTP_TIMEOUT=10

# Primary variable (API_FOOTBALL_KEY); WINDELS_API_FOOTBALL_KEY is an
# accepted legacy alias — set exactly one.
API_FOOTBALL_KEY=...
API_FOOTBALL_BASE_URL=https://v3.football.api-sports.io
# Legacy alias:
# WINDELS_API_FOOTBALL_KEY=...
# WINDELS_API_FOOTBALL_BASE_URL=https://v3.football.api-sports.io

WINDELS_THESPORTSDB_KEY=123
WINDELS_THESPORTSDB_BASE_URL=https://www.thesportsdb.com/api/v1/json

WINDELS_SPORTMONKS_TOKEN=...
WINDELS_SPORTMONKS_BASE_URL=https://api.sportmonks.com/v3/football
```

A provider is registered only when its credential exists. Multiple configured providers are retained in registration order and the provider manager falls back to the next provider after authentication, rate-limit, quota, network, or upstream data failures. Provider status is available through `GET /api_sports/providers` and the Sports Intelligence status endpoint; both carry a `readiness` block (`operational`, `total`, `engine`) — see *Provider health, circuit breaker and DATA_UNAVAILABLE* below.

## Capabilities

| Provider | Fixtures | Results | Odds | Form source (standings / team stats) | Top players |
|---|---:|---:|---:|---:|---:|
| API-Football | Yes | Yes | Yes, via the odds endpoint | Team statistics + season standings fallback | Yes (scorers / assists / yellow cards / red cards) |
| TheSportsDB | Yes | Yes | No bookmaker odds endpoint | Season table (`lookuptable.php`) | No |
| SportMonks | Yes (incl. full-round bulk fetch) | Yes | Yes, per fixture and per round (odds add-on) | Season standings | No |

All upstream responses are converted to the internal fixture, odds, and result shapes before they reach the normalizers and persistence layer. The provider adapters do not expose credentials to the frontend.

## API-Football notes

API-Football uses the `x-apisports-key` header. Its odds response is flattened into the internal market/selection/decimalOdds shape. The provider's plan and quota determine which leagues and odds markets are available.

**Pagination:** every v3 list response carries `paging: {current, total}`, but
only some endpoints actually paginate — `/players` at 20 rows/page and `/odds`
at 10 rows/page take a `page` parameter, while `/fixtures` (a whole day or a
whole season in one response) and `/leagues` return everything and reject an
explicit `page` with HTTP 200 and
`errors: {"page": "The Page field do not exist."}`.

`fetchAllPages()` therefore omits `page` on the first request (page 1 is the
provider default), sends `page=N` from 2 upwards only while
`paging.current < paging.total` (hard cap: 40 pages), and — if a follow-up page
is refused because the endpoint does not accept the parameter — keeps the rows
already fetched and records the truncation in `paginationNotes()` (also
reported by `health()` and by the live smoke test) instead of throwing the whole
pull away. Any other provider error still propagates.

> **History:** sending `page=1` on the first request made every non-paginated
> endpoint fail — `fixtures()` for a calendar day and `leagues()` both answered
> "The Page field do not exist.", the sync stored nothing and the dashboard
> reported `Sync pulled nothing.`

`ApiFootballProvider::topPlayers(leagueId, season, type)` wraps the four
top-player endpoints of the Players tag
(`/players/topscorers`, `/players/topassists`, `/players/topyellowcards`,
`/players/topredcards`). `league` and `season` are required upstream; the
response is normalized to ranked entries (`rank`, `playerId`, `name`,
`position`, `nationality`, `team`, `teamId`, `photo`) plus `value` — the
headline number for the ranked metric — and the full per-season `statistics`
profile as a keyed map. Unsupported `type` values throw instead of guessing a
path.

Exposed to the API as
`GET /api/sports/topplayers?league=61&season=2020&type=yellow_cards`
(`sports.view`). `provider` is optional — when omitted, the first configured
provider with top-player support serves the request (health-aware fallback),
and the response reports which provider answered. Results are cached per
(provider, league, season, type) for 15 minutes to protect the provider's
daily request quota (`?cache=0` bypasses).

## TheSportsDB notes

TheSportsDB uses the numeric key as part of the URL path (`/api/v1/json/{key}/...`). The adapter uses the soccer events-by-day endpoint and maps `idEvent`, `strHomeTeam`, `strAwayTeam`, `strLeague`, and `dateEvent`.

`searchTeams(name)` wraps `searchteams.php` (the endpoint from the
official API examples) and returns the internal team shape including the
vendor's `idAPIfootball` cross-reference. All TheSportsDB events also carry
`idAPIfootball`; the mappers surface it as `apiFootballId` on fixtures and
results so the same match/team can be matched across api-football and
TheSportsDB.

**Free key:** the documented free/test key is `123`. The old key `3` was
retired and the v1 endpoints now answer **HTTP 400** for it — that is what
produced `thesportsdb: HTTP 400` in the daily-ticket log. The adapter
normalises `1`/`2`/`3` (and an empty key) to `123`, and normalises a base URL that already
contains the key segment (`.../api/v1/json/3`) or points at the premium-only
v2 root back to `https://www.thesportsdb.com/api/v1/json`. Free tier is
limited to 30 requests/minute (HTTP 429 → `RATE_LIMITED`).

`standings($leagueId, $season)` wraps the documented v1 season table
(`lookuptable.php?l={leagueId}&s={season}`) and maps `intPlayed`,
`intGoalsFor` and `intGoalsAgainst` per team. TheSportsDB has no
team-statistics endpoint, so this table is the provider's **only** verified
form source — without it every fixture from a TheSportsDB-only installation
is rejected `INSUFFICIENT_DATA` regardless of odds quality. Rows without an
`idTeam` are dropped rather than guessed.

**Free tier limits, verified live:** list endpoints are capped —
`all_leagues.php` returns 5 leagues, `eventsday.php` a partial day, and
`eventsseason.php` a partial season. The adapter never fabricates the
missing rows; treat free-tier syncs as a sample of the day. Full seasons
require a premium key.

**Live scores (`liveFixtures()` → `GET /livescore.php?d=<today>&s=Soccer`):**
verified live (2026-09) the documented free key `123` DOES get real data back
on v1 — the vendor's own forum posts about "livescore is Patreon-only" refer
to the legacy test keys `1`/`2`, which the endpoint now rejects outright with
HTTP 400 and body `{"Message":"Invalid Premium API key: ..."}`.
`normalizeKey()` maps `1`/`2`/`3`/`123`/empty all onto `123`, so an
installation using any of those legacy aliases is unaffected — but a
genuinely wrong, expired, or revoked key configured through
`WINDELS_THESPORTSDB_KEY` or Admin → API passes through unchanged and hits
this same "Invalid Premium API key" wall, which `ProviderHttp::classify()`
turns into `BAD_REQUEST` and the circuit breaker holds in a config cooldown
until the key is fixed — check the adapter's `bodySnippet` diagnostic (Admin
→ Cron / provider health) for that exact vendor message before assuming the
endpoint itself is broken.

The response body nests rows under **`livescore`**, not `events` like the
day/season/league endpoints — a mismatch here silently returns zero rows
instead of failing, so a `processed: 0` COMPLETED sweep is as suspicious as
an outright error. Each row's in-play minute comes from `strProgress`
(`"57"`, `"90+4"`) rather than `intElapsed`; the adapter parses the base
minute and the stoppage-time remainder (`extraMinute`) out of it. Status
codes on this endpoint are the vendor's own short codes (`1H`, `2H`, `FT`,
…), not the words "LIVE"/"IN PROGRESS" used elsewhere.

## SportMonks notes

SportMonks uses the token query parameter (`api_token`) and the Football
API **v3** endpoints. Fixtures use participants, scores, and league
includes, and are mapped using participant location (`home`/`away`).
Ensure the token has access to the leagues and includes used by the
deployment.

> **v3 gotcha (audited against the official v3 docs, 2026-09):** the v2-era
> query parameters are **silently ignored** by the v3 API — a v2-style
> `filter[starts_between:...]` on `/fixtures` returns the API's oldest
> fixtures unfiltered, and a top-level `leagues=`/`season=` parameter
> filters nothing. All SportMonks requests below use the documented v3
> surface; do not "restore" the old parameter style.

### Date endpoints and filters (fixtures)

`SportMonksProvider::fixtures(['from' => 'Y-m-d', 'to' => 'Y-m-d',
'league' => id, 'season' => id])` maps to the v3 date endpoints:

- single day → `GET /fixtures/date/{date}`
- range → `GET /fixtures/between/{start}/{end}` (**max 100 days** — wider
  windows throw a `ProviderException` instead of hitting a limit the API
  enforces)
- league scope → `&filters=fixtureLeagues:{id}`
- season scope → `&filters=fixtureSeasons:{id}`

### Pagination

`SportMonksProvider::fixtures()` follows the v3 cursor pagination of the
date endpoints above (they default to 25 fixtures per page): the first
request sets `per_page=50`, subsequent requests pass `next_cursor` until
`has_more` is false, with a hard cap of 40 pages (2000 fixtures) so a
busy multi-league day is never silently truncated to the first page. The
round, standings and lineups endpoints do not paginate.

### Standings

`SportMonksProvider::standings($leagueId, $season)` calls
`GET /standings/seasons/{season}?filters=standingLeagues:{id}&include=participant;details`.
The base standing row only carries `position` and `points`; the team name
comes from the `participant` include and W/D/L/goals from the `details`
include (standing-detail type ids: 129 played, 130 won, 131 draw,
132 lost, 133 goals for, 134 conceded).

### Odds

`SportMonksProvider::odds($fixtureId)` calls
`GET /odds/pre-match/fixtures/{id}?include=market;bookmaker` (standard
odds feed — requires the odds add-on; failures degrade to an empty
array). The v2-era standalone path `/odds/fixtures/{id}` **does not
exist** in v3 (verified live: "The requested endpoint does not exist").
Round-embedded odds come from the same feed via the `fixtures.odds`
include on `GET /rounds/{id}`.

### Lineups

`SportMonksProvider::lineups($fixtureId)` calls
`GET /fixtures/{id}?include=lineups;participants;lineups.position` — v3
has no `/lineups/...` endpoint, lineups are a fixture include. Each
entry's `type_id` marks the role (11 = starting player, 12 = substitute)
and the nested `lineups.position` include provides the position name.
Failures degrade to an empty array (lineups are optional data).

### Round-based bulk fetch

`SportMonksProvider::round($roundExternalId)` retrieves an entire matchday in **one request** via `GET /rounds/{id}` with nested includes (`fixtures`, `fixtures.odds`, `fixtures.odds.market`, `fixtures.odds.bookmaker`, `fixtures.participants`, `fixtures.scores`, `fixtures.venue`, `fixtures.state`, `league`, `league.country`). It returns:

```php
[
    'roundId' => '396698', 'name' => '25', 'leagueId' => '648', 'league' => 'Serie A',
    'season' => '26763', 'startingAt' => '2026-08-29', 'endingAt' => '2026-08-31',
    'finished' => true,
    'fixtures' => [ /* internal fixture shape */ ],
    'odds'     => [ /* internal odds shape, + impliedProbability/updatedAt/winning when the vendor supplies them */ ],
    'results'  => [ /* internal result shape, from the embedded scores */ ],
]
```

- Round ids are resolved with `SportMonksProvider::seasonRounds($seasonId)` (`GET /rounds/seasons/{id}`).
- Round-embedded odds carry `original_label` (`1`/`Draw`/`2`) or a display `label` instead of a `selection` object; the mapper handles both shapes.
- Fixture status is resolved from the v3 `state` include object, then `state_id` (official v3 state table, e.g. `5` = FT), with the legacy v2 numeric `status` codes as a fallback.
- Consumer pattern through the fallback manager (rounds are a SportMonks-only capability, so guard with `method_exists`):

```php
$attempt = $providers->withFallback('round', function ($p) use ($roundId) {
    if (!method_exists($p, 'round')) throw new ProviderException('round endpoint not supported', ProviderException::DATA_ERROR);
    return $p->round($roundId);
});
```

The odds prediction ticket engine uses this path: when the serving provider exposes
`round()` and the fetched fixtures carry a `roundId`, `DailyTicketService`
bulk-fetches each matchday's odds with one `round()` call per round
(`fetchRoundOdds`) and only falls back to the per-fixture `odds()` call for
fixtures the round fetch did not cover (no `roundId`, or a failed round
request). Odds already persisted for a match are never re-fetched.

### Round sync job

`SportsSyncService::syncRound($provider, $roundExternalId, $executionKey)`
bulk-syncs a whole matchday in one provider request — fixtures, odds and
results are persisted from the single `round()` payload (idempotent per
execution key, job type `ROUND`, audited as `SPORTS_ROUND_SYNC_*`). It is
exposed through the sync endpoint:

```
GET /api/sports/sync?provider=sportmonks&type=round&roundId=396698
```

Providers without a `round()` endpoint fail the job with an explicit
"does not support round sync" error instead of silently no-op'ing.

### Cron odds job on the round path

`sports_matches` stores `round_id` (nullable, indexed on `provider_id,
round_id` — new column added via the idempotent schema upgrade), populated
from the provider fixture payload at sync time. The cron `odds` job groups
the day's active matches by `(provider, round_id)`: every round on a
round-capable provider is synced once via `syncRound(..., ['results' => false])`
(one provider request per matchday, results skipped so verified results are
never re-written), and matches without a `round_id` — or on providers
without the round endpoint — keep the legacy per-fixture `syncOdds` call.

## Live scores — auto-updating goal scores

When a goal is scored, the Sports Intelligence live board updates itself: no
page reload, no manual "Sync now". The chain is:

1. **Sweep** — `SportsSyncService::syncLive($provider, $key)` calls the
   provider's live endpoint (`liveFixtures()`: API-Football
   `/fixtures?live=all`, TheSportsDB `/livescore.php`, SportMonks
   `/fixtures/live/{date}`, plus the labeled SANDBOX simulation) and upserts
   every in-play match: status, minute and current score land in
   `sports_matches.payload.live` (the normalizer copies provider-stated values
   only — an absent score is never defaulted to 0-0).
2. **Goal detection** — each sweep compares the provider's total goals with the
   last stored total. An increase audits one `SPORTS_GOAL_SCORED` event
   (match, previous score, new score, scoring side, minute, delta); a decrease
   (provider correction) or the very first observation of a live match emits
   nothing.
3. **Board** — `LiveScoreService::board()` serves the stored LIVE matches, each
   with the kickoff it was stored with, and `goalEventsSince($since)` replays
   goal events for the UI flash. `GET /api/sports/live?since=…` (`sports.view`)
   returns both; the Sports console's "Live scores — auto-updating" panel polls
   it and flashes ⚽ GOAL as soon as an event lands. Every row prints the match
   date and time in its own **Kickoff (UTC)** column (`YYYY-MM-DD HH:MM`,
   rendered from the stored kickoff on both the server side and by the poll
   handler); a match the provider gave no kickoff for shows `—`, never a
   guessed time. The football console's live cards carry the same stamp
   (`Sun 6 Sep 2026 · 14:00 UTC`, or `DATA_UNAVAILABLE`).

### Quota-safe by construction

Every consumer funnels into one **self-gated** refresh
(`LiveScoreService::refresh()`):

1. **In-play window gate** — when no stored match can currently be on the
   pitch (nothing `LIVE`, no kickoff within the last 3 hours or the next 10
   minutes), the sweep is skipped outright: `SKIPPED_NO_MATCHES_IN_PLAY`,
   zero provider requests. Idle hours never eat a small daily quota.
2. **Interval throttle** — the provider is polled at most once per
   `WINDELS_SPORTS_LIVE_REFRESH_SECONDS` (default 60, minimum 10) regardless
   of how many browsers are open; concurrent pollers inside one interval
   bucket are deduplicated by the sweep's execution key, and between sweeps
   the board is served purely from storage.

`refresh()` is driven by:

- the `/api/sports/live` poll itself (default when the console is open),
- the **Sports live scores** cron job (`sports-live`, every minute, self-gated
  — disable it in Admin → Cron or raise the interval to protect a free-tier
  quota),
- `php index.php tools sports-cron live`,
- and the operator sync endpoint
  `GET /api/sports/sync?provider=api-football&type=live` for a one-shot sweep.

The circuit breaker applies as everywhere else: a quota-dead feed is skipped
without a request. The refresh interval is the worst-case delay between the
provider reporting a score and the board showing it — lower it on a paid feed
for faster updates.

## Provider health, circuit breaker and DATA_UNAVAILABLE

### Why

On 2026-09-05 the daily ticket run reported `NO_QUALIFIED_TICKET` with
`0 matches evaluated`. Nothing was wrong with the prediction engine — every
data feed had failed: API-Football answered `You have reached the request
limit for the day` (and was still being re-called for `odds` / `fixtures`),
TheSportsDB returned HTTP 400 (retired free key `3`), SportMonks and the
generic HTTP provider returned HTTP 404 (wrong base URL). The engine treated
"no data" as "no qualified games". The provider layer now distinguishes the two.

### Provider states

Every adapter classifies each response through `ProviderHttp::classify()`:

| State | Trigger | Circuit behaviour |
|---|---|---|
| `ONLINE` (HEALTHY) | 2xx and usable body | closed |
| `DEGRADED` | partial data / 5xx | counts towards the 3-failure threshold |
| `RATE_LIMITED` | HTTP 429 per-minute throttle, api-football `errors.rateLimit` | opens for `Retry-After` (default 60 s) |
| `DAILY_QUOTA_EXHAUSTED` | api-football `errors.requests` ("request limit for the day"), `x-ratelimit-requests-remaining: 0`, `/status` `requests.current >= limit_day`, or a 429 whose body says the day is used up | **opens immediately until the next 00:00 UTC** — no retries before the vendor reset |
| `AUTHENTICATION_ERROR` (AUTH_FAILED) | HTTP 401/403, api-football `errors.token` | opens for 5 min (configuration error) |
| `BAD_REQUEST` | HTTP 400/422, api-football parameter errors | opens for 5 min (configuration error) |
| `NOT_FOUND` | HTTP 404/410 | opens for 5 min (configuration error) |
| `TIMEOUT` | cURL errno 28 | counts towards threshold |
| `OFFLINE` | no HTTP response (DNS/TLS/connect) | counts towards threshold |

`ProviderCircuitBreaker` (`Sports/Providers/ProviderCircuitBreaker.php`):
3 generic failures → `OPEN` for 10 minutes → `HALF_OPEN` (one probe) →
`CLOSED` on success / `OPEN` again on failure. Terminal states (quota, rate
limit, configuration) open the circuit at once with the state-specific
cooldown above. Circuits are re-hydrated from `sports_provider_health` at
startup, so a cron tick at 09:00 still knows the quota died at 08:40.

`SportsProviderManager::withFallback()` skips an `OPEN` provider **without
any network call** (not even `health()`), probes `health()` before the first
data call otherwise, feeds a non-`ONLINE` self-report to the breaker, and —
when every provider fails — returns
`{ok:false, failureStatuses:{id:STATE}, summary:"fixtures: all 4 provider(s) failed — api-football DAILY_QUOTA_EXHAUSTED, thesportsdb BAD_REQUEST, sportmonks NOT_FOUND, http-provider NOT_FOUND"}`.

### Diagnostics

Every `ProviderException` carries `details` with `method`, `endpoint`
(credential redacted), `query` (secret parameters replaced by `[redacted]`),
`httpStatus` and a 240-character `bodySnippet`. `ProviderHttp::redact()` also
strips bearer tokens, `x-apisports-key` values, TheSportsDB path keys and
32+-character opaque tokens from any free text before it reaches a log, the
audit trail, a flash message or the API. API keys are never logged.

### API-Football quota monitoring

`ApiFootballProvider::health()` calls `GET /status` (free — it does not count
against the quota) and reads `response.requests.current/limit_day` and the
`x-ratelimit-requests-remaining` / `x-ratelimit-requests-limit` headers. It
reports `rateLimitRemaining`, `limitDaily`, the plan, and returns
`DAILY_QUOTA_EXHAUSTED` with `retryAt` = next 00:00 UTC when nothing is left,
so the manager never spends a paid request to discover an empty quota. The
same headers are checked on every data response.

### DATA_UNAVAILABLE

When the fixtures pull fails on all providers the odds prediction ticket engine no
longer evaluates zero matches and reports `NO_QUALIFIED_TICKET`. Instead:

* `DailyTicketService::runDaily()` returns
  `status: DATA_UNAVAILABLE`, `dataState`, `providerStatuses`,
  `rejection_summary["PROVIDER:<id>"]`, `retryable: true`, and releases the
  job run so the next tick can try again.
* `SportsCronService::jobTicket()` checks `readiness()` first; with
  `operational == 0` it emits the `SPORTS_DAILY_TICKET_BLOCKED` audit event
  and returns `DATA_UNAVAILABLE` without touching the engine.
* `POST /api_sports/run_ticket_engine` answers **HTTP 503** with
  `status: DATA_UNAVAILABLE`, `providerStatuses` and `readiness`.
* The dashboard shows `NO TICKET for <date> — STATUS: DATA_UNAVAILABLE` with
  the per-provider reasons, never "no qualified games".

### Dashboard

`GET /api_sports/providers` and the Sports Intelligence page expose
`readiness = {operational, total, engine: READY|BLOCKED|DISABLED_NO_PROVIDER, providers:{id:{status, detail, circuit, retryAt}}}`.
The page header reads **Operational providers: N/4 · Prediction Engine:
READY/BLOCKED**, the data-feed table has a *Circuit* column (state, reason,
retry time, quota usage) and a red banner lists every non-operational
provider with its state and `retryAt`.

## Live smoke test

`php index.php tools sports-live [provider]` proves the configured providers
actually work against the real APIs, layer by layer: health/auth (+ quota
usage) → today's fixtures → odds for the first fixture → top players where
supported. Read-only; costs a handful of requests per provider. Exit codes:
0 all pass, 1 one or more failed, 2 no providers configured. When a provider
"doesn't work", this tells you exactly which layer fails (bad key,
unreachable host, plan restriction) instead of guessing.

## Safe operation

Provider data is untrusted input. The existing normalizers, data-quality gates, confidence checks, and ticket governance remain in the pipeline. Missing odds from providers without an odds feed must not be treated as fabricated odds; those predictions should be rejected or supplied by a separately licensed odds source.

## Odds freshness, provider fallback and the diagnostics funnel

The daily ticket engine treats bookmaker odds as fresh inside a configurable
TTL and only refreshes when the maximum age is actually exceeded:

* **TTL resolution** (first match wins): explicit context override →
  per-provider override → per-market override →
  `WINDELS_SPORTS_ODDS_MAX_AGE` (seconds) → built-in default of **6 hours**.
  A once-a-day odds sync therefore stays usable all day; it is never marked
  stale merely because the current run did not refresh it. Every prediction
  record stores the provenance: `oddsUpdatedAt`, `oddsSource`,
  `oddsAgeSeconds`, `oddsStatus` (`FRESH` / `STALE` / `UNAVAILABLE` /
  `INVALID_TIMESTAMP`).
* **Refresh order when odds are missing or stale**: bulk `round()` rows (one
  request per matchday, when the fixture provider exposes the round endpoint)
  → the fixture provider's own `odds()` call → any other configured provider
  that knows the fixture under a **verified id**. A provider answering "no
  odds for this fixture" (an empty result, not an error) is not a failure —
  the next provider is tried before the candidate is rejected.
* **Cross-provider safety**: fixture ids are provider-specific. A provider is
  only asked for odds with an id in its OWN namespace — the supplying
  provider's id or a recorded cross-reference (TheSportsDB rows carry
  `idAPIfootball`, preserved as `crossReferences` on the normalized fixture).
  A provider without a verified id is skipped without a request, so odds can
  never be silently attached to another provider's fixture.
* **No double counting**: every rejected candidate/fixture counts exactly one
  *primary* blocking reason (the first failed pipeline stage); all reasons
  remain on the immutable decision record. Shared upstream failures (fixture
  eligibility, odds availability/freshness, market-mandatory data,
  calibration, quality floor) reject the **fixture once** instead of
  generating one rejected prediction per market.
* **Diagnostics**: the run result (and the stored `rejection_summary` under
  the reserved `_diagnostics` key) carries a funnel — fixtures evaluated →
  eligible → with form → fresh odds → sufficient data → predictions → confidence-qualified
  → positive value → risk-qualified → correlation-qualified → final — plus the
  top rejection reasons with the provider that caused each failure, refresh
  attempts, and the active thresholds. The console's no-ticket panel renders
  it; `POST /api/sports/run_ticket_engine` returns it as `diagnostics`.

## Recent form — the model's mandatory input

Every supported market (`MATCH_RESULT`, `TOTAL_GOALS`, `BTTS`,
`DOUBLE_CHANCE`) has exactly one mandatory data field: verified
`recentForm` (home/away goals and conceded per match). No form → no
probability → an explicit `INSUFFICIENT_DATA` rejection. Nothing is
extrapolated to fill the gap.

Provider fixture responses never carry form, so the `FormResolver` fetches it:

* **Any provider that publishes a league table** serves form — one
  `standings()` request per *(league, season)* covers every team in that
  league, cached for the whole run. The table is the **primary** source:
  api-football's per-team `/teams/statistics` costs two lookups per fixture
  and starved the 30-lookup budget after ~15 fixtures (the "14 with-form"
  dead end of the 2026-09-10 run). Per-team statistics are now the
  **fallback** for teams the table does not cover (cup sides, mid-season
  moves, no games yet). A fixture whose provider row stated **no season**
  (`league.season` is null for cups and friendlies) is asked with the season
  that provider's own endpoint requires: the current year for api-football
  (whose `/standings` refuses an empty `season=` — those fixtures were
  rejected `INSUFFICIENT_DATA` even though their table exists), and **no**
  season for TheSportsDB and SportMonks, which read it as a `2025-2026` range
  or an internal id where a bare year would match nothing. A team the answered
  table does not carry stays unresolved; no number is ever extrapolated.
* **The lookup budget is spent where a ticket can still be won.** The daily
  ticket engine screens fixture eligibility *before* enrichment, so
  `WINDELS_SPORTS_FORM_LOOKUPS` (default 30) is never burned on matches that
  already kicked off or start inside the 2-hour cut-off. Only live requests
  are charged against it; reading an already-cached league table is free.
* **Verified form is carried forward, not re-fetched.** Form stored on a
  fixture by an earlier run is reused while it is inside
  `WINDELS_SPORTS_FORM_MAX_AGE` (default 7 days), keeping its original
  `source` and `timestamp` on the decision record. Older form is dropped and
  re-read; form without a timestamp is never reused. The stored `payload`
  column is read in **either** shape (decoded document or raw JSON text) —
  `SportsDataNormalizer::document()` — because a repository that hands back
  the text of the column while the caller expects an array reads as "no
  stored form" and re-buys every verified reading until the daily quota is
  gone (case 137; the sports repository decodes `findMatch` like every other
  row reader for the same reason).
* **Observability**: the funnel carries `formEnrichmentCandidates` (eligible
  fixtures offered to the resolver), `fixturesWithRecentForm`,
  `fixturesWithCarriedForwardForm`, and the resolver's own stats (`lookupsUsed`
  / `budget` / `lookupFailures` / `budgetSkips` / `providerCapable`). When no
  fixture resolved form, the no-ticket message names the cause — missing
  endpoint, failed lookups, or a starved budget with the numbers to fix it.

## Calibration — the cold start

The ticket engine predicts nothing without an **APPROVED** calibration
(`MODEL_NOT_CALIBRATED`), and a fitted Platt calibration can only be fitted
from 20+ SETTLED stored predictions — which only the ticket engine writes.
A fresh installation would be locked out of itself, so the daily run breaks
the deadlock with the documented **identity calibration**
(`POST /api/sports/calibrations/bootstrap-identity` creates the same row
manually):

* **Auto-bootstrap + auto-approval (audited system act)**: when a run starts
  and no APPROVED calibration exists for the deployed model version, the
  engine bootstraps the identity mapping (intercept 0 / slope 1 — the raw
  model probability, the same mapping the backtester uses) and approves it
  as actor `system:daily-ticket`, emitting a `SPORTS_CALIBRATION_AUTO_APPROVED`
  audit event. The funnel carries `calibrationBootstrap`
  (`IDENTITY_AUTO_APPROVED` / `REJECTED_BY_ADMIN` / …).
* **Only the identity bootstrap is auto-approved.** Fitted Platt
  calibrations remain a human decision, and once one is approved it is the
  newest APPROVED row, so the identity bootstrap retires itself.
* **Explicit vetoes are honoured**: if an administrator REJECTS the identity
  bootstrap, the engine does not resurrect it — the run stays blocked with
  `MODEL_NOT_CALIBRATED` and a message that names the veto. `require_calibration`
  (config) can also be set to 0, which runs the model through the identity
  mapping without any calibration row and flags it `identity` on the
  decision record.
* Tickets remain gated by confidence / quality / value / risk — and, in the
  default `USER_APPROVAL_REQUIRED` engine mode, by user approval — before
  anything happens.

### Persistence contract (2026-09-10 incident)

On 2026-09-10 a run reported `NO_QUALIFIED_TICKET` with every fresh-odds
fixture rejected `MODEL_NOT_CALIBRATED` and the diagnostic
`CALIBRATION_PERSIST_FAILED`: the engine had created its identity bootstrap,
but the row did not survive the database round-trip. The deployed
`sports_calibrations.method` column was still `VARCHAR(16)` and the marker of
the time (`identity-bootstrap`, 18 characters) was truncated or rejected by
MySQL, so the engine never recognized its own cold-start break. The contract
that now guards this:

* **The marker fits the narrowest deployed column.** The marker is
  `identity` (8 characters) and may never rely on the widened `VARCHAR(32)`
  — un-migrated installs with `VARCHAR(16)` must keep working
  (`tests/cases/136-sports-column-width-contract.php` pins the widths in the
  shipped DDL against every marker the code can write).
* **Identity rows are recognised by prefix**, never by exact equality: the
  old marker stored whole (`identity-bootstrap`) or truncated
  (`identity-bootstr`) is the same bootstrap row — reused and healed, never
  duplicated.
* **Every write is verified against a read-back** before success is
  reported. A driver that silently truncates or swallows the insert produces
  an honest `CALIBRATION_PERSIST_FAILED` (audited as
  `SPORTS_CALIBRATION_PERSIST_FAIL`), never a phantom calibration id.
  `tests/cases/138-sports-calibration-roundtrip-db.php` exercises this
  round-trip against the real database — the in-memory stub cannot fail a
  round-trip, which is why the original bug shipped green.
* **Boot-time repair**: the schema installer widens historically narrow
  columns on existing MySQL/PostgreSQL databases
  (`sports_calibrations.method` → `VARCHAR(32)`, `audit_logs.actor`/`type`
  → `VARCHAR(64)`). The marker never depends on it.

After fixing a `CALIBRATION_PERSIST_FAILED` day, verify and re-run:

```bash
php index.php tools sports-calibration-check 2026-09-10   # column vs marker, rows, run errors, audit trail
php index.php tools sports-cron ticket 2026-09-10          # re-run that day (blocked days stay retryable)
```

`runtime/rerun-daily-ticket.mjs` runs the same sequence on the offline dev
runtime (SANDBOX simulation provider, sqlite storage).

## Odds Prediction Ticket compliance rules

The `🎯 Odds Prediction Ticket` builder is intentionally conservative:

* It builds at most one football ticket per configured run from enabled Provider Hub feeds only (API-Football, Sportmonks, TheSportsDB where supported, or another registered `SportsDataProvider`). Missing fixture, form, odds, or provider data is reported as unavailable; it is never filled with synthetic values.
* Runtime date/time is read when the run starts evaluating fixtures. Eligible fixtures must be football, must be provider-not-started (`NS`, or the provider adapter's explicit scheduled mapping), and must kick off strictly more than two hours after that runtime clock.
* Fixture discovery is deliberately wider than prediction generation: it requests up to **200** upcoming candidates over the configured-local ticket day and next local day, with `NS` requested server-side where the provider supports it. The engine then applies the same provider-neutral eligibility rule and still generates/evaluates at most **50** fixtures. This prevents an afternoon provider page containing only already-started or imminent matches from hiding later legitimate candidates; it does **not** relax the two-hour lead or fabricate a ticket.
* Current odds are accepted only when the provider returned numeric decimal odds greater than `1.00`, with a valid observation timestamp, for one of these supported markets: `MATCH_RESULT` (1X2), `TOTAL_GOALS / OVER_1_5`, `BTTS / YES`, or `DOUBLE_CHANCE`.
* Ticket thresholds are hard floors: the WINDELS model confidence must be at least the configured `min_confidence` (default `30%`, configurable within `30–100`), data quality at least the configured `min_data_quality` (shipped default `55/100`, configurable within `30–100`), the de-vigged expected value must reach the configured `min_expected_value` (shipped default `+3%`), odds must be fresh under the configured TTL, and the combined decimal odds window is fully configurable from the `1.01` sanity floor upward (shipped default `2.00`–`3.50` over at most two legs; the previous `5.00`–`8.00` window remains configurable). The optimizer multiplies unrounded leg odds and rounds only the stored/displayed total.
* The confidence floor (30%) and the data-quality floor (30) are absolute: an operator may raise the configured values but never lower them beneath the gates. `29.99%` confidence and `29/100` data quality are rejected; `30%` and `30/100` pass. The gates are enforced in `ConfigurationService` (defaults + validation), `ConfidencePolicy` (tier selection) and `TicketOptimizer` (pool admission), so no configuration path and no authored confidence policy can admit evidence beneath them.
* Stake sizing is configurable (`staking_mode`): `FLAT` (the fixed `stake_amount`, default) or `FRACTIONAL_KELLY` (`kelly_fraction` × full Kelly on the ticket's calibrated combined probability against `bankroll`, capped by `max_exposure` and 4× the flat unit; a non-positive Kelly edge stakes nothing). The full computation trail is stored in the ticket's `odds_calculation.staking` block.
* The optimizer prefers stronger confidence, quality, expected value, fresh/reliable odds, lower risk, fewer unnecessary selections, and low correlation. It does not add weak selections just to reach the odds band.
* If no verified combination satisfies those gates, the run records `NO_QUALIFIED_TICKET` with a `NO VALUE TICKET TODAY` message rather than guessing.
* Outcome states are never conflated. `NO_QUALIFIED_TICKET` means fixtures were genuinely assessed and rejected; a missing feed is `NO_PROVIDER`, an all-provider outage is `DATA_UNAVAILABLE`, a healthy feed with nothing scheduled is `NO_FIXTURES`, and an administratively switched-off engine is `DISABLED`. Only the first describes the day's football; the rest describe the system. `DATA_UNAVAILABLE` and `NO_PROVIDER` answer HTTP `503` on the API, while `NO_FIXTURES` and `NO_QUALIFIED_TICKET` are ordinary `200` outcomes.
* Both entry points — `POST /sports/generate-ticket` (browser) and `POST /api/sports/ticket-engine/run` (API) — call the same `DailyTicketService` and return the same contract via `GenerationResult::fromRunDaily()`. Generation requires `sports.manage`; `sports.view` grants read-only access to published tickets. The selected date is mandatory and is never silently replaced with today: a malformed or impossible date is refused (`422` on the API) rather than redirected onto the wrong day.

### Pipeline endpoint aliases

For the odds prediction pipeline contract, these API routes map to the implementation:

* `GET /api/sports/fixtures?date=today` (also `/fixtures`) reads saved verified fixtures for the requested day.
* `GET /api/sports/odds?fixture={fixture_id}` (also `/odds`) reads saved provider odds for that fixture/match.
* `POST /api/sports/predict` (also `/predict`) runs the daily odds prediction ticket builder.
* `POST /api/sports/settle` (also `/settle`) sweeps all open tickets and only settles picks with verified persisted final results.

The endpoint aliases do not relax authentication, permissions, provider validation, odds freshness, or the `NO VALUE TICKET TODAY` fail-safe.
