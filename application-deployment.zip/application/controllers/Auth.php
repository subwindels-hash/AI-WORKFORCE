<?php
defined('BASEPATH') or exit('No direct script access allowed');

/** Browser authentication pages for the portable PHP/cPanel application. */
class Auth extends MY_Controller
{
    public function index()
    {
        // Honour ?return_to=/path so an in-page "sign in to view" link on a
        // gated console page returns the visitor to that exact page after they
        // authenticate. Same-origin path only — never a scheme or //host.
        $returnTo = trim((string) $this->input->get('return_to', true));
        if ($returnTo !== '' && str_starts_with($returnTo, '/') && !str_starts_with($returnTo, '//') && !str_contains($returnTo, '://')) {
            $this->session->set_userdata('return_to', $returnTo);
        }
        if ($user = $this->sessionUser()) {
            $next = (string) $this->session->userdata('return_to');
            if ($next !== '' && str_starts_with($next, '/') && !str_starts_with($next, '//') && !str_contains($next, '://')) {
                $this->session->unset_userdata('return_to');
                redirect($next);
                return;
            }
            redirect($this->isAdmin($user) ? '/admin' : '/dashboard');
            return;
        }
        $this->renderAuth(false);
    }

    public function admin_login()
    {
        if ($user = $this->sessionUser()) {
            redirect($this->isAdmin($user) ? '/admin' : '/access-denied');
            return;
        }
        // First-run setup: when the database has no administrator at all
        // (e.g. a cPanel import that lost the seeded admin row), offer the
        // one-time browser setup form instead of a login that can never succeed.
        $exists = $this->AIWorkforce_model->identity->superAdminExists();
        if ($exists === false) {
            $this->load->view('auth/admin_setup', [
                'title' => 'Create the platform administrator',
                'error' => $this->consumeFlash('error'),
                'notice' => $this->consumeFlash('notice'),
                'csrfToken' => $this->ensureVisitorCsrf(),
            ]);
            return;
        }
        if ($exists === null) {
            $this->flash('error', 'The administrator database could not be verified. Import database/production.sql in phpMyAdmin and check the VP_DB_* values in .env.');
        }
        $this->renderAuth(true);
    }

    public function register()
    {
        if ($this->sessionUser()) { redirect('/dashboard'); return; }
        $protection = $this->signupProtection();
        $this->load->view('auth/register', [
            'title' => 'Create an account',
            'error' => $this->consumeFlash('error'),
            'notice' => $this->consumeFlash('notice'),
            'csrfToken' => $this->ensureVisitorCsrf(),
            'securityQuestions' => \AIWorkforce\IdentitySchema::SECURITY_QUESTIONS,
            // Site key + provider only — the secret never reaches a view.
            'captcha' => $protection->widget(),
            'old' => $this->consumeOld(),
        ]);
    }

    /** Sign-up protection as configured on the super-admin settings page. */
    private function signupProtection(): \AIWorkforce\SignupProtection
    {
        try {
            $portal = new \AIWorkforce\AdminPortal($this->AIWorkforce_model);
            $portal->ensureSchema();
            return \AIWorkforce\SignupProtection::fromPortal($portal);
        } catch (Throwable $e) {
            log_message('error', 'signup protection settings unavailable: ' . $e->getMessage());
            return \AIWorkforce\SignupProtection::fromSettings([]);
        }
    }

    /** Re-populate the non-secret fields after a validation redirect. */
    private function rememberOld(): void
    {
        $keep = [];
        foreach (['username', 'email', 'phone', 'address', 'security_question'] as $f) $keep[$f] = (string) $this->input->post($f);
        $this->session->set_flashdata('register_old', $keep);
    }

    private function consumeOld(): array
    {
        $old = $this->session->flashdata('register_old');
        return is_array($old) ? $old : [];
    }

    public function register_submit()
    {
        if ($this->sessionUser()) { redirect('/dashboard'); return; }
        if (!$this->validAuthCsrf()) {
            $this->flash('error', 'Your session expired while filling in the form. Please try again.');
            redirect('/register');
            return;
        }
        $portal = new \AIWorkforce\AdminPortal($this->AIWorkforce_model);
        $portal->ensureSchema();
        if ($portal->setting('registration_enabled', '1') !== '1') {
            $this->flash('error', 'New account registration is currently closed.');
            redirect('/register');
            return;
        }
        $protection = \AIWorkforce\SignupProtection::fromPortal($portal);
        $this->rememberOld();
        // Honeypot: invisible to people; bots fill every field. Answer exactly
        // like a captcha failure so automation learns nothing from the reply.
        if (\AIWorkforce\SignupProtection::honeypotTripped($this->input->post(\AIWorkforce\SignupProtection::HONEYPOT_FIELD))) {
            $this->AIWorkforce_model->audit->emit('SIGNUP_BLOCKED', 'Registration rejected: honeypot field filled', ['reason' => 'HONEYPOT', 'ip' => (string) $this->input->ip_address()], 'visitor');
            $this->flash('error', 'Human verification failed. Please try again.');
            redirect('/register');
            return;
        }
        // reCAPTCHA — verified server-side, fails closed. Checked before the
        // cheap field validation so a bot cannot probe the rules captcha-free.
        $captcha = $protection->verifyCaptcha($this->input->post(\AIWorkforce\SignupProtection::CAPTCHA_FIELD), (string) $this->input->ip_address());
        if (!$captcha['ok']) {
            $this->AIWorkforce_model->audit->emit('SIGNUP_BLOCKED', 'Registration rejected by reCAPTCHA: ' . $captcha['reason'], [
                'reason' => $captcha['reason'], 'score' => $captcha['score'], 'errorCodes' => $captcha['errorCodes'], 'ip' => (string) $this->input->ip_address(),
            ], 'visitor');
            $this->flash('error', $captcha['message']);
            redirect('/register');
            return;
        }
        $username = strtolower(trim((string) $this->input->post('username')));
        $emailCheck = $protection->validateEmail((string) $this->input->post('email'));
        $email = $emailCheck['email'];
        $phone = \AIWorkforce\IdentitySchema::normalizePhone((string) $this->input->post('phone'));
        $address = \AIWorkforce\IdentitySchema::normalizeAddress((string) $this->input->post('address'));
        $password = (string) $this->input->post('password');
        $confirm = (string) $this->input->post('password_confirm');
        $terms = (string) $this->input->post('terms');
        if (!$this->validUsername($username)) {
            $this->flash('error', 'Enter a valid username (3–20 letters, numbers or underscores, starting with a letter).');
            redirect('/register');
            return;
        }
        if (!$emailCheck['ok']) {
            if (in_array($emailCheck['reason'], ['DISPOSABLE', 'DOMAIN_BLOCKED', 'DOMAIN_NOT_ALLOWED'], true)) {
                $this->AIWorkforce_model->audit->emit('SIGNUP_BLOCKED', 'Registration rejected: email ' . $emailCheck['reason'], ['reason' => $emailCheck['reason'], 'domain' => substr((string) strrchr($email, '@'), 1)], 'visitor');
            }
            $this->flash('error', $emailCheck['message']);
            redirect('/register');
            return;
        }
        if (!\AIWorkforce\IdentitySchema::validPhone($phone) || !\AIWorkforce\IdentitySchema::validAddress($address)) {
            $this->flash('error', 'Enter a valid phone number and a street address (at least 5 characters).');
            redirect('/register');
            return;
        }
        if (strlen($password) < 12 || $password !== $confirm) {
            $this->flash('error', 'Use a password of at least 12 characters and confirm it exactly.');
            redirect('/register');
            return;
        }
        if ($terms !== '1') {
            $this->flash('error', 'Please accept the Terms and Privacy Policy to create an account.');
            redirect('/register');
            return;
        }
        $recovery = \AIWorkforce\IdentitySchema::fromPostedQuestion(
            (string) $this->input->post('security_question'),
            (string) $this->input->post('security_answer')
        );
        if (!$recovery) {
            $this->flash('error', 'Choose a security question and an answer of at least 2 characters.');
            redirect('/register');
            return;
        }
        if ($this->AIWorkforce_model->identity->findUserByEmail($email)) {
            $this->flash('error', 'An account with that email already exists. Sign in instead.');
            redirect('/login');
            return;
        }
        if ($this->AIWorkforce_model->identity->usernameTaken($username)) {
            $this->flash('error', 'That username is already taken. Try a different one.');
            redirect('/register');
            return;
        }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            $now = gmdate('c');
            $new = $this->AIWorkforce_model->identity->createUser([
                'username' => $username,
                'email' => $email,
                'phone' => $phone,
                'address' => $address,
                'security_question' => $recovery['security_question'],
                'security_answer' => $recovery['security_answer'],
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'display_name' => $username,
                'active' => 1,
                'created_at' => $now,
                'updated_at' => $now,
                'last_login_at' => $now,
            ]);
            if (empty($new['id'])) {
                log_message('error', 'register_submit: createUser returned no id');
                $this->flash('error', 'Unable to save your changes. Please try again.');
                redirect('/register');
                return;
            }
            $role = $this->AIWorkforce_model->identity->ensureRole('platform_member', 'Platform member');
            foreach (['trading.view', 'sports.view', 'lottery.view'] as $code) {
                $pid = $this->AIWorkforce_model->identity->ensurePermission($code, $code);
                $this->AIWorkforce_model->identity->grantRolePermission($role, $pid);
            }
            $this->AIWorkforce_model->identity->assignRole((int) $new['id'], $role);
            $this->AIWorkforce_model->audit->emit('USER_REGISTERED', 'A visitor created a platform member account', ['userId' => (int) $new['id'], 'userUid' => (string) ($new['user_uid'] ?? '')], 'visitor');
            $portal->notifyAdmins('USER_REGISTERED', 'info', 'New user registration: ' . ($new['username'] ?? $email), [
                'userUid' => (string) ($new['user_uid'] ?? ''),
                'username' => (string) ($new['username'] ?? ''),
            ], 'register:' . (string) ($new['user_uid'] ?? $new['id']));
            $user = $this->platform->identity->authenticate($username, $password);
            if (!$user) { $this->flash('error', 'Account created. Sign in to continue.'); redirect('/login'); return; }
            $this->establishSession($user);
            $this->issueRememberCookie((int) $new['id']);
            $this->session->set_flashdata('register_old', null);
            $this->flash('notice', '✓ Changes saved successfully');
            redirect('/dashboard');
        } catch (Throwable $e) {
            log_message('error', 'register_submit failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
            redirect('/register');
        }
    }

    public function forgot()
    {
        $this->load->view('auth/forgot', [
            'title' => 'Reset password',
            'notice' => $this->consumeFlash('notice'),
            'csrfToken' => $this->ensureVisitorCsrf(),
        ]);
    }

    public function forgot_submit()
    {
        if (!$this->validAuthCsrf()) {
            $this->flash('error', 'Your session expired. Please try again.');
            redirect('/forgot-password'); return;
        }
        $this->flash('notice', 'Password resets are issued by an administrator. Email support or your platform admin — this form does not invent a reset token.');
        redirect('/forgot-password');
    }

    public function denied()
    {
        $this->load->view('auth/denied', [
            'title' => 'Access denied',
            'user' => $this->sessionUser(),
        ]);
    }

    public function login()
    {
        $admin = $this->input->post('admin') === '1';
        if ($admin && $this->input->post('setup') === '1') { $this->handleFirstRunSetup(); return; }
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); $this->redirectLogin($admin); return; }
        // Single sign-in identifier — username, email address OR six-digit User ID.
        $identifier = trim((string) $this->input->post('identifier'));
        if ($identifier === '') $identifier = trim((string) $this->input->post('email'));
        $password = (string) $this->input->post('password');
        $remember = $this->input->post('remember') === '1';
        $attempts = (int) $this->session->userdata('login_attempts');
        $until = (int) $this->session->userdata('login_locked_until');
        $portal = new \AIWorkforce\AdminPortal($this->AIWorkforce_model);
        $portal->ensureSchema();
        $maxAttempts = max(3, min(20, (int) $portal->setting('login_max_attempts', '5')));
        $lockSeconds = max(60, min(86400, (int) $portal->setting('login_lockout_seconds', '900')));
        if ($until > time()) { $this->flash('error', 'Too many attempts. Try again later.'); $this->redirectLogin($admin); return; }
        if ($identifier === '' || $password === '') { $this->flash('error', 'Enter your username, email or User ID and your password.'); $this->redirectLogin($admin); return; }
        if ($this->platform->identity->isSuspendedWithPassword($identifier, $password)) {
            $this->flash('error', 'Your account is currently unavailable. Please contact support.');
            $this->redirectLogin($admin); return;
        }
        $user = $this->platform->identity->authenticate($identifier, $password);
        if (!$user || ($admin && !$this->platform->identity->canAccessAdmin($user))) {
            $attempts++;
            $this->session->set_userdata('login_attempts', $attempts);
            if ($attempts >= $maxAttempts) {
                $this->session->set_userdata('login_locked_until', time() + $lockSeconds);
                $portal->notifyAdmins('SUSPICIOUS_LOGIN', 'warning', 'Login lockout after repeated failed attempts', [
                    'identifier' => mb_substr($identifier, 0, 80),
                    'adminForm' => $admin,
                ], 'lockout:' . md5(strtolower($identifier)));
            }
            if ($admin && $this->AIWorkforce_model->identity->superAdminExists() === false) {
                $this->flash('error', 'No administrator account exists in the database yet. Open the administrator login page — it now offers a one-time setup form to create the first administrator (no terminal required).');
            } else {
                $this->flash('error', $admin ? 'Administrator access was not granted.' : 'Invalid username, email or User ID, or password.');
            }
            $this->redirectLogin($admin); return;
        }
        $this->establishSession($user);
        if ($admin || $this->canAccessAdmin($user)) {
            $portal->log($user, 'ADMIN_LOGIN', 'ok', null, [], (string) $this->input->ip_address());
        }
        // Keep the user signed in persistently until they explicitly click Logout
        $this->issueRememberCookie((int) $user['id']);
        $next = (string) $this->session->userdata('return_to');
        $this->session->unset_userdata('return_to');
        // Preserve the exact page the visitor requested before signing in, for
        // everyone including administrators — a person who asked for /sports
        // must land on /sports, not be diverted to /admin. Only accept a safe,
        // same-origin internal path (leading single slash, no scheme, no
        // protocol-relative //host) so an open redirect can never be smuggled
        // through return_to.
        $safeNext = ($next !== '' && str_starts_with($next, '/') && !str_starts_with($next, '//') && !str_contains($next, '://'))
            ? $next : '';
        if ($safeNext !== '') { redirect($safeNext); return; }
        if ($admin || $this->isAdmin($user)) { redirect('/admin'); return; }
        redirect('/dashboard');
    }

    /**
     * One-time first-run setup (POST /login/submit with admin=1&setup=1):
     * create the platform's first super administrator from the browser.
     * Shown only while NO administrator exists; fail-closed afterwards.
     */
    private function handleFirstRunSetup(): void
    {
        if (!$this->validAuthCsrf()) {
            $this->flash('error', 'Your session expired. Please try again.');
            redirect('/admin/login');
            return;
        }
        $exists = $this->AIWorkforce_model->identity->superAdminExists();
        if ($exists === true) {
            $this->flash('notice', 'An administrator already exists — sign in below.');
            redirect('/admin/login');
            return;
        }
        $name = trim((string) $this->input->post('display_name'));
        $email = strtolower(trim((string) $this->input->post('email')));
        $password = (string) $this->input->post('password');
        $confirm = (string) $this->input->post('password_confirm');
        if ($name === '') $name = 'Platform Administrator';
        if ($exists === null) {
            $this->flash('error', 'The database could not be verified. Import database/production.sql in phpMyAdmin and check the VP_DB_* values in .env, then try again.');
            redirect('/admin/login');
            return;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->flash('error', 'Enter a valid email address for the administrator account.');
            redirect('/admin/login');
            return;
        }
        if (strlen($password) < 12 || $password !== $confirm) {
            $this->flash('error', 'Use a password of at least 12 characters and confirm it exactly.');
            redirect('/admin/login');
            return;
        }
        if ($this->AIWorkforce_model->identity->emailTaken($email)) {
            $this->flash('error', 'An account with that email already exists. Sign in instead.');
            redirect('/login');
            return;
        }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            $this->seedAccessControls();
            $user = $this->platform->identity->createFirstSuperAdmin($email, $password, $name);
            $this->AIWorkforce_model->audit->emit('ADMIN_BOOTSTRAPPED', 'First platform administrator created through the one-time web setup', [
                'userId' => (int) $user['id'],
                'userUid' => (string) ($user['user_uid'] ?? ''),
            ], 'web-setup');
            $this->issueRememberCookie((int) $user['id']);
            $this->flash('notice', 'Platform administrator created. Sign in now with your new credentials.');
        } catch (Throwable $e) {
            log_message('error', 'first-run admin setup failed: ' . $e->getMessage());
            $this->flash('error', 'The administrator account could not be created. Check that database/production.sql was imported and the database user has ALL PRIVILEGES (cPanel → MySQL Databases).');
        }
        redirect('/admin/login');
    }

    /** Same RBAC defaults as Tools::seedAccessControls (shared matrix in tools/rbac.php). */
    private function seedAccessControls(): void
    {
        require_once FCPATH . 'tools/rbac.php';
        $identity = $this->AIWorkforce_model->identity;
        ai_workforce_seed_rbac(
            fn(string $code, string $name): int => $identity->ensureRole($code, $name),
            fn(string $code, string $name): int => $identity->ensurePermission($code, $name),
            fn(int $roleId, int $permissionId): bool => (bool) $identity->grantRolePermission($roleId, $permissionId)
        );
    }

    public function logout()
    {
        $identity = $this->sessionUser();
        if ($identity) {
            $token = (string) $this->input->post('csrf_token');
            $known = (string) $this->session->userdata('csrf_token');
            if ($token === '' || $known === '' || !hash_equals($known, $token)) { $this->flash('error', 'Invalid security token.'); redirect('/account'); return; }
        }
        $this->clearRememberCookie();
        $this->session->sess_destroy();
        // Render the goodbye page for both a completed POST logout and a GET.
        $this->load->view('auth/goodbye', [
            'title' => 'You\'ve been signed out',
            'csrfToken' => bin2hex(random_bytes(32)),
        ]);
    }

    public function account()
    {
        $user = $this->requireLogin();
        $fresh = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
        if ($fresh) {
            $fresh['permissions'] = $user['permissions'] ?? [];
            $user = $this->impersonator()
                ? \AIWorkforce\IdentitySchema::stripSecrets($fresh)
                : \AIWorkforce\IdentitySchema::stripSecrets($fresh, true);
        }
        $this->renderPage('My Account', 'account', [
            'user' => $user,
            'impersonating' => (bool) $this->impersonator(),
            'securityQuestions' => \AIWorkforce\IdentitySchema::SECURITY_QUESTIONS,
        ]);
    }

    /** Dashboard → My Account → Profile: change the username (their own only). */
    public function update_username()
    {
        $user = $this->requireLogin();
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); redirect('/account'); return; }
        $username = strtolower(trim((string) $this->input->post('username')));
        if (!$this->validUsername($username)) {
            $this->flash('error', 'Usernames must be 3–20 characters using letters, numbers or underscores, starting with a letter.');
            redirect('/account'); return;
        }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            if ($this->AIWorkforce_model->identity->usernameTaken($username, (int) $user['id'])) {
                $this->flash('error', 'That username is already in use by another account.');
                redirect('/account'); return;
            }
            $originalUid = (string) ($user['user_uid'] ?? '');
            $this->AIWorkforce_model->identity->updateUser((int) $user['id'], ['username' => $username, 'display_name' => $username]);
            $fresh = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
            if (!$fresh || strtolower((string) ($fresh['username'] ?? '')) !== $username) {
                log_message('error', 'update_username: persisted username mismatch for user ' . (int) $user['id']);
                $this->flash('error', 'Your username could not be saved. Please try again.');
                redirect('/account'); return;
            }
            if ($originalUid !== '' && (string) ($fresh['user_uid'] ?? '') !== $originalUid) {
                log_message('error', 'update_username: User ID changed unexpectedly for user ' . (int) $user['id']);
            }
            $this->AIWorkforce_model->audit->emit('USER_UPDATED', 'User changed their username', ['userId' => (int) $user['id']], (string) $user['id']);
            $this->reestablishIdentity((int) $user['id']);
            $this->flash('notice', '✓ Changes saved successfully');
        } catch (Throwable $e) {
            log_message('error', 'update_username failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
        }
        redirect('/account');
    }

    /** Dashboard → My Account → Profile: change the email (their own only). */
    public function update_email()
    {
        $user = $this->requireLogin();
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); redirect('/account'); return; }
        $email = strtolower(trim((string) $this->input->post('email')));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->flash('error', 'Enter a valid email address.');
            redirect('/account'); return;
        }
        if ($this->AIWorkforce_model->identity->emailTaken($email, (int) $user['id'])) {
            $this->flash('error', 'That email address is already attached to another account.');
            redirect('/account'); return;
        }
        $this->AIWorkforce_model->identity->updateUser((int) $user['id'], ['email' => $email]);
        $this->AIWorkforce_model->audit->emit('USER_UPDATED', 'User changed their email address', ['userId' => (int) $user['id']], (string) $user['id']);
        $this->reestablishIdentity((int) $user['id']);
        $this->flash('notice', 'Your email address has been updated.');
        redirect('/account');
    }

    /** Dashboard → My Account → Profile: change phone number and address. */
    public function update_contact()
    {
        $user = $this->requireLogin();
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); redirect('/account'); return; }
        $phone = \AIWorkforce\IdentitySchema::normalizePhone((string) $this->input->post('phone'));
        $address = \AIWorkforce\IdentitySchema::normalizeAddress((string) $this->input->post('address'));
        if (!\AIWorkforce\IdentitySchema::validPhone($phone) || !\AIWorkforce\IdentitySchema::validAddress($address)) {
            $this->flash('error', 'Enter a valid phone number and a street address (at least 5 characters).');
            redirect('/account'); return;
        }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            $this->AIWorkforce_model->identity->updateUser((int) $user['id'], ['phone' => $phone, 'address' => $address]);
            $fresh = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
            if (!$fresh || (string) ($fresh['phone'] ?? '') !== $phone || (string) ($fresh['address'] ?? '') !== $address) {
                log_message('error', 'update_contact: persisted phone/address mismatch for user ' . (int) $user['id']);
                $this->flash('error', 'Unable to save your changes. Please try again.');
                redirect('/account'); return;
            }
            $this->AIWorkforce_model->audit->emit('USER_UPDATED', 'User changed their phone number and address', ['userId' => (int) $user['id']], (string) $user['id']);
            $this->reestablishIdentity((int) $user['id']);
            $this->flash('notice', '✓ Changes saved successfully');
        } catch (Throwable $e) {
            log_message('error', 'update_contact failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
        }
        redirect('/account');
    }

    /** Dashboard → My Account → Security: change security question. PIN is assigned automatically and cannot be changed. */
    public function update_recovery()
    {
        $user = $this->requireLogin();
        if ($this->impersonator()) {
            $this->flash('error', 'Recovery details cannot be changed while viewing as another user.');
            redirect('/account#security'); return;
        }
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); redirect('/account#security'); return; }
        $current = (string) $this->input->post('current_password');
        $stored = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
        if (!$stored || !password_verify($current, $stored['password_hash'])) {
            $this->flash('error', 'Your current password is not correct.');
            redirect('/account#security'); return;
        }
        $recovery = \AIWorkforce\IdentitySchema::fromPostedQuestion(
            (string) $this->input->post('security_question'),
            (string) $this->input->post('security_answer')
        );
        if (!$recovery) {
            $this->flash('error', 'Choose a security question and an answer of at least 2 characters.');
            redirect('/account#security'); return;
        }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            $originalPin = (string) ($stored['security_pin'] ?? '');
            $this->AIWorkforce_model->identity->updateUser((int) $user['id'], $recovery);
            $fresh = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
            if (!$fresh || (string) ($fresh['security_question'] ?? '') !== $recovery['security_question']) {
                log_message('error', 'update_recovery: persisted question mismatch for user ' . (int) $user['id']);
                $this->flash('error', 'Unable to save your changes. Please try again.');
                redirect('/account#security'); return;
            }
            if ($originalPin !== '' && (string) ($fresh['security_pin'] ?? '') !== $originalPin) {
                log_message('error', 'update_recovery: Security PIN changed unexpectedly for user ' . (int) $user['id']);
            }
            $this->AIWorkforce_model->audit->emit('USER_UPDATED', 'User changed their security question', ['userId' => (int) $user['id']], (string) $user['id']);
            $this->reestablishIdentity((int) $user['id']);
            $this->flash('notice', '✓ Changes saved successfully');
        } catch (Throwable $e) {
            log_message('error', 'update_recovery failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
        }
        redirect('/account#security');
    }

    /** Dashboard → My Account → Security: change the password (their own only). */
    public function change_password()
    {
        $user = $this->requireLogin();
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); redirect('/account'); return; }
        $current = (string) $this->input->post('current_password');
        $password = (string) $this->input->post('new_password');
        $confirm = (string) $this->input->post('new_password_confirm');
        $stored = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
        if (!$stored || !password_verify($current, $stored['password_hash'])) {
            $this->flash('error', 'Your current password is not correct.');
            redirect('/account#security'); return;
        }
        if (strlen($password) < 12) { $this->flash('error', 'Your new password must be at least 12 characters.'); redirect('/account#security'); return; }
        if ($password !== $confirm) { $this->flash('error', 'The two new passwords do not match.'); redirect('/account#security'); return; }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            $this->AIWorkforce_model->identity->updateUser((int) $user['id'], ['password_hash' => password_hash($password, PASSWORD_DEFAULT)]);
            $fresh = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
            if (!$fresh || !password_verify($password, (string) ($fresh['password_hash'] ?? ''))) {
                log_message('error', 'change_password: persisted password mismatch for user ' . (int) $user['id']);
                $this->flash('error', 'Unable to save your changes. Please try again.');
                redirect('/account#security'); return;
            }
            $this->AIWorkforce_model->audit->emit('PASSWORD_CHANGED', 'User changed their password', ['userId' => (int) $user['id']], (string) $user['id']);
            $this->reestablishIdentity((int) $user['id']);
            $this->flash('notice', '✓ Changes saved successfully');
        } catch (Throwable $e) {
            log_message('error', 'change_password failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
        }
        redirect('/account#security');
    }

    /** Dashboard → My Account → Profile: upload / replace the profile image. */
    public function upload_avatar()
    {
        $user = $this->requireLogin();
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); redirect('/account#profile'); return; }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            $stored = \AIWorkforce\ProfileImage::store(is_array($_FILES['avatar'] ?? null) ? $_FILES['avatar'] : [], (int) $user['id']);
            if (empty($stored['ok'])) {
                $this->flash('error', (string) ($stored['error'] ?? 'The profile picture could not be uploaded. Please use a JPG, PNG or WebP image under the allowed file size.'));
                redirect('/account#profile'); return;
            }
            $path = (string) $stored['path'];
            $previous = (string) ($user['profile_image'] ?? '');
            $this->AIWorkforce_model->identity->updateUser((int) $user['id'], ['profile_image' => $path]);
            $fresh = $this->AIWorkforce_model->identity->findUserById((int) $user['id']);
            if (!$fresh || (string) ($fresh['profile_image'] ?? '') !== $path) {
                \AIWorkforce\ProfileImage::deletePublicPath($path);
                log_message('error', 'upload_avatar: database path was not saved for user ' . (int) $user['id']);
                $this->flash('error', 'Unable to save your changes. Please try again.');
                redirect('/account#profile'); return;
            }
            if ($previous !== '' && $previous !== $path) {
                \AIWorkforce\ProfileImage::deletePublicPath($previous);
            }
            $this->AIWorkforce_model->audit->emit('USER_UPDATED', 'User changed their profile image', ['userId' => (int) $user['id']], (string) $user['id']);
            $this->reestablishIdentity((int) $user['id']);
            $this->flash('notice', '✓ Changes saved successfully');
        } catch (Throwable $e) {
            log_message('error', 'upload_avatar failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
        }
        redirect('/account#profile');
    }

    /** Dashboard → My Account → Profile: remove the profile image (reset to default). */
    public function remove_avatar()
    {
        $user = $this->requireLogin();
        if (!$this->validAuthCsrf()) { $this->flash('error', 'Your session expired. Please try again.'); redirect('/account'); return; }
        try {
            \AIWorkforce\IdentitySchema::ensure($this->db);
            $previous = (string) ($user['profile_image'] ?? '');
            $this->AIWorkforce_model->identity->updateUser((int) $user['id'], ['profile_image' => null]);
            \AIWorkforce\ProfileImage::deletePublicPath($previous);
            $this->reestablishIdentity((int) $user['id']);
            $this->flash('notice', '✓ Changes saved successfully');
        } catch (Throwable $e) {
            log_message('error', 'remove_avatar failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
        }
        redirect('/account#profile');
    }

    /** Reload the signed-in user from the DB and refresh the session identity. */
    private function reestablishIdentity(int $userId): void
    {
        $fresh = $this->AIWorkforce_model->identity->findUserById($userId);
        if (!$fresh) return;
        $fresh['permissions'] = $this->AIWorkforce_model->identity->permissionsForUser($userId);
        $fresh = \AIWorkforce\IdentitySchema::stripSecrets($fresh);
        try { $this->session->sess_regenerate(true); }
        catch (Throwable $e) { log_message('error', 'session regenerate failed: ' . $e->getMessage()); }
        $this->session->set_userdata(['identity' => $fresh, 'csrf_token' => bin2hex(random_bytes(32))]);
    }

    /** Username policy: 3–20 chars, letters/numbers/underscore, must start with a letter. */
    private function validUsername(string $username): bool
    {
        return (bool) preg_match('/^[a-z][a-z0-9_]{2,19}$/', $username);
    }

    private function establishSession(array $user): void
    {
        $this->session->sess_regenerate(true);
        $this->session->set_userdata(['identity' => $user, 'csrf_token' => bin2hex(random_bytes(32)), 'login_attempts' => 0, 'login_locked_until' => 0]);
    }

    private function renderAuth(bool $admin): void
    {
        // Offline dev preview only: the WASM bridge injects the demo operator's
        // credentials (index.php bridge block) so the preview is always usable.
        // Production never sets these variables, so the hint never renders there.
        $demoHint = null;
        $demoEmail = getenv('AI_WORKFORCE_DEMO_ADMIN_EMAIL');
        $demoPassword = getenv('AI_WORKFORCE_DEMO_ADMIN_PASSWORD');
        if (is_string($demoEmail) && $demoEmail !== '' && is_string($demoPassword) && $demoPassword !== '') {
            $demoHint = ['email' => $demoEmail, 'password' => $demoPassword];
        }
        $this->load->view('auth/login', [
            'title' => $admin ? 'Administrator sign in' : 'User sign in',
            'admin' => $admin,
            'error' => $this->consumeFlash('error'),
            'notice' => $this->consumeFlash('notice'),
            'csrfToken' => $this->ensureVisitorCsrf(),
            'demoHint' => $demoHint,
        ]);
    }

    /** CSRF for signed-out visitors: mint one for the session on first render. */
    private function ensureVisitorCsrf(): string
    {
        $token = (string) $this->session->userdata('csrf_token');
        if ($token === '') {
            $token = bin2hex(random_bytes(32));
            $this->session->set_userdata('csrf_token', $token);
        }
        return $token;
    }

    /** Verify the csrf_token posted by an auth form against the session. */
    private function validAuthCsrf(): bool
    {
        $token = (string) $this->input->post('csrf_token');
        $known = (string) $this->session->userdata('csrf_token');
        return $token !== '' && $known !== '' && hash_equals($known, $token);
    }

    private function renderPage(string $title, string $active, array $data = []): void
    {
        $state = ['tradingMode' => 'ANALYSIS_ONLY', 'killSwitch' => ['active' => true]];
        try { $state = $this->platform->state(); } catch (Throwable $e) { log_message('error', 'account state failed: ' . $e->getMessage()); }
        $data = array_merge($data, [
            'title' => $title, 'active' => $active,
            // No live provider health probes here: the layout header never
            // renders them and each probe is a blocking outbound HTTP call.
            // Live health stays available via /api/market-data/* endpoints.
            'status' => ['tradingMode' => $state['tradingMode'], 'killSwitch' => $state['killSwitch'], 'providers' => []],
            'notice' => $this->consumeFlash('notice'), 'error' => $this->consumeFlash('error'),
        ]);
        $this->load->view('layout/header', $data); $this->load->view('auth/account', $data); $this->load->view('layout/footer');
    }

    private function sessionUser(): ?array { return $this->currentUser(); }
    private function redirectLogin(bool $admin): void { redirect($admin ? '/admin/login' : '/login'); }
    private function flash(string $key, string $value): void { $this->session->set_flashdata($key, $value); }
    private function consumeFlash(string $key): ?string { $value = $this->session->flashdata($key); return is_string($value) && $value !== '' ? $value : null; }
}
