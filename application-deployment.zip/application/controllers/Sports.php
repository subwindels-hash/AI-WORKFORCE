<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/MY_Controller.php';

/**
 * Sports Intelligence console (integration plan step 6 — dashboards,
 * responsive UI).
 *
 * Traditional MVC pages that render the same stored data the permissioned
 * JSON API exposes (no data fabrication in either path). Read pages are open
 * like the rest of the console; mutation actions enforce the sports RBAC
 * matrix (sports.approve / sports.settle) from the signed-in identity — the
 * same permission checks the API enforces, and the odds prediction ticket stays audited with
 * the acting user.
 */
class Sports extends MY_Controller
{
    /** Signed-in identity for this request, or null for a logged-out visitor. */
    protected ?array $identity = null;

    public function __construct()
    {
        parent::__construct();
        // Read pages render for everyone; logged-out visitors get the page
        // shell plus an in-page sign-in prompt. Mutations still enforce the
        // sports RBAC matrix per request.
        $this->identity = $this->optionalLogin();
    }

    /** Renders the sign-in gate inside the page shell when nobody is signed in. */
    private function gateGuest(string $title): bool
    {
        if ($this->identity !== null) return false;
        $data = $this->base($title, 'sports');
        $data['signInUrl'] = $this->signInUrl('/sports');
        $data['gateTitle'] = 'Sign in to view Sports Intelligence';
        $this->load->view('layout/header', $data);
        $this->load->view('partials/signin_gate', $data);
        $this->load->view('layout/footer');
        return true;
    }

    public function index()
    {
        if ($this->gateGuest('Sports Intelligence')) return;
        $data = $this->base('Sports Intelligence', 'sports');
        $get = $this->input->get(NULL, true) ?: [];
        $notes = [];
        // The day the console reports (?date=YYYY-MM-DD, default today). A
        // typo'd date must not be answered with a silently different day: the
        // page shows the fallback day, and says that is what it did and why.
        $date = \AIWorkforce\Football\RequestParams::date($get, 'date', $this->ticketToday(), $notes);
        if ($notes !== []) $data['notice'] = trim(implode(' ', array_filter([(string) ($data['notice'] ?? ''), ...$notes])));
        $data['date'] = $date;
        $data['yesterday'] = gmdate('Y-m-d', strtotime($date . ' -1 day'));
        $data['tomorrow'] = gmdate('Y-m-d', strtotime($date . ' +1 day'));
        $data['isToday'] = ($date === $this->ticketToday());
        $data['dashboard'] = $this->platform->sports->dashboard($date);
        $this->render('sports/index', $data);
    }

    public function tickets()
    {
        if ($this->gateGuest('🎯 Odds Prediction Tickets')) return;
        $data = $this->base('🎯 Odds Prediction Tickets', 'sports');
        $data['tickets'] = $this->platform->model->sports->listTickets([], 100);
        $data['dailyRuns'] = $this->platform->model->sports->listDailyTickets(30);
        $data['performance'] = $this->platform->sports->performanceReport([]);
        // Today's AI ticket hero: the stored daily run for today plus its
        // ticket and selections. Viewing never generates anything — when no
        // run or ticket exists the hero degrades to an honest empty state.
        $today = $this->ticketToday();
        $todayRun = null;
        $todayTicket = null;
        $todaySelections = [];
        try {
            $todayRun = $this->platform->model->sports->findDailyTicket($today);
            $ticketId = is_array($todayRun) ? (string) ($todayRun['ticket_id'] ?? '') : '';
            if ($ticketId !== '') {
                $todayTicket = $this->platform->model->sports->findTicket($ticketId);
                if ($todayTicket !== null) {
                    $todaySelections = $this->platform->model->sports->ticketSelections($ticketId);
                    foreach ($todaySelections as &$selection) {
                        $match = $this->platform->model->sports->findMatchById((int) ($selection['match_id'] ?? 0));
                        if ($match !== null) {
                            $selection['competition'] = $match['competition'] ?? null;
                            $selection['kickoff_time'] = $selection['kickoff_time'] ?? $match['kickoff_at'] ?? null;
                            $selection['home_team'] = $selection['home_team'] ?? $match['home_team'] ?? null;
                            $selection['away_team'] = $selection['away_team'] ?? $match['away_team'] ?? null;
                            // Legacy selections (recorded before the crest
                            // columns existed) fall back to the stored
                            // fixture payload — never guessed for rows that
                            // still have neither.
                            if (empty($selection['home_team_logo']) || empty($selection['away_team_logo'])) {
                                $payload = is_array($match['payload'] ?? null) ? $match['payload'] : [];
                                $selection['home_team_logo'] = $selection['home_team_logo'] ?? ($payload['homeTeamLogo'] ?? null);
                                $selection['away_team_logo'] = $selection['away_team_logo'] ?? ($payload['awayTeamLogo'] ?? null);
                            }
                        }
                        // Market reaction as it stood WHEN THE PICK WAS MADE.
                        // Read back from the decision record rather than
                        // recomputed from today's observations, so the row
                        // shows the evidence the model actually used and can
                        // never drift from it after the fact. Absent or
                        // unreadable factors leave it null — the view then
                        // says "not measured", never a fabricated STABLE.
                        $selection['movement'] = null;
                        $predictionId = (string) ($selection['prediction_id'] ?? '');
                        if ($predictionId !== '') {
                            try {
                                $prediction = $this->platform->model->sports->findPrediction($predictionId);
                                $factors = is_array($prediction) ? ($prediction['factors'] ?? null) : null;
                                if (is_array($factors) && is_array($factors['movement'] ?? null)) {
                                    $selection['movement'] = $factors['movement'];
                                }
                            } catch (Throwable $e) { /* the pick still renders without it */ }
                        }
                    }
                    unset($selection);
                }
            }
        } catch (Throwable $e) { /* hero degrades to "not generated" */ }
        $data['todayIso'] = $today;
        $data['todayRun'] = $todayRun;
        $data['todayTicket'] = $todayTicket;
        $data['todaySelections'] = $todaySelections;
        $this->render('sports/tickets', $data);
    }

    /** Configured-local calendar date used by the daily ticket scheduler. */
    private function ticketToday(): string
    {
        try {
            $config = $this->platform->sports->configuration->active();
            return \AIWorkforce\Sports\DailyTicketDate::today((string) ($config['system_timezone'] ?? 'UTC'));
        } catch (Throwable $e) {
            return \AIWorkforce\Sports\DailyTicketDate::today('UTC');
        }
    }

    /**
     * Sports capabilities of the signed-in identity, read fresh from the
     * database. The console uses these to show only the controls the identity
     * can actually use, instead of offering a button that fails on submit.
     *
     * @return array{sync: bool, approve: bool, settle: bool}
     */
    private function sportsCaps(): array
    {
        $user = $this->refreshIdentityPermissions($this->identity);
        $can = fn(string $permission): bool => $user !== null && $this->platform->identity->can($user, $permission);
        return ['sync' => $can('sports.manage'), 'approve' => $can('sports.approve'), 'settle' => $can('sports.settle')];
    }

    /** Approve / reject a PENDING_USER_APPROVAL odds prediction ticket (sports.approve). */
    public function decide(string $id)
    {
        if (!$this->requireSportsPermission('sports.approve', 'approve/reject')) return;
        // Kill switch scope: sports odds-prediction tickets are NOT an
        // order-bound surface (no broker, no money movement in this
        // deployment), so an engaged trading kill switch does not gate
        // approval or settlement here. Governance is RBAC (sports.approve).
        $approve = $this->input->post('approve') === '1';
        $reason = trim((string) $this->input->post('reason'));
        try {
            $this->platform->sports->governance->decide($id, $approve, $this->actor(), $reason);
            $this->flash('notice', 'Odds prediction ticket ' . ($approve ? 'approved' : 'rejected') . ' and audited — no external execution exists in this deployment.');
        } catch (Throwable $e) {
            $this->flash('error', $e->getMessage());
        }
        redirect('/sports/odds-prediction-ticket');
    }

    /** Settle an odds prediction ticket from stored verified results (sports.settle). */
    public function settle(string $id)
    {
        if (!$this->requireSportsPermission('sports.settle', 'settle')) return;
        try {
            $out = $this->platform->sports->settlement->settlePending($id);
            $this->flash('notice', sprintf('Odds prediction ticket settlement: %s (effective odds %s, P/L %s)',
                $out['status'] ?? 'PENDING', $out['effectiveOdds'] ?? 'n/a', $out['pnl'] ?? 'n/a'));
        } catch (Throwable $e) {
            $this->flash('error', $e->getMessage());
        }
        redirect('/sports/odds-prediction-ticket');
    }

    /**
     * Generate an odds prediction ticket from stored fixtures/odds (sports.manage).
     * Browser-accessible equivalent of POST /api/sports/ticket-engine/run for
     * operators without CLI/cron access. DailyTicketService reuses stored
     * fixtures/odds/predictions first and refreshes only missing or stale data,
     * then applies every calibration/value/confidence/risk/correlation gate.
     * Persisted ticket identity is idempotent per (ticket type, local date).
     */
    public function generate_ticket()
    {
        if ($this->input->method(true) !== 'POST') { redirect('/sports'); return; }
        if (!$this->requireSportsPermission('sports.manage', 'generate odds prediction ticket')) return;
        @set_time_limit(180);
        $date = trim((string) $this->input->post('date'));
        // Spec §21: an explicitly supplied date is honoured or refused — never
        // silently swapped for today. Only an ABSENT date means "today".
        if ($date === '') {
            $date = $this->ticketToday();
        } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            $this->flash('error', 'Generation refused: ' . mb_substr($date, 0, 40) . ' is not a valid date (expected YYYY-MM-DD). Nothing was generated.');
            redirect('/sports');
            return;
        } else {
            [$dateY, $dateM, $dateD] = array_map('intval', explode('-', $date));
            if (!checkdate($dateM, $dateD, $dateY)) {
                $this->flash('error', 'Generation refused: ' . $date . ' is not a real calendar date. Nothing was generated.');
                redirect('/sports');
                return;
            }
        }
        // force=1 clears the day's ACTIVE candidate state (no old pass odds can
        // be carried forward) before a clean regeneration runs.
        $force = (bool) $this->input->post('force');
        // refresh=1 rebuilds the day's ticket from current odds: the existing
        // PENDING ticket is superseded and a new one generated. An APPROVED
        // ticket is never replaced — the service refuses and returns it
        // unchanged — so this can never cancel a bet the operator has taken.
        $refresh = (bool) $this->input->post('refresh');
        $sports = $this->platform->sports;
        try {
            // Spec §1/§5: ONE service, and the run is attributed to the
            // administrator who clicked Generate — never a blanket 'system'.
            $options = ['actor' => $this->actor()];
            if ($force) $options['force'] = true;
            // A refresh implies a fresh provider cycle: rebuilding from the
            // odds we already stored would just reproduce the same ticket.
            if ($refresh) { $options['refresh'] = true; $options['force'] = true; }
            $result = \AIWorkforce\Sports\GenerationResult::fromRunDaily(
                $sports->dailyTickets->runDaily($date, null, $options)
            );
            if (($result['status'] ?? '') === 'RESET_FAILED') {
                $this->flash('error', $result['message'] ?? 'Candidate reset failed');
                redirect('/sports?date=' . urlencode($date));
                return;
            }
        } catch (Throwable $e) {
            $this->flash('error', 'Odds prediction ticket generation failed: ' . mb_substr($e->getMessage(), 0, 300));
            redirect('/sports');
            return;
        }
        // Canonical contract fields only (spec §1) — the same array the API
        // returns, so the two surfaces can never disagree about an outcome.
        $status = (string) ($result['status'] ?? 'UNKNOWN');
        $ticketId = $result['ticketId'] ?? null;
        $evaluated = (int) ($result['fixturesEvaluated'] ?? 0);
        $recorded = (int) ($result['predictionsGenerated'] ?? 0);
        $rejections = (int) ($result['rejections'] ?? 0);
        $message = (string) ($result['message'] ?? '');

        if ($status === 'GENERATION_IN_PROGRESS') {
            $this->flash('notice', 'Odds prediction ticket generation is already in progress for ' . $date . '. Refresh shortly; no duplicate worker was started.');
            redirect('/sports/odds-prediction-ticket?date=' . urlencode($date));
            return;
        }
        // Spec §20: a ticket that already exists for this date is reported as
        // DUPLICATE_SKIPPED. Nothing is regenerated and no row is duplicated.
        if ($status === 'DUPLICATE_SKIPPED') {
            $this->flash('notice', sprintf(
                'TICKET ALREADY GENERATED — Ticket ID %s for %s. Generation: already completed; no duplicate ticket or prediction rows were created.',
                (string) $ticketId, $date));
            redirect('/sports/odds-prediction-ticket?date=' . urlencode($date));
            return;
        }
        if ($ticketId) {
            $msg = sprintf('🎯 ODDS PREDICTION TICKET GENERATED — Ticket ID %s for %s — status %s, %d fixtures evaluated, %d predictions, %d qualified candidates, %d selected picks. %s',
                $ticketId, $date, $status, $evaluated, $recorded,
                (int) ($result['qualifiedCandidates'] ?? 0), (int) ($result['selectedPicks'] ?? 0), $message);
            $this->flash('notice', $msg);
            redirect('/sports/odds-prediction-ticket?date=' . urlencode($date));
            return;
        }
        // Spec §8/§18: no provider configured is NOT a prediction outcome.
        if ($status === 'NO_PROVIDER') {
            $this->flash('error', sprintf('NO TICKET for %s — STATUS: NO_PROVIDER. SPORTS DATA PROVIDER NOT CONFIGURED — fixtures UNAVAILABLE, odds UNAVAILABLE, prediction engine WAITING FOR DATA. Configure a sports data provider (see Data feed), then run again — the day stays retryable.', $date));
            redirect('/sports?date=' . $date);
            return;
        }
        if ($status === 'DATA_UNAVAILABLE') {
            // Every provider failed: a data outage, reported as such — never as "no qualified games".
            $ledger = [];
            foreach ((array) ($result['providerStatuses'] ?? []) as $pid => $st) $ledger[] = $pid . ': ' . $st;
            $this->flash('error', sprintf('NO TICKET for %s — STATUS: DATA_UNAVAILABLE. Sports data temporarily unavailable: all configured sports-data providers failed (%s). No ticket was generated because verified data was unavailable. Fix or wait for the providers (see Data feed), then run again — the day stays retryable.',
                $date, $ledger ? implode('; ', $ledger) : 'no detail'));
            redirect('/sports?date=' . $date);
            return;
        }
        // Spec §19: providers answered correctly but the day had no fixtures.
        if ($status === 'NO_FIXTURES') {
            $this->flash('notice', sprintf('NO TICKET for %s — STATUS: NO_FIXTURES. The provider answered successfully but returned no fixtures for this date. Nothing was fabricated and the day stays retryable.', $date));
            redirect('/sports?date=' . $date);
            return;
        }
        // No record qualified — still a valid outcome (spec §3).
        // The engine's own message already carries a "(N evaluated, … funnel: …)"
        // breakdown; repeating the status code, the counts and the funnel here
        // produced the unreadable triple-printed flash. Each fact is stated once.
        $hasFunnel = stripos($message, 'funnel:') !== false;
        $hasCounts = (bool) preg_match('/\(\d+ evaluated,/', $message);
        // Spec §17: a NO_QUALIFIED_TICKET day must explain itself with the
        // real, labelled gate breakdown — never a bare "no ticket generated".
        $summary = '';
        if (!empty($result['gateFailures']) && is_array($result['gateFailures'])) {
            $parts = [];
            foreach ($result['gateFailures'] as $gate) {
                $parts[] = (string) $gate['label'] . ': ' . (int) $gate['count'];
            }
            if ($parts) $summary = ' Rejection breakdown — ' . implode(', ', array_slice($parts, 0, 10)) . '.';
        }
        // Diagnostic funnel — which pipeline stage eliminated the candidates.
        $funnel = '';
        $diag = $result['diagnostics'] ?? [];
        if (!$hasFunnel && is_array($diag) && !empty($diag['fixturesEvaluated'])) {
            $funnel = sprintf(
                ' Funnel: %d evaluated → %d eligible → %d fresh-odds → %d sufficient-data fixtures → %d predictions → %d confidence-qualified → %d positive-value → %d risk-qualified → %d final.',
                (int) ($diag['fixturesEvaluated'] ?? 0),
                (int) ($diag['eligibleFixtures'] ?? 0),
                (int) ($diag['fixturesWithFreshOdds'] ?? 0),
                (int) ($diag['sufficientDataFixtures'] ?? 0),
                (int) ($diag['predictionsGenerated'] ?? 0),
                (int) ($diag['confidenceQualifiedCandidates'] ?? 0),
                (int) ($diag['positiveValueCandidates'] ?? 0),
                (int) ($diag['riskQualifiedCandidates'] ?? 0),
                (int) ($diag['finalQualifiedCandidates'] ?? 0)
            );
        }
        // "NO_QUALIFIED_TICKET: NO QUALIFIED TICKET — …" said the same thing
        // twice: the status code is only shown when the message does not
        // already state the outcome in words.
        $headline = $message !== '' ? $message : $status;
        if ($message !== '' && $status !== 'NO_QUALIFIED_TICKET') $headline = $status . ': ' . $message;
        $counts = $hasCounts ? '' : sprintf(' (%d fixtures evaluated, %d eligible, %d predictions, %d fresh odds, %d stale odds, %d qualified candidates, %d selected picks, %d rejections)',
            $evaluated, (int) ($result['eligibleFixtures'] ?? 0), $recorded,
            (int) ($result['freshOdds'] ?? 0), (int) ($result['staleOdds'] ?? 0),
            (int) ($result['qualifiedCandidates'] ?? 0), (int) ($result['selectedPicks'] ?? 0), $rejections);
        $msg = sprintf('No qualified odds prediction ticket for %s — %s%s.%s%s',
            $date, $headline, $counts, $summary, $funnel);
        if ($status === 'NO_QUALIFIED_TICKET') {
            $this->flash('notice', $msg);
        } else {
            $this->flash('error', $msg);
        }
        // Land back on the day that was generated for, not on today.
        redirect('/sports?date=' . $date);
    }

    /**
     * Invalidate the day's ACTIVE odds-prediction candidate state without
     * regenerating (sports.manage): deletes un-settled predictions of upcoming
     * fixtures, supersedes the PENDING ticket and clears the daily slot, and
     * purges unquotable odds rows. Settled/historical records and verified
     * results are preserved. The next generation then starts from a clean
     * pool — an old pass can never leak through via cached candidates.
     */
    public function reset_candidates()
    {
        if ($this->input->method(true) !== 'POST') { redirect('/sports'); return; }
        if (!$this->requireSportsPermission('sports.manage', 'reset active candidates')) return;
        $date = trim((string) $this->input->post('date'));
        if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = $this->ticketToday();
        $to = gmdate('Y-m-d', strtotime($date . ' +1 day'));
        try {
            $counts = $this->platform->model->sports->invalidateActiveCandidates($date, $to, true);
            $this->flash('notice', sprintf(
                'Active candidate state cleared for %s..%s: %d predictions removed, %d pending ticket(s) superseded (%d legs), %d daily slot(s) cleared, %d unquotable odds row(s) purged. Settled/historical records preserved.',
                $date, $to, $counts['predictionsDeleted'], $counts['ticketsSuperseded'], $counts['selectionsDeleted'], $counts['dailySlotsCleared'], $counts['invalidOddsDeleted']));
        } catch (Throwable $e) {
            $this->flash('error', 'Active candidate reset failed: ' . mb_substr($e->getMessage(), 0, 300));
        }
        redirect('/sports?date=' . urlencode($date));
    }

    /**
     * Pull fresh data from the configured sports providers (sports.manage).
     * Browser-accessible equivalent of the cron sweep for operators without
     * CLI/cron access: fixtures for today+tomorrow, a bounded odds/results
     * refresh, quality recalc and the daily odds prediction ticket run. Bounded so a first
     * pull cannot exhaust a free-tier daily quota or PHP's time limit.
     */
    public function sync()
    {
        if ($this->input->method(true) !== 'POST') { redirect('/sports'); return; }
        if (!$this->requireSportsPermission('sports.manage', 'sync')) return;
        @set_time_limit(180);
        $sports = $this->platform->sports;
        $date = $this->ticketToday();
        $tomorrow = gmdate('Y-m-d', strtotime($date . ' +1 day'));
        $providers = $sports->providers->all();
        if (!$providers) {
            $this->flash('error', 'No sports provider is registered. Add a provider key (API-Football, TheSportsDB or SportMonks) via Admin → API or the WINDELS_*_KEY variables in .env, then sync again.');
            redirect('/sports');
            return;
        }
        $stamp = gmdate('YmdHis');
        $fixtures = 0; $created = 0; $errors = [];
        foreach ($providers as $provider) {
            try {
                $cfg = $sports->configuration->active();
                $r = $sports->sync->syncFixtures($provider, [
                    'from' => $date, 'to' => $tomorrow,
                    'timezone' => (string) ($cfg['system_timezone'] ?? 'UTC'),
                    'limit' => 50, 'page' => 1,
                ], 'web-sync:fixtures:' . $date . ':' . $provider->id() . ':' . $stamp);
            } catch (Throwable $e) {
                $r = ['status' => 'FAILED', 'errors' => [mb_substr($e->getMessage(), 0, 200)]];
            }
            $fixtures += (int) ($r['processed'] ?? 0);
            $created += (int) ($r['created'] ?? 0);
            foreach (array_slice((array) ($r['errors'] ?? []), 0, 3) as $err) $errors[] = $provider->id() . ': ' . mb_substr((string) $err, 0, 160);
        }
        $oddsDone = $this->syncWebOdds($sports, $date, $stamp, $errors);
        $resultsDone = $this->syncWebResults($sports, $date, $stamp, $errors);
        $ticketStatus = null;
        try {
            $cron = new \AIWorkforce\Sports\SportsCronService($this->AIWorkforce_model->sports, $this->AIWorkforce_model->audit, $sports);
            $cron->run('quality', $date);
            $ticket = $cron->run('ticket', $date);
            $ticketStatus = (string) ($ticket['status'] ?? '');
        } catch (Throwable $e) {
            $errors[] = 'record: ' . mb_substr($e->getMessage(), 0, 160);
        }
        if ($fixtures > 0 || $created > 0 || $oddsDone > 0 || $resultsDone > 0) {
            $msg = sprintf('Sync complete: %d fixture(s) pulled (%d new), odds refreshed for %d, results checked for %d.', $fixtures, $created, $oddsDone, $resultsDone);
            if ($ticketStatus !== null && $ticketStatus !== '') $msg .= ' Odds prediction ticket engine: ' . $ticketStatus . '.';
            if ($errors) $msg .= ' ' . count($errors) . ' warning(s) — see Data feed below.';
            $this->flash('notice', $msg);
        } else {
            $first = $errors ? ' First error: ' . mb_substr((string) $errors[0], 0, 200) : ' The providers returned no fixtures for ' . $date . '–' . $tomorrow . '.';
            $this->flash('error', 'Sync pulled nothing.' . $first);
        }
        redirect('/sports');
    }

    /** Refresh odds for today's scheduled matches, bounded for web use. */
    private function syncWebOdds(\AIWorkforce\Sports\SportsIntelligence $sports, string $date, string $stamp, array &$errors): int
    {
        $done = 0;
        $config = $sports->configuration->active();
        $window = \AIWorkforce\Sports\DailyTicketDate::utcWindow($date, (string) ($config['system_timezone'] ?? 'UTC'));
        $end = gmdate('Y-m-d\TH:i:sP', $window['endTimestamp'] - 1);
        $matches = $this->AIWorkforce_model->sports->listMatches(['from' => $window['start'], 'to' => $end, 'status' => 'SCHEDULED'], 1000);
        $sources = $this->AIWorkforce_model->sports->listProviders();
        $attempted = 0;
        foreach ($matches as $match) {
            if ($attempted >= \AIWorkforce\Sports\SportsCronService::ODDS_BATCH_SIZE) break;
            $provider = $this->webProviderById($sports, $sources, (int) $match['provider_id']);
            if ($provider === null) continue;
            // Reuse valid odds. The web action advances through stale/missing
            // rows in controlled 50-fixture batches instead of repeatedly
            // burning quota on the first arbitrary 40 rows.
            $latest = $this->AIWorkforce_model->sports->latestOdds((int) $match['id']);
            $maxAge = \AIWorkforce\Sports\OddsFreshnessEngine::maxAgeFor($latest['market'] ?? null, $provider->id());
            $observed = $latest ? strtotime((string) ($latest['observed_at'] ?? '')) : false;
            if ($observed !== false && time() - $observed <= $maxAge) continue;
            $attempted++;
            try {
                $r = $sports->sync->syncOdds($provider, (string) $match['external_id'], 'web-sync:odds:' . (int) $match['id'] . ':' . $date . ':' . $stamp);
                if (($r['status'] ?? '') === 'COMPLETED') $done++;
                elseif (!empty($r['errors'][0]) && count($errors) < 6) $errors[] = $provider->id() . ' odds: ' . mb_substr((string) $r['errors'][0], 0, 160);
            } catch (Throwable $e) {
                if (count($errors) < 6) $errors[] = $provider->id() . ' odds: ' . mb_substr((string) $e->getMessage(), 0, 160);
            }
        }
        return $done;
    }

    /** Check results for recent matches that have none stored, bounded for web use. */
    private function syncWebResults(\AIWorkforce\Sports\SportsIntelligence $sports, string $date, string $stamp, array &$errors): int
    {
        $done = 0;
        $since = gmdate('Y-m-d', strtotime($date . ' -2 days')) . 'T00:00:00+00:00';
        $matches = $this->AIWorkforce_model->sports->listMatches(['from' => $since, 'to' => $date . 'T23:59:59+00:00'], 200);
        $sources = $this->AIWorkforce_model->sports->listProviders();
        $checked = 0;
        foreach ($matches as $match) {
            if ($checked >= 40) break;
            if ($this->AIWorkforce_model->sports->findResultByMatch((int) $match['id']) !== null) continue;
            $provider = $this->webProviderById($sports, $sources, (int) $match['provider_id']);
            if ($provider === null) continue;
            $checked++;
            try {
                $r = $sports->sync->syncResults($provider, (string) $match['external_id'], 'web-sync:results:' . (int) $match['id'] . ':' . $date . ':' . $stamp);
                if (($r['status'] ?? '') === 'COMPLETED') $done++;
                elseif (!empty($r['errors'][0]) && count($errors) < 6) $errors[] = $provider->id() . ' results: ' . mb_substr((string) $r['errors'][0], 0, 160);
            } catch (Throwable $e) {
                if (count($errors) < 6) $errors[] = $provider->id() . ' results: ' . mb_substr((string) $e->getMessage(), 0, 160);
            }
        }
        return $done;
    }

    private function webProviderById(\AIWorkforce\Sports\SportsIntelligence $sports, array $sources, int $id): ?\AIWorkforce\Sports\Providers\SportsDataProvider
    {
        foreach ($sources as $p) if ((int) $p['id'] === $id) return $sports->providers->provider((string) $p['provider_code']);
        return null;
    }

    /**
     * Enforce the sports RBAC matrix + production guards for console
     * mutations (PRG flow). Plan step 6 (production review): form POSTs
     * self-guard with the session CSRF token issued at sign-in — the same
     * token the JSON API verifies as the X-CSRF-Token header, since
     * platform-wide csrf_protection is off and privileged endpoints guard
     * themselves.
     */
    private function requireSportsPermission(string $permission, string $action): bool
    {
        // A logged-out visitor cannot perform a mutation: send them to sign in
        // and return to the sports console afterwards, rather than showing a
        // permission-refusal that implies they merely lack a role.
        if ($this->identity === null && $this->currentUser() === null) {
            $this->session->set_userdata('return_to', '/sports');
            redirect('/login');
            return false;
        }
        // Read permissions from the database: a role granted after sign-in
        // applies immediately instead of waiting for the next sign-in.
        $user = $this->refreshIdentityPermissions($this->identity);
        if (!is_array($user) || !$this->platform->identity->can($user, $permission)) {
            $this->flash('error', "Refused: signed-in identity lacks '{$permission}' — the {$action} action was not performed."
                . " Ask an administrator to assign a role that carries '{$permission}' (Sports administrator for the sports console), then retry — permissions are re-read from the database on every action, so no sign-out is needed.");
            redirect('/sports');
            return false;
        }
        $sent = (string) $this->input->post('csrf_token');
        $known = $this->session->userdata('csrf_token');
        if ($sent === '' || !is_string($known) || $known === '' || !hash_equals($known, $sent)) {
            $this->flash('error', "Refused: missing or invalid CSRF token — the {$action} action was not performed.");
            redirect('/sports');
            return false;
        }
        return true;
    }

    private function actor(): string
    {
        $user = $this->refreshIdentityPermissions($this->identity);
        return is_array($user) ? (string) $user['id'] : 'anonymous';
    }

    private function base(string $title, string $active): array
    {
        $state = $this->platform->state();
        return [
            'title' => $title, 'active' => $active,
            'csrfToken' => (string) $this->session->userdata('csrf_token'),
            'caps' => $this->sportsCaps(),
            'status' => ['tradingMode' => $state['tradingMode'], 'killSwitch' => $state['killSwitch'],
                // Deliberately NOT calling providers->getAllHealth() here: it
                // probes every trading provider (Binance, Kraken, Alpaca, OANDA
                // ...) over the network on each render, ~5s of blocking TTFB on
                // this page alone. The layout header only reads tradingMode and
                // killSwitch, and the sports feed-health table is fed by
                // $sys['providers'] from dashboard()'s systemStatus (stored
                // provider health), so nothing on screen loses data.
                // Live trading-provider health stays at /api/market-data/*.
                'providers' => []],
            'notice' => $this->flashGet('notice'), 'error' => $this->flashGet('error'),
        ];
    }

    private function render(string $view, array $data): void
    {
        $this->load->view('layout/header', $data);
        $this->load->view($view, $data);
        $this->load->view('layout/footer');
    }

    private function flash(string $key, string $msg): void
    {
        setcookie("flash_{$key}", rawurlencode($msg), time() + 30, '/');
    }

    private function flashGet(string $key): ?string
    {
        $v = $_COOKIE["flash_{$key}"] ?? null;
        if ($v !== null) setcookie("flash_{$key}", '', time() - 3600, '/');
        return $v !== null ? rawurldecode($v) : null;
    }
}
