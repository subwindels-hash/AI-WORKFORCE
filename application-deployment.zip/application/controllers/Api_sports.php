<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Sports Intelligence JSON API (spec §25/§26/§34).
 *
 * Authorization follows the existing WINDELS RBAC:
 *   - status                      public (no secrets, no PII)
 *   - read endpoints              sports.view
 *   - configuration / jobs /
 *     calibrations / backtests /  sports.manage  (+ native session + CSRF)
 *     provider toggles
 *   - ticket decide               sports.approve
 *   - results verify / settle     sports.settle
 */
class Api_sports extends Api_controller
{
    /** Season-level top-player lists change a few times a week; cache them to
     * protect the provider's daily request quota from repeated UI loads. */
    private const TOP_PLAYERS_CACHE_TTL = 900;
    /** @var array<string,array{at:int,data:array}> */
    private static array $topPlayersCache = [];

    // ---------------------------------------------------------------- public
    public function status()
    {
        $this->json($this->platform->sports->status());
    }

    // ------------------------------------------------------------- read-only
    public function dashboard()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $this->json($this->platform->sports->dashboard());
    }

    public function performance()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $allowed = ['from', 'to', 'status', 'modelVersionId'];
        $filter = array_intersect_key($this->input->get(NULL, true) ?: [], array_flip($allowed));
        $this->json($this->platform->sports->performanceReport($filter));
    }

    /**
     * Auto-updating live match board — the goal scores update by themselves.
     * GET /api/sports/live[?refresh=0|1][&since=ISO8601]   (sports.view)
     *
     * Read is always from stored state; with refresh=1 (the default) the
     * endpoint first triggers the throttled live sweep, so a goal lands here
     * automatically at most WINDELS_SPORTS_LIVE_REFRESH_SECONDS after the
     * provider reports it — regardless of how many clients poll, they share
     * one provider request per interval. `since` replays SPORTS_GOAL_SCORED
     * events (at/after that timestamp) for the UI's GOAL flash.
     */
    public function live()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $svc = $this->platform->sports->liveScores;
        $refreshed = null;
        if (!isset($g['refresh']) || (string) $g['refresh'] !== '0') {
            @set_time_limit(60);
            try {
                $refreshed = $svc->refresh();
            } catch (\Throwable $e) {
                $refreshed = ['status' => 'FAILED', 'providers' => [], 'goalEvents' => [], 'errors' => [mb_substr($e->getMessage(), 0, 200)]];
            }
        }
        $since = trim((string) ($g['since'] ?? ''));
        if ($since !== '' && strtotime($since) === false) $since = '';
        $board = $svc->board($since !== '' ? $since : null);
        // A sweep can both return its freshly detected events and have them
        // already audited (then replayed by board()); dedupe by identity so a
        // goal flashes once.
        $seen = [];
        $events = array_values(array_filter(array_merge((array) ($refreshed['goalEvents'] ?? []), (array) $board['goalEvents']), static function ($e) use (&$seen) {
            if (!is_array($e)) return false;
            $key = ($e['matchId'] ?? 0) . ':' . ($e['score']['home'] ?? '?') . '-' . ($e['score']['away'] ?? '?') . ':' . ($e['minute'] ?? '');
            if (isset($seen[$key])) return false;
            $seen[$key] = true;
            return true;
        }));
        $this->json([
            'status' => $board['status'],
            'matches' => $board['matches'],
            'goalEvents' => $events,
            'refreshed' => $refreshed === null ? null : [
                'status' => $refreshed['status'] ?? null,
                'providers' => $refreshed['providers'] ?? [],
                'errors' => $refreshed['errors'] ?? [],
                'retryInSeconds' => $refreshed['retryInSeconds'] ?? null,
            ],
            'refreshIntervalSeconds' => $board['refreshIntervalSeconds'],
            'serverTime' => gmdate('c'),
        ]);
    }


    /** Spec alias: GET /fixtures?date=today returns persisted fixtures for a day. */
    public function fixtures()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $date = (string) ($g['date'] ?? gmdate('Y-m-d'));
        if ($date === 'today') $date = gmdate('Y-m-d');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) return $this->jsonError('date must be YYYY-MM-DD or today');
        $rows = $this->AIWorkforce_model->sports->listMatches(['from' => $date . 'T00:00:00+00:00', 'to' => $date . 'T23:59:59+00:00'], (int) ($g['limit'] ?: 500));
        $fixtures = array_map(fn($m) => [
            'fixture_id' => $m['external_id'] ?? (string) ($m['id'] ?? ''),
            'league_id' => $m['payload']['leagueId'] ?? null,
            'league_name' => $m['competition'] ?? null,
            'home_team' => $m['home_team'] ?? null,
            'away_team' => $m['away_team'] ?? null,
            'kickoff_time' => $m['kickoff_at'] ?? null,
            'fixture_status' => $m['payload']['sourceStatus'] ?? $m['status'] ?? null,
            'timezone' => $m['payload']['timezone'] ?? null,
        ], $rows);
        $this->json(['fixtures' => $fixtures, 'source' => 'database', 'date' => $date]);
    }

    public function matches()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $filter = array_intersect_key($g, array_flip(['status', 'from', 'to', 'competition', 'providerId']));
        $rows = $this->AIWorkforce_model->sports->listMatches($filter, (int) ($g['limit'] ?: 200));
        foreach ($rows as &$row) {
            $row['latestOdds'] = $this->AIWorkforce_model->sports->latestOdds((int) $row['id'], 'TOTAL_GOALS', 'OVER_1_5');
            $row['latestQuality'] = $this->AIWorkforce_model->sports->latestQuality((int) $row['id']);
        }
        $this->json(['matches' => $rows]);
    }

    /** Match intelligence snapshot (spec §8/§28). */
    public function show_match(string $id)
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $match = $this->AIWorkforce_model->sports->findMatchById((int) $id);
        if (!$match) return $this->jsonError('match not found', 404);
        $odds = $this->AIWorkforce_model->sports->latestOdds((int) $id, 'TOTAL_GOALS', 'OVER_1_5');
        $oddsArr = $odds ? ['market' => $odds['market'], 'selection' => $odds['selection'], 'decimalOdds' => (float) $odds['decimal_odds'], 'observedAt' => $odds['observed_at']] : null;
        $intel = $this->platform->sports->matchIntelligence->analyze($match, $oddsArr);
        $preds = $this->AIWorkforce_model->sports->listPredictions(['matchId' => (int) $id], 50);
        $this->json(['match' => $match, 'intelligence' => $intel, 'odds' => $odds, 'predictions' => $preds, 'quality' => $this->AIWorkforce_model->sports->latestQuality((int) $id)]);
    }

    public function odds()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $matchId = $g['matchId'] ?? $g['fixture'] ?? $g['fixture_id'] ?? null;
        if ($matchId === null || $matchId === '') return $this->jsonError('matchId or fixture is required');
        if (!is_numeric($matchId)) {
            $found = null;
            foreach ($this->AIWorkforce_model->sports->listMatches([], 1000) as $m) {
                if ((string) ($m['external_id'] ?? '') === (string) $matchId) { $found = $m; break; }
            }
            if (!$found) return $this->jsonError('fixture not found', 404);
            $matchId = (int) $found['id'];
        }
        $rows = $this->AIWorkforce_model->sports->listOdds((int) $matchId, (int) ($g['limit'] ?: 50));
        $this->json(['odds' => $rows]);
    }

    public function predictions()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $filter = array_intersect_key($g, array_flip(['matchId', 'modelVersionId', 'decision', 'market', 'from', 'to']));
        $this->json(['predictions' => $this->AIWorkforce_model->sports->listPredictions($filter, (int) ($g['limit'] ?: 200))]);
    }

    /** AI decision report: why the AI selected/rejected this (spec §28/§29). */
    public function decision_report(string $id)
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $p = $this->AIWorkforce_model->sports->findPrediction($id);
        if (!$p) return $this->jsonError('prediction not found', 404);
        $match = $this->AIWorkforce_model->sports->findMatchById((int) $p['match_id']);
        $model = $this->AIWorkforce_model->sports->findModelVersion((int) $p['model_version_id']);
        $quality = $this->AIWorkforce_model->sports->latestQuality((int) $p['match_id']);
        $factors = is_array($p['factors']) ? $p['factors'] : [];
        $selection = null;
        foreach ($this->AIWorkforce_model->sports->settledSelections() as $s) {
            if (($s['prediction_id'] ?? '') === $id) { $selection = $s; break; }
        }
        $this->json([
            'predictionId' => $p['id'],
            'match' => $match ? ['homeTeam' => $match['home_team'], 'awayTeam' => $match['away_team'], 'competition' => $match['competition'], 'kickoff' => $match['kickoff_at'], 'status' => $match['status']] : null,
            'market' => $p['market'], 'selection' => $p['selection'],
            'oddsAtPrediction' => $p['odds'] ?? null, 'oddsTimestamp' => $p['odds_timestamp'] ?? null,
            'model' => $model,
            'rawModelProbability' => $p['raw_probability'] ?? null,
            'calibratedProbability' => $p['calibrated_probability'] ?? null,
            'impliedProbability' => $p['implied_probability'] ?? null,
            'expectedValue' => $p['expected_value'] ?? null,
            'confidence' => $p['confidence'] ?? null,
            'risk' => $p['risk'], 'correlation' => $p['correlation'],
            'dataQuality' => $quality ? ['score' => $quality['score'], 'band' => $quality['band'], 'missing' => $quality['missing_fields']] : null,
            'decision' => $p['decision'],
            'rejectionReasons' => $p['rejection_reasons'] ?? [],
            'factors' => $factors,
            'whySelected' => ($p['decision'] ?? '') === 'PREDICTION_READY'
                ? 'Positive expected value between calibrated model probability and market-implied probability, with risk, confidence, data-quality and correlation gates all passed.'
                : 'See rejectionReasons — the engine declined rather than forcing a prediction.',
            'finalResult' => $selection ? ['status' => $selection['status'], 'ticketId' => $selection['ticket_id']] : null,
            'createdAt' => $p['created_at'],
        ]);
    }

    public function tickets()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $filter = array_intersect_key($g, array_flip(['from', 'to', 'status', 'modelVersionId']));
        $tickets = $this->AIWorkforce_model->sports->listTickets($filter, (int) ($g['limit'] ?: 200));
        foreach ($tickets as &$t) $t['selections'] = $this->AIWorkforce_model->sports->ticketSelections((string) $t['id']);
        $this->json(['tickets' => $tickets]);
    }

    public function show_ticket(string $id)
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $t = $this->AIWorkforce_model->sports->findTicket($id);
        if (!$t) return $this->jsonError('ticket not found', 404);
        $selections = $this->AIWorkforce_model->sports->ticketSelections($id);
        foreach ($selections as &$s) {
            $match = $this->AIWorkforce_model->sports->findMatchById((int) $s['match_id']);
            $s['match'] = $match ? ['homeTeam' => $match['home_team'], 'awayTeam' => $match['away_team'], 'competition' => $match['competition'], 'kickoff' => $match['kickoff_at']] : null;
        }
        $this->json(['ticket' => $t, 'selections' => $selections]);
    }

    public function daily_tickets()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $this->json(['dailyTickets' => $this->AIWorkforce_model->sports->listDailyTickets((int) ($this->input->get('limit') ?: 60))]);
    }

    public function results()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $limit = (int) ($g['limit'] ?: 200);
        $rows = $this->AIWorkforce_model->sports->listMatches(['from' => $g['from'] ?? null, 'to' => $g['to'] ?? null, 'status' => 'FINISHED'], min(500, max(1, $limit)));
        $out = [];
        foreach ($rows as $m) {
            $r = $this->AIWorkforce_model->sports->findResultByMatch((int) $m['id']);
            $out[] = ['match' => ['id' => (int) $m['id'], 'homeTeam' => $m['home_team'], 'awayTeam' => $m['away_team'], 'competition' => $m['competition'], 'kickoff' => $m['kickoff_at']],
                'result' => $r ? ['homeScore' => $r['home_score'], 'awayScore' => $r['away_score'], 'status' => $r['status'], 'verified' => (bool) $r['verified'], 'verifiedAt' => $r['verified_at'], 'sourceTimestamp' => $r['source_timestamp']] : null];
        }
        $this->json(['results' => $out]);
    }

    public function providers()
    {
        // Vendor identities, key tiers, quota figures, circuit state and failing
        // endpoints are operator diagnostics — sports.manage, not sports.view.
        // Read-only users learn whether data is available from /dashboard.
        if (!$this->requirePermission('sports.manage', false)) return;
        $status = $this->platform->sports->status();
        $this->json([
            'providers' => $status['providers'],
            'liveHealth' => $status['liveHealth'],
            // Operational count + engine readiness (READY | BLOCKED | DISABLED_NO_PROVIDER)
            // and per-provider circuit state — the health-check dashboard contract.
            'readiness' => $status['readiness'],
            'predictionEngine' => $status['predictionEngine'],
        ]);
    }

    public function models()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $svc = $this->platform->sports->modelPerformance;
        $calibrations = $this->AIWorkforce_model->sports->listCalibrations(null, null, 50);
        $this->json(['models' => $svc->listModels(), 'calibrations' => $calibrations, 'metrics' => $this->AIWorkforce_model->sports->listModelMetrics(null, null, null, 100)]);
    }

    public function model_performance()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $window = (int) ($this->input->get('window') ?: 90);
        $this->json(['window' => $window, 'comparison' => $this->platform->sports->modelPerformance->compare($window)]);
    }

    public function calibrations()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $this->json(['calibrations' => $this->AIWorkforce_model->sports->listCalibrations(!empty($g['modelVersionId']) ? (int) $g['modelVersionId'] : null, $g['status'] ?? null, 50)]);
    }

    public function backtests()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $this->json(['backtests' => $this->AIWorkforce_model->sports->listBacktests((int) ($this->input->get('limit') ?: 20))]);
    }

    public function show_backtest(string $id)
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $bt = $this->AIWorkforce_model->sports->findBacktest($id);
        if (!$bt) return $this->jsonError('backtest not found', 404);
        $this->json(['backtest' => $bt]);
    }

    public function audit()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $events = $this->AIWorkforce_model->audit->recent((int) ($g['limit'] ?: 200));
        if (!empty($g['type'])) $events = array_values(array_filter($events, fn($e) => str_contains((string) $e['type'], (string) $g['type'])));
        $this->json(['events' => $events]);
    }

    public function jobs()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $this->json(['jobs' => $this->AIWorkforce_model->sports->listJobRuns(!empty($g['jobType']) ? (string) $g['jobType'] : null, (int) ($g['limit'] ?: 50))]);
    }

    public function configuration()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $this->json(['active' => $this->platform->sports->configuration->active(), 'history' => $this->AIWorkforce_model->sports->listConfigurations(20)]);
    }

    public function risk_monitor()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $since = gmdate('Y-m-d H:i:s', time() - (int) ($g['hours'] ?: 72) * 3600);
        $preds = $this->AIWorkforce_model->sports->listPredictions(['from' => $since], 1000);
        $byRisk = ['LOW' => 0, 'MEDIUM' => 0, 'HIGH' => 0, 'REJECTED' => 0];
        $reasons = [];
        $recent = [];
        foreach ($preds as $p) {
            $r = $p['risk'] ?? 'REJECTED';
            $byRisk[$r] = ($byRisk[$r] ?? 0) + 1;
            if (($p['decision'] ?? '') !== 'PREDICTION_READY') {
                foreach ((array) ($p['rejection_reasons'] ?? []) as $reason) {
                    if (is_string($reason)) $reasons[$reason] = ($reasons[$reason] ?? 0) + 1;
                }
            }
            if (count($recent) < 50) $recent[] = ['predictionId' => $p['id'], 'market' => $p['market'], 'selection' => $p['selection'], 'risk' => $p['risk'], 'decision' => $p['decision'], 'rejectionReasons' => $p['rejection_reasons'] ?? [], 'confidence' => $p['confidence'], 'dataQuality' => $p['data_quality_score'], 'createdAt' => $p['created_at']];
        }
        arsort($reasons);
        $this->json(['byRisk' => $byRisk, 'rejectionReasons' => $reasons, 'recent' => $recent, 'windowHours' => (int) ($g['hours'] ?: 72)]);
    }

    public function correlation_monitor()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $eng = $this->platform->sports->correlation;
        $tickets = $this->AIWorkforce_model->sports->listTickets([], 100);
        $alerts = [];
        foreach ($tickets as $t) {
            $sels = $this->AIWorkforce_model->sports->ticketSelections((string) $t['id']);
            if (count($sels) < 2) continue;
            $rows = array_map(function ($s) use ($eng) {
                $m = $this->AIWorkforce_model->sports->findMatchById((int) $s['match_id']);
                return ['matchId' => (int) $s['match_id'], 'competition' => $m['competition'] ?? null, 'homeTeam' => $m['home_team'] ?? null, 'awayTeam' => $m['away_team'] ?? null];
            }, $sels);
            $pairwise = $eng->classifySelections($rows);
            if ($pairwise['classification'] !== 'LOW') {
                $alerts[] = ['ticketId' => $t['id'], 'classification' => $pairwise['classification'], 'reasons' => $pairwise['reasons'], 'selectionCount' => count($sels), 'status' => $t['settlement_status']];
            }
        }
        $this->json(['alerts' => $alerts, 'note' => 'Tickets are optimized to stay under the configured correlation cap; these rows document measured pairwise classes.']);
    }

    /**
     * Top players for a league + season from a native provider.
     * GET /api/sports/topplayers?league=61&season=2020&type=yellow_cards[&provider=api-football][&cache=0]
     *
     * provider is optional — when omitted, the first configured provider with
     * top-player support is used (health-aware fallback). The response reports
     * which provider served it. Cached per (provider, league, season, type)
     * for 15 minutes; ?cache=0 bypasses.
     */
    public function top_players()
    {
        if (!$this->requirePermission('sports.view', false)) return;
        $g = $this->input->get(NULL, true) ?: [];
        $league = trim((string) ($g['league'] ?? ''));
        $season = trim((string) ($g['season'] ?? ''));
        if ($league === '' || $season === '') return $this->jsonError('league and season are required');
        $type = trim((string) ($g['type'] ?? 'scorers'));
        $providerId = trim((string) ($g['provider'] ?? ''));
        if ($providerId === '') $providerId = null;
        $bypass = isset($g['cache']) && (string) $g['cache'] === '0';
        $cacheKey = md5(implode('|', [$providerId ?? '', $league, $season, $type]));
        if (!$bypass && isset(self::$topPlayersCache[$cacheKey]) && (time() - self::$topPlayersCache[$cacheKey]['at']) < self::TOP_PLAYERS_CACHE_TTL) {
            $this->json(self::$topPlayersCache[$cacheKey]['data'], 200);
            return;
        }
        try {
            $data = $this->platform->sports->topPlayers($providerId, $league, $season, $type);
            $data['cachedFor'] = self::TOP_PLAYERS_CACHE_TTL;
            if (!$bypass) self::$topPlayersCache[$cacheKey] = ['at' => time(), 'data' => $data];
            $this->json($data, 200);
        } catch (\InvalidArgumentException $e) {
            $this->jsonError($e->getMessage(), 422);
        } catch (\Throwable $e) {
            $this->jsonError($e->getMessage(), 409);
        }
    }

    // ------------------------------------------------------------------ admin
    public function update_configuration()
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        $body = $this->jsonBody();
        if (empty($body['reason']) || !is_string($body['reason']) || trim($body['reason']) === '') return $this->jsonError('reason is required for configuration changes');
        $patch = array_diff_key($body, array_flip(['reason', 'allowAutomatedExecution']));
        $result = $this->platform->sports->configuration->update($patch, (string) $user['id'], (string) $body['reason'], !empty($body['allowAutomatedExecution']));
        if (!$result['ok']) return $this->jsonError($result['reason'], 422);
        $this->json(['configuration' => $result['configuration']]);
    }

    /** Triggers the daily ticket run for the given (or current) UTC date. */
    public function run_ticket_engine()
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        $body = $this->jsonBody();
        $date = isset($body['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $body['date']) ? (string) $body['date'] : gmdate('Y-m-d');
        $result = $this->platform->sports->dailyTickets->runDaily($date);
        // DATA_UNAVAILABLE (every provider failed) is a dependency outage:
        // 503 tells a caller "retry later", while NO_QUALIFIED_TICKET stays a
        // normal 200 outcome. The body carries the per-provider status codes.
        if (($result['status'] ?? '') === 'DATA_UNAVAILABLE') {
            $result['readiness'] = $this->platform->sports->providers->readiness();
            $this->json($result, 503);
            return;
        }
        $this->json($result, 200);
    }

    /** Fits a new calibration version from stored settled predictions. */
    public function fit_calibration()
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        try {
            $svc = $this->platform->sports;
            $outcomes = $this->AIWorkforce_model->sports->predictionOutcomes();
            $fit = $svc->calibration->fit($outcomes);
            if (empty($fit['ok'])) return $this->jsonError('calibration cannot be fitted: ' . ($fit['reason'] ?? 'unknown') . ' (samples: ' . ($fit['samples'] ?? 0) . ')', 422);
            $modelId = $this->AIWorkforce_model->sports->ensureModelVersion(['modelName' => \AIWorkforce\Sports\PredictionEngine::MODEL_NAME, 'modelVersion' => \AIWorkforce\Sports\PredictionEngine::MODEL_VERSION, 'featureVersion' => \AIWorkforce\Sports\FeatureEngineeringEngine::VERSION]);
            $id = $this->AIWorkforce_model->sports->saveCalibration([
                'model_version_id' => $modelId, 'method' => 'platt',
                'intercept' => $fit['fit']['intercept'], 'slope' => $fit['fit']['slope'],
                'brier' => $fit['metrics']['brier'], 'ece' => $fit['metrics']['ece'],
                'samples' => $fit['fit']['samples'], 'bins' => json_encode($fit['bins']),
                'status' => 'PENDING', 'created_by' => (string) $user['id'], 'created_at' => gmdate('c'),
            ]);
            $this->AIWorkforce_model->audit->emit('SPORTS_CALIBRATION_FITTED', 'New calibration version fitted (pending approval)', ['calibrationId' => $id, 'samples' => $fit['fit']['samples'], 'ece' => $fit['metrics']['ece'], 'brier' => $fit['metrics']['brier']], (string) $user['id']);
            $this->json(['calibration' => $this->AIWorkforce_model->sports->findCalibration($id)]);
        } catch (\Throwable $e) {
            $this->jsonError($e->getMessage(), 409);
        }
    }

    public function approve_calibration(string $id)
    {
        $this->decide_calibration($id, 'APPROVED');
    }

    public function reject_calibration(string $id)
    {
        $this->decide_calibration($id, 'REJECTED');
    }

    private function decide_calibration(string $id, string $status)
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        $cal = $this->AIWorkforce_model->sports->findCalibration((int) $id);
        if (!$cal) { $this->jsonError('calibration not found', 404); return; }
        if (($cal['status'] ?? '') !== 'PENDING') { $this->jsonError('calibration already decided', 409); return; }
        $this->AIWorkforce_model->sports->updateCalibrationStatus((int) $id, $status, (string) $user['id']);
        $this->AIWorkforce_model->audit->emit('SPORTS_CALIBRATION_' . $status, 'Calibration ' . $status . ' by ' . $user['id'], ['calibrationId' => (int) $id, 'intercept' => $cal['intercept'], 'slope' => $cal['slope'], 'samples' => $cal['samples']], (string) $user['id']);
        $this->json(['calibration' => $this->AIWorkforce_model->sports->findCalibration((int) $id)]);
    }

    public function run_backtest()
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        $body = $this->jsonBody();
        if (empty($body['from']) || empty($body['to'])) return $this->jsonError('from and to (YYYY-MM-DD) are required');
        try {
            $report = $this->platform->sports->backtester->run($body, (string) $user['id']);
            $this->json(['backtest' => $report]);
        } catch (\InvalidArgumentException $e) {
            $this->jsonError($e->getMessage(), 422);
        } catch (\Throwable $e) {
            $this->jsonError($e->getMessage(), 409);
        }
    }

    public function run_job(string $job)
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        if (!in_array($job, \AIWorkforce\Sports\SportsCronService::JOBS, true)) return $this->jsonError('unknown job. Valid: ' . implode(', ', \AIWorkforce\Sports\SportsCronService::JOBS), 422);
        $service = new \AIWorkforce\Sports\SportsCronService($this->AIWorkforce_model->sports, $this->AIWorkforce_model->audit, $this->platform->sports);
        $this->json(['result' => $service->run($job)], 200);
    }

    public function toggle_provider(string $id)
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        $body = $this->jsonBody();
        if (!isset($body['enabled']) || !is_bool($body['enabled'])) return $this->jsonError('body must include enabled: boolean');
        $providers = $this->AIWorkforce_model->sports->listProviders();
        $target = null;
        foreach ($providers as $p) if ((int) $p['id'] === (int) $id) { $target = $p; break; }
        if (!$target) return $this->jsonError('provider not found', 404);
        $this->AIWorkforce_model->sports->setProviderEnabled((int) $id, (bool) $body['enabled']);
        $this->AIWorkforce_model->audit->emit('SPORTS_PROVIDER_TOGGLED', 'Provider ' . $target['provider_code'] . ' ' . ((bool) $body['enabled'] ? 'enabled' : 'disabled'), ['provider' => $target['provider_code'], 'enabled' => (bool) $body['enabled']], (string) $user['id']);
        $this->json(['provider' => $this->AIWorkforce_model->sports->listProviders(true)]);
    }

    // ------------------------------------------------------------ governance
    /** Human decision only. Requires the native session, CSRF token and sports.approve. */
    public function decide_ticket(string $id)
    {
        $user = $this->requirePermission('sports.approve');
        if (!$user) return;
        // The kill switch is scoped to broker + trading-intelligence order paths
        // (AIWorkforce\KillSwitchPolicy) — Sports Intelligence is not governed
        // by it, so ticket approval is protected by sports.approve + CSRF only.
        $body = $this->jsonBody();
        if (!isset($body['approve']) || !is_bool($body['approve'])) return $this->jsonError('body must include approve: boolean');
        try {
            $this->json(['ticket' => $this->platform->sports->governance->decide($id, $body['approve'], (string) $user['id'], (string) ($body['reason'] ?? ''))]);
        } catch (\InvalidArgumentException $e) { $this->jsonError($e->getMessage(), 404); }
        catch (\Throwable $e) { $this->jsonError($e->getMessage(), 409); }
    }

    /** Promotes a persisted provider result only after validation. */
    public function verify_result()
    {
        $user = $this->requirePermission('sports.settle');
        if (!$user) return;
        $body = $this->jsonBody();
        if (!isset($body['matchId'], $body['providerId']) || !is_numeric($body['matchId']) || !is_numeric($body['providerId'])) return $this->jsonError('body must include numeric matchId and providerId');
        try { $this->json(['result' => $this->platform->sports->resultVerifier->verify((int) $body['matchId'], (int) $body['providerId'], (string) $user['id'])]); }
        catch (\InvalidArgumentException $e) { $this->jsonError($e->getMessage(), 404); }
        catch (\Throwable $e) { $this->jsonError($e->getMessage(), 409); }
    }



    /** Settles all open odds prediction tickets from verified persisted results. */
    public function settle()
    {
        if (!$this->requirePermission('sports.settle')) return;
        try {
            $this->json(['settlement' => $this->platform->sports->settlement->settleAllPending(200)]);
        } catch (\Throwable $e) { $this->jsonError($e->getMessage(), 409); }
    }

    /** Settles only from an already verified persisted provider result. */
    public function settle_ticket(string $id)
    {
        if (!$this->requirePermission('sports.settle')) return;
        $body = $this->jsonBody();
        try {
            if (isset($body['matchId'], $body['providerId']) && is_numeric($body['matchId']) && is_numeric($body['providerId'])) {
                $this->json(['settlement' => $this->platform->sports->settlement->applyStoredResult($id, (int) $body['matchId'], (int) $body['providerId'])]);
            } else {
                $this->json(['settlement' => $this->platform->sports->settlement->settlePending($id)]);
            }
        } catch (\InvalidArgumentException $e) { $this->jsonError($e->getMessage(), 404); }
        catch (\Throwable $e) { $this->jsonError($e->getMessage(), 409); }
    }

    /**
     * Sync fixtures/odds/results from a specific named provider.
     * GET /api/sports/sync?provider=api-football&type=fixtures&from=2026-09-01&to=2026-09-07
     * type=live refreshes every in-play fixture of the provider (minute + goal
     * score) from its live endpoint and records SPORTS_GOAL_SCORED events.
     * type=round bulk-syncs a whole matchday (fixtures + odds + results) in
     * one provider request: ?provider=sportmonks&type=round&roundId=396698
     */
    public function sync_provider()
    {
        $user = $this->requirePermission('sports.manage');
        if (!$user) return;
        $g = $this->input->get(NULL, true) ?: [];
        $providerId = (string) ($g['provider'] ?? '');
        $type = (string) ($g['type'] ?? 'fixtures');
        if ($providerId === '') return $this->jsonError('provider is required (e.g. api-football, thesportsdb, sportmonks)');
        $provider = $this->platform->sports->providers->provider($providerId);
        if (!$provider) return $this->jsonError('provider not registered: ' . $providerId, 404);
        try {
            if ($type === 'fixtures') {
                $query = ['from' => $g['from'] ?? gmdate('Y-m-d'), 'to' => $g['to'] ?? $g['from'] ?? gmdate('Y-m-d')];
                // Forward optional api-football filters so callers can narrow
                // a range without hitting the generic 31-day date-loop limit
                // (e.g. &league=39&season=2026) or request a single calendar
                // day via date. The provider also accepts these directly.
                foreach (['league', 'season', 'team', 'status', 'timezone', 'round', 'venue', 'date'] as $k) {
                    if (!empty($g[$k])) $query[$k] = (string) $g[$k];
                }
                // date is a single-day shortcut — from/to are irrelevant when
                // it is present (provider maps it to /fixtures?date=YYYY-MM-DD).
                if (!empty($query['date'])) {
                    unset($query['from'], $query['to']);
                }
                $result = $this->platform->sports->sync->syncFixtures($provider, $query, 'api-sync-' . $providerId . '-' . gmdate('YmdHis'));
            } elseif ($type === 'odds') {
                if (empty($g['fixtureId'])) return $this->jsonError('fixtureId is required for odds sync');
                $result = $this->platform->sports->sync->syncOdds($provider, (string) $g['fixtureId'], 'api-sync-odds-' . $providerId . '-' . gmdate('YmdHis'));
            } elseif ($type === 'results') {
                if (empty($g['fixtureId'])) return $this->jsonError('fixtureId is required for results sync');
                $result = $this->platform->sports->sync->syncResults($provider, (string) $g['fixtureId'], 'api-sync-results-' . $providerId . '-' . gmdate('YmdHis'));
            } elseif ($type === 'live') {
                // One live-endpoint request: refresh every in-play fixture of
                // this provider (minute + goal score) and record goal events.
                if (!method_exists($provider, 'liveFixtures')) return $this->jsonError('provider does not support live fixtures: ' . $providerId, 422);
                $result = $this->platform->sports->sync->syncLive($provider, 'api-sync-live-' . $providerId . '-' . gmdate('YmdHis'));
            } elseif ($type === 'round') {
                if (empty($g['roundId'])) return $this->jsonError('roundId is required for round sync (resolve with the provider season rounds)');
                $result = $this->platform->sports->sync->syncRound($provider, (string) $g['roundId'], 'api-sync-round-' . $providerId . '-' . $g['roundId'] . '-' . gmdate('YmdHis'));
            } else {
                return $this->jsonError('type must be fixtures, odds, results, live, or round');
            }
            $this->json(['sync' => $result, 'provider' => $providerId, 'type' => $type]);
        } catch (\Throwable $e) {
            $this->jsonError($e->getMessage(), 409);
        }
    }

    /**
     * List available native sports provider drivers and their connection status.
     * GET /api/sports/provider-drivers
     */
    public function provider_drivers()
    {
        if (!$this->requirePermission('sports.view')) return;
        $drivers = [
            'api-football' => [
                'label' => 'API-Football (api-football.com)',
                'docs' => 'https://www.api-football.com/documentation-v3',
                'capabilities' => ['fixtures', 'odds', 'results', 'standings', 'team_statistics', 'top_players', 'leagues'],
                'envKey' => 'WINDELS_API_FOOTBALL_KEY',
                'configured' => $this->platform->sports->providers->provider('api-football') !== null,
            ],
            'thesportsdb' => [
                'label' => 'TheSportsDB (thesportsdb.com)',
                'docs' => 'https://www.thesportsdb.com/docs_api_examples',
                'capabilities' => ['fixtures', 'results', 'leagues', 'teams', 'team_search'],
                'notes' => 'No odds endpoint on any tier. Free key "3" caps list endpoints (e.g. 5 leagues, partial day/season); v2 livescore requires premium. Events carry an idAPIfootball cross-reference, surfaced as apiFootballId.',
                'envKey' => 'WINDELS_THESPORTSDB_KEY',
                'configured' => $this->platform->sports->providers->provider('thesportsdb') !== null,
            ],
            'sportmonks' => [
                'label' => 'SportMonks (sportmonks.com)',
                'docs' => 'https://docs.sportmonks.com/football/v3',
                'capabilities' => ['fixtures', 'odds', 'results', 'standings', 'lineups', 'leagues', 'rounds'],
                'notes' => 'Odds require the optional odds add-on subscription. round() fetches a full matchday (fixtures + odds + results) in one request.',
                'envKey' => 'WINDELS_SPORTMONKS_TOKEN',
                'configured' => $this->platform->sports->providers->provider('sportmonks') !== null,
            ],
        ];
        $liveHealth = $this->platform->sports->providers->health();
        foreach ($drivers as $id => &$driver) {
            $driver['health'] = $liveHealth[$id] ?? null;
        }
        $this->json(['drivers' => $drivers]);
    }
}
