<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/App_Controller.php';

/**
 * WINDELS AI WORKFORCE administrator portal.
 * Every action is authorized server-side. Passwords and hashes are never shown.
 * The 4-digit Security PIN and security question are readable only by Super Admin.
 */
class Admin extends App_Controller
{
    private \AIWorkforce\AdminPortal $portal;

    public function __construct()
    {
        parent::__construct();
        $this->portal = new \AIWorkforce\AdminPortal($this->AIWorkforce_model);
        $this->portal->ensureSchema();
    }

    public function index()
    {
        $user = $this->requireAdmin(); if (!$user) return;
        // Best-effort auto-run: an admin visit fires due cron jobs in the background.
        try {
            $cronStore = new \AIWorkforce\Cron\PlatformSettingsCronStore($this->AIWorkforce_model->db);
            \AIWorkforce\Cron\CronAutoRun::maybeTrigger(
                new \AIWorkforce\Cron\CronScheduler($cronStore),
                $cronStore,
                $this->cronRunUrl(\AIWorkforce\Cron\CronSecrets::ensure($cronStore))
            );
        } catch (\Throwable $e) { /* auto-run must never break the dashboard */ }
        if (!$this->platform->identity->can($user, 'admin.analytics.view') && !$this->isSuperAdmin($user)) {
            // Support admins still see the overview with the numbers they can access.
        }
        $data = $this->base('Admin Dashboard', 'dashboard');
        $data['stats'] = $this->portal->dashboardStats();
        $data['smtp'] = \AIWorkforce\Mailer::configSummary();
        // Initialize Cloudflare agent runtime if configured
        $cloudflareRuntime = null;
        try {
            $llmConfig = \AIWorkforce\ApiProviders::activeConfig('llm');
            if ($llmConfig && ($llmConfig['driver'] ?? '') === 'cloudflare_workers_ai') {
                $cloudflareRuntime = new \AIWorkforce\CloudflareAgentRuntime([
                    'account_id' => $llmConfig['account_id'] ?? '',
                    'token' => $llmConfig['secrets']['token'] ?? '',
                    'gateway' => $llmConfig['extra']['gateway'] ?? null,
                ]);
            }
        } catch (\Throwable $e) {
            // Cloudflare not configured
        }

        // Get Cloudflare platform status (new unified platform)
        $cfPlatformStatus = [];
        try {
            $cfPlatformStatus = $this->platform->cloudflare->status();
        } catch (\Throwable $e) {
            // Platform not yet initialized
        }
        
        $data['agentRuntime'] = [
            'cloudflareConfigured' => \AIWorkforce\ApiProviders::publicStatus('llm')['configured'],
            'cloudflareRuntime' => $cloudflareRuntime ? $cloudflareRuntime->status() : null,
            'platformStatus' => $cfPlatformStatus,
            'registeredAgents' => $cloudflareRuntime ? array_keys($cloudflareRuntime->agents()) : array_keys($this->platform->agents->agents()),
            'registeredTools' => $cloudflareRuntime ? array_keys($cloudflareRuntime->tools()) : [],
            'toolPolicy' => 'Approval required for broker.submitTrade and lottery.purchaseTicket',
            'availableServices' => [
                'text_generation' => 'Llama 3.1 (8B/70B), Mistral, Gemma, Phi-2 via Workers AI',
                'embeddings' => 'BGE Base/Large for semantic search and RAG',
                'image_generation' => 'Stable Diffusion XL, Dreamshaper',
                'speech_recognition' => 'Whisper and Whisper Large v3',
                'translation' => 'M2M100 — 100+ languages',
                'summarization' => 'BART text summarization',
                'classification' => 'Sentiment and zero-shot classification',
                'object_detection' => 'DETR ResNet-50 for computer vision',
            ],
            'platformComponents' => [
                'Model Router' => 'Multi-provider failover with rate limiting and cost tracking',
                'MCP Tool Registry' => 'Centralized tool discovery with 15+ registered tools',
                'Agent Sessions' => 'Durable conversations with history and state',
                'Workflow Engine' => 'Long-running tasks with retry and scheduling',
                'Communication Bus' => 'Agent-to-agent delegation and routing',
                'Observability' => 'Full monitoring dashboard with traces',
            ],
        ];
        $this->render('admin/index', $data);
    }

    public function users()
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $q = trim((string) $this->input->get('q', true));
        $status = (string) $this->input->get('status', true);
        $sort = (string) $this->input->get('sort', true) ?: 'created_at';
        $dir = (string) $this->input->get('dir', true) ?: 'DESC';
        $page = max(1, (int) $this->input->get('page'));
        $result = $this->AIWorkforce_model->identity->searchUsers(
            ['q' => $q, 'status' => in_array($status, ['active', 'suspended'], true) ? $status : ''],
            $sort, $dir, $page, 20
        );
        $data = $this->base('Users', 'users');
        $data = array_merge($data, $result);
        $data['q'] = $q;
        $data['statusFilter'] = $status;
        $data['sort'] = $sort;
        $data['dir'] = $dir;
        $data['canManage'] = $this->platform->identity->can($actor, 'admin.users.manage');
        $data['canImpersonate'] = $this->platform->identity->can($actor, 'admin.users.impersonate');
        $data['canDelete'] = $this->platform->identity->can($actor, 'admin.users.delete');
        $this->render('admin/users/index', $data);
    }

    public function user($id = 0)
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $member = $this->findPublicUser((int) $id, $this->isSuperAdmin($actor));
        if (!$member) { $this->flash('error', 'User not found.'); redirect('/admin/users'); return; }
        $data = $this->base('User ' . ($member['user_uid'] ?? $member['id']), 'users');
        $data['member'] = $member;
        $data['bundle'] = $this->portal->userProfileBundle($member);
        $data['canManage'] = $this->platform->identity->can($actor, 'admin.users.manage');
        $data['canImpersonate'] = $this->canImpersonate($actor, $member);
        $data['canDelete'] = $this->platform->identity->can($actor, 'admin.users.delete');
        $this->render('admin/users/show', $data);
    }

    public function create_user()
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        if ($this->input->method(true) !== 'POST') {
            $data = $this->base('Create user', 'users');
            $data['roles'] = $this->portal->assignableRoles($actor);
            $data['securityQuestions'] = \AIWorkforce\IdentitySchema::SECURITY_QUESTIONS;
            $this->render('admin/users/create', $data);
            return;
        }
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/users/create'); return; }
        $username = strtolower(trim((string) $this->input->post('username')));
        $email = strtolower(trim((string) $this->input->post('email')));
        $password = (string) $this->input->post('password');
        $roleCode = trim((string) $this->input->post('role'));
        if (!$this->validUsername($username) || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12) {
            $this->flash('error', 'Enter a valid username, email and a password of at least 12 characters.');
            redirect('/admin/users/create'); return;
        }
        if (!$this->roleAllowed($actor, $roleCode)) {
            $this->flash('error', 'That role cannot be assigned from your account.');
            redirect('/admin/users/create'); return;
        }
        if ($this->AIWorkforce_model->identity->findUserByEmail($email) || $this->AIWorkforce_model->identity->usernameTaken($username)) {
            $this->flash('error', 'That username or email is already in use.');
            redirect('/admin/users/create'); return;
        }
        $questionPosted = trim((string) $this->input->post('security_question'));
        $recovery = null;
        if ($questionPosted !== '') {
            $recovery = \AIWorkforce\IdentitySchema::fromPostedQuestion(
                (string) $this->input->post('security_question'),
                (string) $this->input->post('security_answer')
            );
            if (!$recovery) {
                $this->flash('error', 'Enter a security question and an answer of at least 2 characters — or leave both blank.');
                redirect('/admin/users/create'); return;
            }
        }
        $now = gmdate('c');
        $payload = [
            'username' => $username, 'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'display_name' => $username, 'active' => 1,
            'created_at' => $now, 'updated_at' => $now, 'last_login_at' => null,
        ];
        if ($recovery) $payload = array_merge($payload, $recovery);
        $new = $this->AIWorkforce_model->identity->createUser($payload);
        $role = $this->AIWorkforce_model->identity->ensureRole($roleCode, ucwords(str_replace('_', ' ', $roleCode)));
        $this->AIWorkforce_model->identity->assignRole((int) $new['id'], $role);
        $this->portal->log($actor, 'USER_CREATED', 'ok', $this->portal->userTarget($new), ['role' => $roleCode], $this->ip());
        $this->flash('notice', 'User account created. User ID ' . ($new['user_uid'] ?? '') . '. A 4-digit Security PIN was assigned automatically. The temporary password is not stored and will not be shown again.');
        redirect('/admin/users/' . (int) $new['id']);
    }

    public function edit_user($id = 0)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        $member = $this->findPublicUser((int) $id);
        if (!$member) { $this->flash('error', 'User not found.'); redirect('/admin/users'); return; }
        if ($this->input->method(true) !== 'POST') {
            $data = $this->base('Edit user', 'users');
            $data['member'] = $member;
            $data['roles'] = $this->portal->assignableRoles($actor);
            $data['currentRole'] = $this->portal->primaryRole($member);
            $this->render('admin/users/edit', $data);
            return;
        }
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/users/' . (int) $id . '/edit'); return; }
        $username = strtolower(trim((string) $this->input->post('username')));
        $email = strtolower(trim((string) $this->input->post('email')));
        $display = trim((string) $this->input->post('display_name'));
        $roleCode = trim((string) $this->input->post('role'));
        if (!$this->validUsername($username) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->flash('error', 'Enter a valid username and email address.');
            redirect('/admin/users/' . (int) $id . '/edit'); return;
        }
        if ($this->AIWorkforce_model->identity->usernameTaken($username, (int) $id) || $this->AIWorkforce_model->identity->emailTaken($email, (int) $id)) {
            $this->flash('error', 'That username or email is already in use.');
            redirect('/admin/users/' . (int) $id . '/edit'); return;
        }
        $patch = ['username' => $username, 'email' => $email, 'display_name' => $display !== '' ? $display : $username];
        $this->AIWorkforce_model->identity->updateUser((int) $id, $patch);
        if ($roleCode !== '' && $this->roleAllowed($actor, $roleCode)) {
            $role = $this->AIWorkforce_model->identity->findRoleByCode($roleCode);
            if ($role) $this->AIWorkforce_model->identity->replaceUserRoles((int) $id, [(int) $role['id']]);
        }
        $this->handleAvatarUpload((int) $id, $member);
        $fresh = $this->findPublicUser((int) $id);
        $this->portal->log($actor, 'USER_EDITED', 'ok', $this->portal->userTarget($fresh ?: $member), [], $this->ip());
        $this->flash('notice', 'User account updated.');
        redirect('/admin/users/' . (int) $id);
    }

    public function suspend_user($id = 0)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        $this->setStatus((int) $id, $actor, false);
    }

    public function activate_user($id = 0)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        $this->setStatus((int) $id, $actor, true);
    }

    /** Kept for the previous toggle route used by older bookmarks. */
    public function toggle_user(int $id)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        $target = $this->AIWorkforce_model->identity->findUserById($id);
        if (!$target) { $this->flash('error', 'User not found.'); redirect('/admin/users'); return; }
        $this->setStatus($id, $actor, empty($target['active']));
    }

    public function delete_user($id = 0)
    {
        $actor = $this->gate('admin.users.delete'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/users'); return; }
        $id = (int) $id;
        if ((int) $actor['id'] === $id) { $this->flash('error', 'You cannot delete your own account.'); redirect('/admin/users/' . $id); return; }
        $target = $this->findPublicUser($id);
        if (!$target) { $this->flash('error', 'User not found.'); redirect('/admin/users'); return; }
        if ($this->AIWorkforce_model->identity->userHasRole($id, 'super_admin') && $this->AIWorkforce_model->identity->countSuperAdmins() <= 1) {
            $this->flash('error', 'The last Super Admin account cannot be deleted.');
            redirect('/admin/users/' . $id); return;
        }
        $ok = $this->AIWorkforce_model->identity->deleteUser($id);
        $this->portal->log($actor, 'USER_DELETED', $ok ? 'ok' : 'error', $this->portal->userTarget($target), [], $this->ip());
        if (!$ok) {
            $this->flash('error', 'This account could not be deleted because related records still exist. Suspend the account instead.');
            redirect('/admin/users/' . $id); return;
        }
        $this->flash('notice', 'User account deleted.');
        redirect('/admin/users');
    }

    public function reset_password($id = 0)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/users/' . (int) $id); return; }
        $target = $this->findPublicUser((int) $id);
        if (!$target) { $this->flash('error', 'User not found.'); redirect('/admin/users'); return; }
        $temporary = $this->randomPassword();
        $this->AIWorkforce_model->identity->updateUser((int) $id, ['password_hash' => password_hash($temporary, PASSWORD_DEFAULT)]);
        $this->portal->log($actor, 'PASSWORD_RESET', 'ok', $this->portal->userTarget($target), [], $this->ip());
        $this->session->set_flashdata('temp_password', $temporary);
        $this->flash('notice', 'Password reset. Give the user the temporary password shown below. It is not stored and will not be shown again.');
        redirect('/admin/users/' . (int) $id);
    }

    public function impersonate($id = 0)
    {
        if ($this->impersonator()) {
            $this->flash('error', 'Return to your administrator account before opening another dashboard.');
            redirect('/dashboard'); return;
        }
        $actor = $this->gate('admin.users.impersonate'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/users'); return; }
        $target = $this->AIWorkforce_model->identity->findUserById((int) $id);
        if (!$target) { $this->flash('error', 'User not found.'); redirect('/admin/users'); return; }
        $public = $this->portal->publicUser($target, false);
        $public['permissions'] = $this->AIWorkforce_model->identity->permissionsForUser((int) $id);
        $public['roles'] = $this->AIWorkforce_model->identity->rolesForUser((int) $id);
        if (!$this->canImpersonate($actor, $public)) {
            $this->portal->log($actor, 'IMPERSONATION_STARTED', 'denied', $this->portal->userTarget($public), [], $this->ip());
            $this->flash('error', 'You cannot sign in as that account.');
            redirect('/admin/users/' . (int) $id); return;
        }
        $sessionId = $this->portal->startImpersonation($actor, $public, $this->ip());
        $this->session->sess_regenerate(true);
        $this->session->set_userdata([
            'identity' => $public,
            'impersonator' => $actor,
            'impersonation_id' => $sessionId,
            'csrf_token' => bin2hex(random_bytes(32)),
        ]);
        $this->flash('notice', 'You are viewing this account dashboard as an administrator. Use the banner to open the admin portal or return to your account.');
        redirect('/dashboard');
    }

    /** Return from a user session to the original administrator. Must not require admin.access on the impersonated user. */
    public function stop_impersonation()
    {
        $current = $this->currentUser();
        $admin = $this->impersonator();
        if (!$current || !$admin) { redirect('/admin'); return; }
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/dashboard'); return; }
        $sessionId = (int) $this->session->userdata('impersonation_id');
        if ($sessionId > 0) $this->portal->endImpersonation($sessionId, $admin, $current, $this->ip());
        $fresh = $this->AIWorkforce_model->identity->findUserById((int) $admin['id']);
        if (!$fresh || empty($fresh['active'])) {
            $this->session->sess_destroy();
            $this->flash('error', 'The administrator session could not be restored.');
            redirect('/admin/login'); return;
        }
        $fresh['permissions'] = $this->AIWorkforce_model->identity->permissionsForUser((int) $fresh['id']);
        $fresh = \AIWorkforce\IdentitySchema::stripSecrets($fresh);
        $this->session->sess_regenerate(true);
        $this->session->unset_userdata(['impersonator', 'impersonation_id']);
        $this->session->set_userdata(['identity' => $fresh, 'csrf_token' => bin2hex(random_bytes(32))]);
        $this->flash('notice', 'Returned to your administrator account.');
        redirect('/admin/users/' . (int) $current['id']);
    }

    public function search()
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $q = trim((string) $this->input->get('q', true));
        $data = $this->base('Search', 'users');
        $data['q'] = $q;
        $data['results'] = $q === '' ? [] : $this->portal->searchUsers($q, 30);
        $this->render('admin/search', $data);
    }

    public function workforce()
    {
        $actor = $this->requireAdmin(); if (!$actor) return;
        $data = $this->base('AI Workforce', 'workforce');
        $data['overview'] = $this->portal->workforceOverview();
        $this->render('admin/workforce', $data);
    }

    public function languages()
    {
        $actor = $this->requireAdmin(); if (!$actor) return;
        $data = $this->base('Language Learning', 'languages');
        $data['overview'] = $this->portal->languageOverview();
        $this->render('admin/languages', $data);
    }

    public function conversations()
    {
        $actor = $this->requireAdmin(); if (!$actor) return;
        $data = $this->base('Conversations', 'conversations');
        $data['overview'] = $this->portal->conversationOverview();
        $this->render('admin/conversations', $data);
    }

    public function analytics()
    {
        $actor = $this->gate('admin.analytics.view'); if (!$actor) return;
        $data = $this->base('Analytics', 'analytics');
        $data['overview'] = $this->portal->analyticsOverview();
        $this->render('admin/analytics', $data);
    }

    public function notifications()
    {
        $actor = $this->requireAdmin(); if (!$actor) return;
        $inbox = $this->platform->notifications->inbox((int) $actor['id'], false, 80);
        $data = $this->base('Notifications', 'notifications');
        $data['inbox'] = $inbox;
        $data['canSend'] = $this->platform->identity->can($actor, 'admin.users.manage');
        $data['activeUsers'] = count($this->AIWorkforce_model->identity->activeRecipients());
        $this->render('admin/notifications', $data);
    }

    // ---- Admin Inbox: contact form messages + replies + email templates ----

    public function inbox()
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $status = (string) $this->input->get('status', true);
        if ($status === '') $status = 'all';
        $search = trim((string) $this->input->get('q', true));
        $page = max(1, (int) $this->input->get('page'));
        $perPage = 30;
        $filter = ['status' => $status];
        if ($search !== '') $filter['search'] = $search;
        if ($status === 'starred') { $filter['starred'] = true; $filter['status'] = 'all'; }
        if ($status === 'unread') { $filter['unread'] = true; $filter['status'] = 'all'; }
        $list = $this->AIWorkforce_model->inbox->list($filter, $perPage, ($page - 1) * $perPage);
        $data = $this->base('Inbox', 'inbox');
        $data['messages'] = $list['rows'];
        $data['total'] = (int) $list['total'];
        $data['page'] = $page;
        $data['perPage'] = $perPage;
        $data['status'] = $status;
        $data['search'] = $search;
        $data['counts'] = $this->AIWorkforce_model->inbox->counts();
        $this->render('admin/inbox/index', $data);
    }

    public function inbox_view($id = 0)
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $msg = $this->AIWorkforce_model->inbox->find((string) $id);
        if (!$msg) { $this->flash('error', 'Message not found.'); redirect('/admin/inbox'); return; }
        // Mark read and transition new -> open once an admin opens it.
        if (empty($msg['is_read'])) $this->AIWorkforce_model->inbox->markRead((int) $msg['id']);
        if (($msg['status'] ?? '') === 'new') $this->AIWorkforce_model->inbox->setStatus((int) $msg['id'], 'open');
        $msg = $this->AIWorkforce_model->inbox->find((int) $msg['id']);
        $replies = $this->AIWorkforce_model->inbox->replies((int) $msg['id']);
        $templates = $this->AIWorkforce_model->inbox->listTemplates('contact', true);
        $data = $this->base('Message from ' . $msg['sender_name'], 'inbox');
        $data['msg'] = $msg;
        $data['replies'] = $replies;
        $data['templates'] = $templates;
        $data['smtp'] = \AIWorkforce\Mailer::configSummary();
        $data['csrfToken'] = (string) $this->session->userdata('csrf_token');
        $this->render('admin/inbox/view', $data);
    }

    public function inbox_reply($id = 0)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/inbox'); return; }
        $msg = $this->AIWorkforce_model->inbox->find((int) $id);
        if (!$msg) { $this->flash('error', 'Message not found.'); redirect('/admin/inbox'); return; }

        $templateId = (int) $this->input->post('template_id');
        $subject = trim((string) $this->input->post('subject'));
        $body = trim((string) $this->input->post('body'));
        if ($subject === '' || $body === '') {
            $this->flash('error', 'Subject and reply body are required.');
            redirect('/admin/inbox/' . (int) $msg['id']); return;
        }

        $tpl = $templateId ? $this->AIWorkforce_model->inbox->findTemplate($templateId) : null;
        $site = (string) (getenv('VP_SITE_NAME') ?: 'WINDELS AI WORKFORCE');
        $senderName = (string) $msg['sender_name'];
        $to = (string) $msg['sender_email'];
        $ctx = [
            'site_name' => $site, 'name' => $senderName, 'subject' => $msg['subject'],
            'reply_body' => $body, 'original_message' => (string) $msg['body'],
            'original_message_date' => (string) ($msg['created_at'] ?? ''),
            'signature_name' => (string) ($actor['display_name'] ?? $actor['email'] ?? 'Support'),
        ];
        $htmlBody = $body;
        if ($tpl && ($tpl['code'] ?? '') === 'admin_reply') {
            $htmlBody = \AIWorkforce\EmailTemplates::render($tpl['body_html'], $ctx);
            $textBody = $tpl['body_text'] ? \AIWorkforce\EmailTemplates::renderText($tpl['body_text'], $ctx) : $body;
        } else {
            $htmlBody = '<div style="font-family:Arial,Helvetica,sans-serif;max-width:620px;margin:0 auto;color:#0f172a;padding:16px">'
                . '<p>Hi ' . htmlspecialchars($senderName) . ',</p>'
                . '<div style="white-space:pre-wrap;line-height:1.6">' . htmlspecialchars($body) . '</div>'
                . '<p style="margin-top:24px">Best regards,<br><strong>' . htmlspecialchars((string) $ctx['signature_name']) . '</strong><br>' . htmlspecialchars($site) . '</p>'
                . '<hr style="border:none;border-top:1px solid #e2e8f0;margin:24px 0">'
                . '<p style="font-size:12px;color:#64748b"><strong>On ' . htmlspecialchars((string) $msg['created_at']) . ' you wrote:</strong></p>'
                . '<blockquote style="margin:4px 0 0;padding:10px 14px;border-left:3px solid #cbd5e1;color:#475569;white-space:pre-wrap;font-size:13px;background:#f8fafc;border-radius:0 6px 6px 0">' . htmlspecialchars((string) $msg['body']) . '</blockquote>'
                . '</div>';
            $textBody = "Hi {$senderName},\n\n{$body}\n\nBest regards,\n{$ctx['signature_name']}\n{$site}";
        }

        $sendResult = \AIWorkforce\Mailer::send($this, $to, $subject, $htmlBody, $textBody);
        $this->AIWorkforce_model->inbox->addReply([
            'message_id' => (int) $msg['id'],
            'template_id' => $templateId ?: null,
            'author_id' => (int) $actor['id'],
            'author_label' => (string) ($actor['display_name'] ?? $actor['email'] ?? 'Admin'),
            'direction' => 'outbound',
            'to_email' => $to,
            'subject' => $subject,
            'body' => $htmlBody,
            'body_text' => $textBody,
            'delivery_status' => !empty($sendResult['ok']) ? 'sent' : 'failed',
            'delivery_message' => (string) ($sendResult['message'] ?? ''),
            'ip' => $this->input->ip_address(),
        ]);
        $this->AIWorkforce_model->inbox->update((int) $msg['id'], [
            'status' => 'replied', 'is_read' => 1, 'last_reply_at' => gmdate('c'), 'last_reply_by' => (int) $actor['id'],
        ]);
        try {
            $this->portal->log($actor, 'INBOX_REPLY_SENT', !empty($sendResult['ok']) ? 'ok' : 'error', [
                'type' => 'contact_message', 'id' => (string) $msg['id'], 'label' => $senderName . ' <' . $to . '>',
            ], ['subject' => $subject, 'delivered' => !empty($sendResult['ok'])], $this->input->ip_address());
        } catch (\Throwable $_) {}

        if (!empty($sendResult['ok'])) {
            $this->flash('notice', 'Reply sent to ' . $to . '.');
        } else {
            $this->flash('error', 'Reply saved but email delivery failed: ' . (string) ($sendResult['message'] ?? 'Unknown error') . '. Check SMTP configuration.');
        }
        redirect('/admin/inbox/' . (int) $msg['id']);
    }

    public function inbox_toggle_star($id = 0)
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $msg = $this->AIWorkforce_model->inbox->find((int) $id);
        if (!$msg) { $this->flash('error', 'Message not found.'); redirect('/admin/inbox'); return; }
        $v = empty($msg['is_starred']) ? 1 : 0;
        $this->AIWorkforce_model->inbox->toggleStar((int) $msg['id'], $v);
        redirect($this->input->get_post('return') ?: '/admin/inbox');
    }

    public function inbox_status($id = 0)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/inbox'); return; }
        $msg = $this->AIWorkforce_model->inbox->find((int) $id);
        if (!$msg) { $this->flash('error', 'Message not found.'); redirect('/admin/inbox'); return; }
        $status = (string) $this->input->post('status');
        $this->AIWorkforce_model->inbox->setStatus((int) $msg['id'], $status);
        $this->flash('notice', 'Message status updated.');
        redirect('/admin/inbox/' . (int) $msg['id']);
    }

    public function inbox_delete($id = 0)
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/inbox'); return; }
        $msg = $this->AIWorkforce_model->inbox->find((int) $id);
        if (!$msg) { $this->flash('error', 'Message not found.'); redirect('/admin/inbox'); return; }
        $this->AIWorkforce_model->inbox->delete((int) $msg['id']);
        try { $this->portal->log($actor, 'INBOX_MESSAGE_DELETED', 'ok', ['type' => 'contact_message', 'id' => (string) $id, 'label' => (string) $msg['sender_name']], [], $this->input->ip_address()); } catch (\Throwable $_) {}
        $this->flash('notice', 'Conversation deleted.');
        redirect('/admin/inbox');
    }

    public function inbox_templates()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        $category = (string) $this->input->get('category', true) ?: 'all';
        $data = $this->base('Email templates', 'inbox');
        $data['templates'] = $this->AIWorkforce_model->inbox->listTemplates($category);
        $data['category'] = $category;
        $data['categories'] = ['all','contact','account','internal','general','marketing'];
        $this->render('admin/inbox/templates', $data);
    }

    public function inbox_template_new()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        $data = $this->base('New email template', 'inbox');
        $data['tpl'] = ['id' => null, 'code' => '', 'name' => '', 'category' => 'general', 'description' => '',
            'subject' => '', 'body_html' => "<p>Hi {{name}},</p>\n<p>…</p>", 'body_text' => '', 'is_active' => 1, 'is_system' => 0];
        $data['categories'] = ['general','contact','account','internal','marketing'];
        $this->render('admin/inbox/template_form', $data);
    }

    public function inbox_template_edit($id = 0)
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        $tpl = $this->AIWorkforce_model->inbox->findTemplate((int) $id);
        if (!$tpl) { $this->flash('error', 'Template not found.'); redirect('/admin/inbox/templates'); return; }
        $data = $this->base('Edit email template', 'inbox');
        $data['tpl'] = $tpl;
        $data['tpl']['variables'] = json_decode((string) ($tpl['variables_json'] ?? '[]'), true) ?: [];
        $data['categories'] = ['general','contact','account','internal','marketing'];
        $this->render('admin/inbox/template_form', $data);
    }

    public function inbox_template_save($id = 0)
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/inbox/templates'); return; }
        $payload = [
            'id' => (int) $id ?: null,
            'code' => strtolower(trim((string) $this->input->post('code'))),
            'name' => trim((string) $this->input->post('name')),
            'category' => trim((string) $this->input->post('category')) ?: 'general',
            'description' => trim((string) $this->input->post('description')),
            'subject' => trim((string) $this->input->post('subject')),
            'body_html' => (string) $this->input->post('body_html'),
            'body_text' => trim((string) $this->input->post('body_text')),
            'is_active' => (int) $this->input->post('is_active') ? 1 : 0,
            'created_by' => (int) $actor['id'],
            'updated_by' => (int) $actor['id'],
        ];
        if ($payload['name'] === '' || $payload['code'] === '' || $payload['subject'] === '' || $payload['body_html'] === '') {
            $this->flash('error', 'Code, name, subject and HTML body are required.');
            redirect($id ? '/admin/inbox/templates/' . (int) $id . '/edit' : '/admin/inbox/templates/new');
            return;
        }
        if (!preg_match('/^[a-z0-9_]{3,60}$/', $payload['code'])) {
            $this->flash('error', 'Template code must be 3–60 lowercase letters, digits or underscores.');
            redirect($id ? '/admin/inbox/templates/' . (int) $id . '/edit' : '/admin/inbox/templates/new');
            return;
        }
        try {
            $newId = $this->AIWorkforce_model->inbox->saveTemplate($payload);
            $this->flash('notice', 'Template saved.');
            redirect('/admin/inbox/templates/' . (int) $newId . '/edit');
            return;
        } catch (\Throwable $e) {
            $this->flash('error', 'Could not save template: ' . $e->getMessage());
            redirect($id ? '/admin/inbox/templates/' . (int) $id . '/edit' : '/admin/inbox/templates/new');
        }
    }

    public function inbox_template_delete($id = 0)
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/inbox/templates'); return; }
        $ok = $this->AIWorkforce_model->inbox->deleteTemplate((int) $id);
        $this->flash($ok ? 'notice' : 'error', $ok ? 'Template deleted.' : 'System templates cannot be deleted — clone them instead.');
        redirect('/admin/inbox/templates');
    }

    // ---- Direct messages: member ⇄ support conversations ----

    public function messages()
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $search = trim((string) $this->input->get('q', true));
        $data = $this->base('Messages', 'messages');
        $data['threads'] = $this->AIWorkforce_model->messages->threads($search);
        $data['counts'] = $this->AIWorkforce_model->messages->counts();
        $data['search'] = $search;
        $data['canManage'] = $this->platform->identity->can($actor, 'admin.users.manage');
        $this->render('admin/messages/index', $data);
    }

    public function message_user($userId = 0)
    {
        $actor = $this->gate('admin.users.view'); if (!$actor) return;
        $member = $this->findPublicUser((int) $userId);
        if (!$member) { $this->flash('error', 'User not found.'); redirect('/admin/messages'); return; }
        // Opening the thread acknowledges every member message in it.
        $this->AIWorkforce_model->messages->markReadByAdmin((int) $member['id']);
        $data = $this->base('Message · ' . ($member['user_uid'] ?? $member['id']), 'messages');
        $data['member'] = $member;
        $data['thread'] = $this->AIWorkforce_model->messages->threadFor((int) $member['id']);
        $data['canManage'] = $this->platform->identity->can($actor, 'admin.users.manage');
        $this->render('admin/messages/view', $data);
    }

    /** Reply in a thread or start a new conversation (both forms post here). */
    public function message_send()
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/messages'); return; }
        $targetRef = trim((string) $this->input->post('user'));
        $body = \AIWorkforce\Messaging\DirectMessages::cleanBody((string) $this->input->post('body'));
        $returnTo = '/admin/messages';
        if (ctype_digit($targetRef) && (int) $targetRef > 0) $returnTo .= '/user/' . (int) $targetRef;

        $member = $this->resolveUserTarget($targetRef);
        if (!$member) {
            $this->flash('error', 'Enter a valid recipient — numeric ID, User ID, username or email.');
            redirect($returnTo); return;
        }
        if (!\AIWorkforce\Messaging\DirectMessages::validBody($body)) {
            $this->flash('error', 'Write a message of 1–' . \AIWorkforce\Messaging\DirectMessages::MAX_BODY . ' characters.');
            redirect('/admin/messages/user/' . (int) $member['id']); return;
        }
        $this->AIWorkforce_model->messages->append([
            'user_id' => (int) $member['id'],
            'sender_id' => (int) $actor['id'],
            'sender_role' => 'admin',
            'sender_label' => (string) ($actor['display_name'] ?? $actor['email'] ?? 'Support'),
            'body' => $body,
        ]);
        try {
            $this->portal->log($actor, 'MESSAGE_SENT', 'ok', $this->portal->userTarget($member), [
                'chars' => mb_strlen($body),
            ], $this->ip());
        } catch (\Throwable $_) {}
        $this->flash('notice', 'Message sent to ' . ($member['username'] ?? $member['email'] ?? 'user') . '.');
        redirect('/admin/messages/user/' . (int) $member['id']);
    }

    // ---- Admin-sent notifications (member Alerts inbox) ----

    public function notification_send()
    {
        $actor = $this->gate('admin.users.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/notifications'); return; }
        $target = (string) $this->input->post('target') === 'all' ? 'all' : 'user';
        $severity = (string) $this->input->post('severity');
        if (!in_array($severity, ['info', 'warning', 'critical'], true)) $severity = 'info';
        $title = mb_substr(trim((string) $this->input->post('title')), 0, 200);
        $message = mb_substr(trim((string) $this->input->post('message')), 0, 2000);
        if ($title === '' || $message === '') {
            $this->flash('error', 'A title and a message are required.');
            redirect('/admin/notifications'); return;
        }
        $from = (string) ($actor['display_name'] ?? $actor['email'] ?? 'Administrator');
        $detail = ['message' => $message, 'from' => $from, 'sentVia' => 'admin console'];

        if ($target === 'all') {
            $recipients = $this->AIWorkforce_model->identity->activeRecipients();
            $sent = 0;
            foreach ($recipients as $recipient) {
                $result = $this->platform->notifications->notify('admin_broadcast', $severity, $title, $detail, null, (int) $recipient['id']);
                if (!empty($result['created'])) $sent++;
            }
            try {
                $this->portal->log($actor, 'NOTIFICATION_SENT', 'ok', [
                    'type' => 'notification', 'id' => 'broadcast', 'label' => 'all users',
                ], ['severity' => $severity, 'title' => $title, 'delivered' => $sent, 'recipients' => count($recipients)], $this->ip());
            } catch (\Throwable $_) {}
            $this->flash('notice', "Notification delivered to {$sent} active user" . ($sent === 1 ? '' : 's') . '.');
        } else {
            $member = $this->resolveUserTarget(trim((string) $this->input->post('user')));
            if (!$member) {
                $this->flash('error', 'User not found — enter a numeric ID, User ID, username or email.');
                redirect('/admin/notifications'); return;
            }
            $this->platform->notifications->notify('admin_message', $severity, $title, $detail, null, (int) $member['id']);
            try {
                $this->portal->log($actor, 'NOTIFICATION_SENT', 'ok', $this->portal->userTarget($member), [
                    'severity' => $severity, 'title' => $title, 'delivered' => 1,
                ], $this->ip());
            } catch (\Throwable $_) {}
            $this->flash('notice', 'Notification sent to ' . ($member['username'] ?? $member['email'] ?? 'user') . '.');
        }
        redirect('/admin/notifications');
    }

    /** Resolve a free-text admin entry to one user: id, User ID, username or email. */
    private function resolveUserTarget(string $q): ?array
    {
        $q = trim($q);
        if ($q === '') return null;
        $identity = $this->AIWorkforce_model->identity;
        if (ctype_digit($q)) {
            $byId = $identity->findUserById((int) $q);
            if ($byId) return $byId;
        }
        $byIdentifier = $identity->findUserByIdentifier($q); // email / six-digit User ID / username
        if ($byIdentifier) return $byIdentifier;
        // Partial match as a last resort — only when it names exactly one account.
        $result = $identity->searchUsers(['q' => $q], 'id', 'ASC', 1, 5);
        $rows = $result['rows'] ?? [];
        return count($rows) === 1 ? $rows[0] : null;
    }

    public function reports()
    {
        $actor = $this->gate('admin.analytics.view'); if (!$actor) return;
        $data = $this->base('Reports', 'reports');
        $data['overview'] = $this->portal->analyticsOverview();
        $data['stats'] = $this->portal->dashboardStats();
        $this->render('admin/reports', $data);
    }

    public function settings()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        $data = $this->base('System Settings', 'settings');
        $data['settings'] = $this->portal->settingsByCategory();
        $data['smtp'] = \AIWorkforce\Mailer::configSummary();
        $data['smtpOk'] = $this->session->flashdata('smtpOk');
        $data['smtpError'] = $this->session->flashdata('smtpError');
        $data['session'] = [
            'expiration' => (int) $this->config->item('sess_expiration'),
            'httponly' => (bool) $this->config->item('cookie_httponly'),
            'samesite' => (string) $this->config->item('sess_samesite'),
            'secure' => (bool) $this->config->item('cookie_secure'),
        ];
        $this->render('admin/settings', $data);
    }

    public function settings_save()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/settings'); return; }
        $category = (string) $this->input->post('category');
        if (!isset(\AIWorkforce\AdminPortal::SETTING_DEFAULTS[$category])) {
            $this->flash('error', 'Unknown settings category.'); redirect('/admin/settings'); return;
        }
        $values = [];
        foreach (array_keys(\AIWorkforce\AdminPortal::SETTING_DEFAULTS[$category]) as $key) {
            $values[$key] = (string) $this->input->post($key);
        }
        if ($category === 'ai' || $category === 'accounts') {
            foreach ($values as $k => $v) $values[$k] = $v === '1' ? '1' : '0';
        }
        if ($category === 'announcement') {
            $values['announcement_enabled'] = ($values['announcement_enabled'] ?? '') === '1' ? '1' : '0';
        }
        if ($category === 'security') {
            $values['login_max_attempts'] = (string) max(3, min(20, (int) ($values['login_max_attempts'] ?? 5)));
            $values['login_lockout_seconds'] = (string) max(60, min(86400, (int) ($values['login_lockout_seconds'] ?? 900)));
        }
        try {
            $this->portal->saveSettings($values, $category, (int) $actor['id'], $category === 'announcement' ? 2000 : 500);
            $this->portal->log($actor, 'SETTINGS_CHANGED', 'ok', ['type' => 'settings', 'id' => $category, 'label' => $category], array_keys($values), $this->ip());
            $this->flash('notice', '✓ Changes saved successfully');
        } catch (Throwable $e) {
            log_message('error', 'admin settings_save failed: ' . $e->getMessage());
            $this->flash('error', 'Unable to save your changes. Please try again.');
        }
        redirect('/admin/settings#' . $category);
    }

    public function test_email()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/settings'); return; }
        $to = strtolower(trim((string) $this->input->post('to')));
        $variant = $this->input->post('variant') === 'plain' ? 'plain' : 'html';
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            $this->flash('error', 'Enter a valid recipient email address.');
            redirect('/admin/settings#email'); return;
        }
        $res = \AIWorkforce\Mailer::sendTest($this, $to, $variant);
        $this->portal->log($actor, 'SETTINGS_CHANGED', $res['ok'] ? 'ok' : 'error', ['type' => 'email', 'id' => 'test', 'label' => $to], ['ok' => $res['ok']], $this->ip());
        $this->session->set_flashdata($res['ok'] ? 'smtpOk' : 'smtpError', $res['message']);
        redirect('/admin/settings#email');
    }

    public function admins()
    {
        $actor = $this->gate('admin.admins.manage'); if (!$actor) return;
        $data = $this->base('Admin Accounts', 'admins');
        $data['admins'] = $this->AIWorkforce_model->identity->listAdminAccounts();
        $data['adminRoles'] = array_values(array_filter(
            $this->AIWorkforce_model->identity->listRoles(),
            fn($r) => in_array($r['code'], \AIWorkforce\AdminPortal::ADMIN_ROLES, true)
        ));
        $this->render('admin/admins', $data);
    }

    public function create_admin()
    {
        $actor = $this->gate('admin.admins.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/admins'); return; }
        $username = strtolower(trim((string) $this->input->post('username')));
        $email = strtolower(trim((string) $this->input->post('email')));
        $password = (string) $this->input->post('password');
        $roleCode = trim((string) $this->input->post('role'));
        if (!in_array($roleCode, \AIWorkforce\AdminPortal::ADMIN_ROLES, true)) $roleCode = 'admin';
        if (!$this->validUsername($username) || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12) {
            $this->flash('error', 'Enter a valid username, email and a password of at least 12 characters.');
            redirect('/admin/admins'); return;
        }
        if ($this->AIWorkforce_model->identity->findUserByEmail($email) || $this->AIWorkforce_model->identity->usernameTaken($username)) {
            $this->flash('error', 'That username or email is already in use.');
            redirect('/admin/admins'); return;
        }
        $now = gmdate('c');
        $new = $this->AIWorkforce_model->identity->createUser([
            'username' => $username, 'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'display_name' => $username, 'active' => 1,
            'created_at' => $now, 'updated_at' => $now, 'last_login_at' => null,
        ]);
        $role = $this->AIWorkforce_model->identity->ensureRole($roleCode, ucwords(str_replace('_', ' ', $roleCode)));
        $this->AIWorkforce_model->identity->assignRole((int) $new['id'], $role);
        $this->portal->log($actor, 'ADMIN_CREATED', 'ok', $this->portal->userTarget($new), ['role' => $roleCode], $this->ip());
        $this->flash('notice', 'Administrator account created. The temporary password is not stored.');
        redirect('/admin/admins');
    }

    public function update_admin($id = 0)
    {
        $actor = $this->gate('admin.admins.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/admins'); return; }
        $id = (int) $id;
        $target = $this->findPublicUser($id);
        if (!$target) { $this->flash('error', 'Administrator not found.'); redirect('/admin/admins'); return; }
        $roleCode = trim((string) $this->input->post('role'));
        $status = $this->input->post('active') === '1';
        if (!in_array($roleCode, \AIWorkforce\AdminPortal::ADMIN_ROLES, true)) {
            $this->flash('error', 'Choose a valid administrator role.'); redirect('/admin/admins'); return;
        }
        if ((int) $actor['id'] === $id && !$status) {
            $this->flash('error', 'You cannot disable your own administrator account.'); redirect('/admin/admins'); return;
        }
        if (!$status && $this->AIWorkforce_model->identity->userHasRole($id, 'super_admin') && $this->AIWorkforce_model->identity->countSuperAdmins() <= 1) {
            $this->flash('error', 'The last Super Admin cannot be disabled.'); redirect('/admin/admins'); return;
        }
        $role = $this->AIWorkforce_model->identity->findRoleByCode($roleCode);
        if ($role) $this->AIWorkforce_model->identity->replaceUserRoles($id, [(int) $role['id']]);
        $this->AIWorkforce_model->identity->setActive($id, $status);
        $this->portal->log($actor, 'ADMIN_PERMISSIONS_CHANGED', 'ok', $this->portal->userTarget($target), ['role' => $roleCode, 'active' => $status], $this->ip());
        $this->flash('notice', 'Administrator account updated.');
        redirect('/admin/admins');
    }

    public function logs()
    {
        $actor = $this->gate('admin.logs.view'); if (!$actor) return;
        $q = trim((string) $this->input->get('q', true));
        $action = trim((string) $this->input->get('action', true));
        $page = max(1, (int) $this->input->get('page'));
        $result = $this->portal->activityLogs(['q' => $q, 'action' => $action], $page, 30);
        $data = $this->base('Activity Logs', 'logs');
        $data = array_merge($data, $result);
        $data['q'] = $q;
        $data['actionFilter'] = $action;
        $this->render('admin/logs', $data);
    }

    public function security()
    {
        $actor = $this->gate('admin.security.view'); if (!$actor) return;
        $data = $this->base('Security', 'security');
        $data['overview'] = $this->portal->securityOverview();
        $data['session'] = [
            'expiration' => (int) $this->config->item('sess_expiration'),
            'httponly' => (bool) $this->config->item('cookie_httponly'),
            'samesite' => (string) $this->config->item('sess_samesite'),
            'secure' => (bool) $this->config->item('cookie_secure'),
            'regenerate' => (bool) $this->config->item('sess_regenerate_destroy'),
        ];
        $this->render('admin/security', $data);
    }

    public function cron()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        $store = new \AIWorkforce\Cron\PlatformSettingsCronStore($this->AIWorkforce_model->db);
        $scheduler = new \AIWorkforce\Cron\CronScheduler($store);
        $data = $this->base('Cron Jobs', 'cron');
        $data['jobs'] = $scheduler->status();
        $data['autoRun'] = $store->get('cron.auto_run') === '1';
        $data['lastTrigger'] = $store->get('cron.last_trigger');
        $data['secret'] = \AIWorkforce\Cron\CronSecrets::ensure($store);
        $data['runUrl'] = $this->cronRunUrl($data['secret']);
        $data['cliCommand'] = 'php ' . FCPATH . 'index.php tools scheduler';
        $data['recent'] = $this->recentCronEvents();
        $this->render('admin/cron', $data);
    }

    public function cron_save()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/cron'); return; }
        $store = new \AIWorkforce\Cron\PlatformSettingsCronStore($this->AIWorkforce_model->db);
        $scheduler = new \AIWorkforce\Cron\CronScheduler($store);
        $store->set('cron.auto_run', $this->input->post('auto_run') === '1' ? '1' : '0');
        foreach (array_keys(\AIWorkforce\Cron\CronScheduler::JOBS) as $id) {
            $scheduler->setEnabled($id, $this->input->post('enabled_' . $id) === '1');
        }
        $this->portal->log($actor, 'CRON_SETTINGS_CHANGED', 'ok', ['type' => 'cron', 'id' => 'schedule', 'label' => 'Cron schedule'], [], $this->ip());
        $this->flash('notice', 'Cron schedule saved.');
        redirect('/admin/cron');
    }

    public function cron_run($job = '')
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/cron'); return; }
        $job = (string) $job;
        $runners = \AIWorkforce\Cron\CronRunner::runners($this);
        if (!isset($runners[$job])) { $this->flash('error', 'Unknown cron job.'); redirect('/admin/cron'); return; }
        @set_time_limit(600);
        $store = new \AIWorkforce\Cron\PlatformSettingsCronStore($this->AIWorkforce_model->db);
        $scheduler = new \AIWorkforce\Cron\CronScheduler($store);
        try {
            $result = $scheduler->runJob($job, $runners[$job]);
        } catch (\Throwable $e) {
            $this->flash('error', 'Run failed: ' . mb_substr($e->getMessage(), 0, 200));
            redirect('/admin/cron'); return;
        }
        $this->portal->log($actor, 'CRON_RUN_MANUAL', ($result['status'] ?? '') === 'FAILED' ? 'error' : 'ok', ['type' => 'cron', 'id' => $job, 'label' => $job], ['status' => $result['status'] ?? '?'], $this->ip());
        if (empty($result['ran'])) {
            $this->flash('error', 'Job ' . $job . ' did not run: ' . ($result['reason'] ?? ($result['status'] ?? 'skipped')) . '.');
        } else {
            $this->flash('notice', 'Job ' . $job . ' finished: ' . ($result['status'] ?? '?') . ' in ' . number_format((int) ($result['durationMs'] ?? 0) / 1000, 1) . 's.');
        }
        redirect('/admin/cron');
    }

    public function cron_secret()
    {
        $actor = $this->gate('admin.settings.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/cron'); return; }
        $store = new \AIWorkforce\Cron\PlatformSettingsCronStore($this->AIWorkforce_model->db);
        \AIWorkforce\Cron\CronSecrets::regenerate($store);
        $this->portal->log($actor, 'CRON_SECRET_REGENERATED', 'ok', ['type' => 'cron', 'id' => 'secret', 'label' => 'Cron URL secret'], [], $this->ip());
        $this->flash('notice', 'New cron URL secret generated — update your hosting cron command with the new URL below.');
        redirect('/admin/cron');
    }

    /** Secret cron URL, with a Host-header fallback when base_url is empty. */
    private function cronRunUrl(string $secret): string
    {
        $base = rtrim((string) $this->config->item('base_url'), '/');
        if ($base === '') {
            $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
            $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
            $base = ($https ? 'https://' : 'http://') . $host;
        }
        return $base . '/cron/run?key=' . $secret;
    }

    /** Latest cron-related audit events for the dashboard's activity panel. */
    private function recentCronEvents(): array
    {
        try {
            $rows = $this->AIWorkforce_model->audit->recent(120);
        } catch (\Throwable $e) {
            return [];
        }
        $out = [];
        foreach ($rows as $row) {
            $type = (string) ($row['type'] ?? '');
            if (!preg_match('/CRON|JOB_FAILED|CLEANUP|SETTLEMENT_SWEEP|QUALITY_RECALC|MONITORING$/', $type)) continue;
            $out[] = ['at' => (string) ($row['at'] ?? ''), 'type' => $type, 'summary' => (string) ($row['summary'] ?? '')];
            if (count($out) >= 15) break;
        }
        return $out;
    }

    public function api()
    {
        $actor = $this->gate('admin.api.view'); if (!$actor) return;
        \AIWorkforce\ApiProviders::ensureSchema($this->AIWorkforce_model->db);
        $data = $this->base('API Management', 'api');
        $data['dashboard'] = \AIWorkforce\ApiProviders::dashboard($this->AIWorkforce_model->db);
        $data['canManage'] = $this->platform->identity->can($actor, 'admin.api.manage');
        $data['canTest'] = $this->platform->identity->can($actor, 'admin.api.test');
        $this->render('admin/api/index', $data);
    }

    public function api_create()
    {
        $actor = $this->gate('admin.api.manage'); if (!$actor) return;
        $this->renderApiForm($actor, null);
    }

    public function api_show($id = 0)
    {
        $actor = $this->gate('admin.api.view'); if (!$actor) return;
        \AIWorkforce\ApiProviders::ensureSchema($this->AIWorkforce_model->db);
        $row = \AIWorkforce\ApiProviders::find($this->AIWorkforce_model->db, (int) $id);
        if (!$row) { $this->flash('error', 'Provider not found.'); redirect('/admin/api'); return; }
        $this->renderApiForm($actor, $row);
    }

    public function api_save($id = 0)
    {
        $actor = $this->gate('admin.api.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/api'); return; }
        $canSecrets = $this->platform->identity->can($actor, 'admin.api.credentials') || $this->isSuperAdmin($actor);
        try {
            $saved = \AIWorkforce\ApiProviders::save($this->AIWorkforce_model->db, $this->input->post() ?: [], $id ? (int) $id : null, (int) $actor['id'], $canSecrets);
            $this->portal->log($actor, $id ? 'API_PROVIDER_UPDATED' : 'API_PROVIDER_CREATED', 'ok', [
                'type' => 'api_provider', 'id' => (string) ($saved['id'] ?? ''), 'label' => (string) ($saved['label'] ?? ''),
            ], ['service' => $saved['service'] ?? '', 'driver' => $saved['driver'] ?? '', 'role' => $saved['role'] ?? ''], $this->ip());
            $this->syncMarketData((string) ($saved['service'] ?? ''), $actor);
            redirect('/admin/api/' . (int) ($saved['id'] ?? 0));
        } catch (Throwable $e) {
            log_message('error', 'api_save failed: ' . $e->getMessage());
            $this->flash('error', $e instanceof InvalidArgumentException ? $e->getMessage() : 'Unable to save your changes. Please try again.');
            redirect($id ? '/admin/api/' . (int) $id : '/admin/api/create');
        }
    }

    public function api_test($id = 0)
    {
        $actor = $this->gate('admin.api.test'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/api'); return; }
        $row = \AIWorkforce\ApiProviders::find($this->AIWorkforce_model->db, (int) $id);
        if (!$row) { $this->flash('error', 'Provider not found.'); redirect('/admin/api'); return; }
        $secrets = \AIWorkforce\ApiProviders::findSecrets($this->AIWorkforce_model->db, (int) $id);
        $result = \AIWorkforce\ApiProviders::test($row, $secrets);
        \AIWorkforce\ApiProviders::recordTest($this->AIWorkforce_model->db, (int) $id, $result);
        $this->portal->log($actor, 'API_PROVIDER_TESTED', !empty($result['ok']) ? 'ok' : 'error', [
            'type' => 'api_provider', 'id' => (string) $id, 'label' => $row['label'],
        ], ['ok' => !empty($result['ok']), 'ms' => $result['ms'] ?? null], $this->ip());
        $detail = trim((string) ($result['message'] ?? ''));
        $flash = !empty($result['ok'])
            ? ('✓ ' . ($detail !== '' ? $detail : 'Connected'))
            : ('✕ ' . ($detail !== '' ? $detail : 'Connection failed'));
        $this->flash(!empty($result['ok']) ? 'notice' : 'error', $flash);
        redirect('/admin/api/' . (int) $id);
    }

    public function api_enable($id = 0)
    {
        $this->apiToggle((int) $id, true);
    }

    public function api_disable($id = 0)
    {
        $this->apiToggle((int) $id, false);
    }

    public function api_primary($id = 0)
    {
        $actor = $this->gate('admin.api.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/api'); return; }
        $row = \AIWorkforce\ApiProviders::find($this->AIWorkforce_model->db, (int) $id);
        if (!$row) { $this->flash('error', 'Provider not found.'); redirect('/admin/api'); return; }
        \AIWorkforce\ApiProviders::setRole($this->AIWorkforce_model->db, (int) $id, 'primary');
        $this->portal->log($actor, 'API_PROVIDER_UPDATED', 'ok', ['type' => 'api_provider', 'id' => (string) $id, 'label' => $row['label']], ['role' => 'primary'], $this->ip());
        $this->syncMarketData((string) ($row['service'] ?? ''), $actor);
        redirect('/admin/api');
    }

    public function api_delete($id = 0)
    {
        $actor = $this->gate('admin.api.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/api'); return; }
        $row = \AIWorkforce\ApiProviders::find($this->AIWorkforce_model->db, (int) $id);
        if (!$row) { $this->flash('error', 'Provider not found.'); redirect('/admin/api'); return; }
        \AIWorkforce\ApiProviders::delete($this->AIWorkforce_model->db, (int) $id);
        $this->portal->log($actor, 'API_PROVIDER_DELETED', 'ok', ['type' => 'api_provider', 'id' => (string) $id, 'label' => $row['label']], ['service' => $row['service']], $this->ip());
        $this->syncMarketData((string) ($row['service'] ?? ''), $actor);
        redirect('/admin/api');
    }

    public function add_language()
    {
        $actor = $this->isSuperAdmin($this->currentUser());
        if (!$actor) {
            $this->flash('error', 'Super admin access required.');
            redirect('/admin');
            return;
        }

        $code = strtolower(trim((string) $this->input->post('code')));
        $name = trim((string) $this->input->post('name'));
        $native_name = trim((string) ($this->input->post('native_name') ?: ''));
        $writing_system = trim((string) $this->input->post('writing_system'));
        $direction = strtolower(trim((string) $this->input->post('direction')));

        // Validate language code format (ISO 639-1/3: 2-3 lowercase letters)
        if (!preg_match('/^[a-z]{2,3}$/', $code)) {
            $this->flash('error', 'Language code must be 2-3 lowercase letters (ISO 639-1/3 format).');
            redirect('/admin/languages');
            return;
        }

        // Validate required fields
        if ($name === '') {
            $this->flash('error', 'English name is required.');
            redirect('/admin/languages');
            return;
        }

        if (!in_array($writing_system, ['latin', 'cyrillic', 'devanagari', 'arabic', 'han', 'kana', 'hangul'])) {
            $this->flash('error', 'Invalid writing system.');
            redirect('/admin/languages');
            return;
        }

        if (!in_array($direction, ['ltr', 'rtl'])) {
            $this->flash('error', 'Invalid direction.');
            redirect('/admin/languages');
            return;
        }

        // Register the language using the LanguageRegistry
        try {
            \AIWorkforce\LangLearn\LanguageRegistry::register([
                'code' => $code,
                'name' => $name,
                'native_name' => $native_name !== '' ? $native_name : $name,
                'iso_code' => $code,
                'writing_system' => $writing_system,
                'direction' => $direction,
                'active' => true,
            ]);
            $this->flash('notice', "Language '{$name}' ({$code}) registered successfully.");
        } catch (\InvalidArgumentException $e) {
            $this->flash('error', $e->getMessage());
        } catch (\Throwable $e) {
            $this->flash('error', 'Failed to register language: ' . $e->getMessage());
        }

        redirect('/admin/languages');
    }

    private function apiToggle(int $id, bool $enabled): void
    {
        $actor = $this->gate('admin.api.manage'); if (!$actor) return;
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/api'); return; }
        $row = \AIWorkforce\ApiProviders::find($this->AIWorkforce_model->db, $id);
        if (!$row) { $this->flash('error', 'Provider not found.'); redirect('/admin/api'); return; }
        \AIWorkforce\ApiProviders::setEnabled($this->AIWorkforce_model->db, $id, $enabled);
        $this->portal->log($actor, $enabled ? 'API_PROVIDER_ENABLED' : 'API_PROVIDER_DISABLED', 'ok', [
            'type' => 'api_provider', 'id' => (string) $id, 'label' => $row['label'],
        ], ['service' => $row['service']], $this->ip());
        $this->syncMarketData((string) ($row['service'] ?? ''), $actor);
        redirect('/admin/api');
    }

    /**
     * Make a market-data provider change take effect immediately, and tell the
     * operator the truth about what it did.
     *
     * Rebuilds the provider chain in this process (next request rebuilds from
     * the store anyway) and replaces the generic "saved" flash with the actual
     * outcome: LIVE, or CONNECTED·NOT ENABLED — the dark state that otherwise
     * leaves the chart silently streaming the labelled simulation.
     */
    private function syncMarketData(string $service, ?array $actor = null): void
    {
        if (!in_array($service, \AIWorkforce\ApiProviders::MARKET_DATA_SERVICES, true)) {
            $this->flash('notice', '✓ Changes saved successfully');
            return;
        }
        $refresh = null;
        try { $refresh = $this->platform->refreshMarketDataProviders(); } catch (Throwable $e) { $refresh = null; }
        $state = \AIWorkforce\ApiProviders::serviceState($this->AIWorkforce_model->db, $service);
        if (!empty($state['live'])) {
            if (is_array($actor) && !empty($actor['id'])) {
                $this->portal->log($actor, 'MARKET_DATA_LIVE', 'ok', [
                    'type' => 'api_provider', 'id' => $service, 'label' => (string) $state['label'],
                ], [
                    'driver' => $state['driver'],
                    'registered' => is_array($refresh['registered'] ?? null) ? count($refresh['registered']) : null,
                ], $this->ip());
            }
            $this->flash('notice', '✓ ' . $state['label'] . ' is LIVE — the market-data chart now streams real bars from ' . (string) $state['driver'] . '.');
            return;
        }
        $this->flash('error', $state['label'] . ' is connected but NOT ENABLED — the chart stays on the labelled simulation until an enabled provider serves it.');
    }

    private function renderApiForm(array $actor, ?array $row): void
    {
        $data = $this->base($row ? 'Manage provider' : 'Add provider', 'api');
        $data['row'] = $row;
        $data['services'] = \AIWorkforce\ApiProviders::services();
        $data['drivers'] = \AIWorkforce\ApiProviders::drivers();
        $data['canManage'] = $this->platform->identity->can($actor, 'admin.api.manage');
        $data['canTest'] = $this->platform->identity->can($actor, 'admin.api.test');
        $data['canSecrets'] = $this->platform->identity->can($actor, 'admin.api.credentials') || $this->isSuperAdmin($actor);
        $this->render('admin/api/form', $data);
    }

    /** Only administrators with portal access may enter. Super Admin holds system.super_admin. */
    private function requireAdmin(): ?array
    {
        return $this->requireAdminPage();
    }

    private function gate(string $permission): ?array
    {
        return $this->requireAdminPermission($permission);
    }

    private function setStatus(int $id, array $actor, bool $active): void
    {
        if (!$this->validCsrf()) { $this->flash('error', 'Invalid security token.'); redirect('/admin/users'); return; }
        if ((int) $actor['id'] === $id && !$active) {
            $this->flash('error', 'You cannot suspend your own administrator account.');
            redirect('/admin/users/' . $id); return;
        }
        $target = $this->findPublicUser($id);
        if (!$target) { $this->flash('error', 'User not found.'); redirect('/admin/users'); return; }
        if (!$active && $this->AIWorkforce_model->identity->userHasRole($id, 'super_admin') && $this->AIWorkforce_model->identity->countSuperAdmins() <= 1) {
            $this->flash('error', 'The last Super Admin cannot be suspended.');
            redirect('/admin/users/' . $id); return;
        }
        $this->AIWorkforce_model->identity->setActive($id, $active);
        $this->portal->log($actor, $active ? 'USER_ACTIVATED' : 'USER_SUSPENDED', 'ok', $this->portal->userTarget($target), [], $this->ip());
        $this->flash('notice', $active ? 'Account activated.' : 'Account suspended. The user can no longer sign in.');
        redirect('/admin/users/' . $id);
    }

    private function canImpersonate(array $actor, array $target): bool
    {
        if ((int) $actor['id'] === (int) $target['id']) return false;
        if (empty($target['active'])) return false;
        if (!$this->platform->identity->can($actor, 'admin.users.impersonate')) return false;
        if ($this->isSuperAdmin($actor)) return true;
        return !$this->portal->isAdminAccount($target);
    }

    private function roleAllowed(array $actor, string $roleCode): bool
    {
        foreach ($this->portal->assignableRoles($actor) as $role) {
            if ($role['code'] === $roleCode) return true;
        }
        return false;
    }

    private function findPublicUser(int $id, bool $includeRecovery = false): ?array
    {
        $user = $this->AIWorkforce_model->identity->findUserById($id);
        if (!$user) return null;
        $user = $this->portal->publicUser($user, $includeRecovery);
        $user['permissions'] = $this->AIWorkforce_model->identity->permissionsForUser($id);
        $user['roles'] = $this->AIWorkforce_model->identity->rolesForUser($id);
        return $user;
    }

    private function handleAvatarUpload(int $userId, array $member): void
    {
        if (empty($_FILES['avatar']) || (int) ($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return;
        $tmp = (string) $_FILES['avatar']['tmp_name'];
        $size = (int) $_FILES['avatar']['size'];
        if ($size <= 0 || $size > 2 * 1024 * 1024) return;
        $info = @getimagesize($tmp);
        if ($info === false) return;
        $allowed = [IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
        $ext = $allowed[$info[2]] ?? null;
        if ($ext === null) return;
        $uploadDir = FCPATH . 'assets/uploads/avatars';
        if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);
        if (!is_dir($uploadDir) || !is_writable($uploadDir)) return;
        $filename = 'u' . $userId . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
        if (!@move_uploaded_file($tmp, $uploadDir . '/' . $filename)) return;
        $path = '/assets/uploads/avatars/' . $filename;
        $this->AIWorkforce_model->identity->updateUser($userId, ['profile_image' => $path]);
        $previous = (string) ($member['profile_image'] ?? '');
        if ($previous !== '' && str_starts_with($previous, '/assets/uploads/avatars/')) {
            $old = FCPATH . ltrim($previous, '/');
            if ($old !== $uploadDir . '/' . $filename && is_file($old)) @unlink($old);
        }
    }

    private function validUsername(string $username): bool
    {
        return (bool) preg_match('/^[a-z][a-z0-9_]{2,19}$/', $username);
    }

    private function randomPassword(): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
        $out = '';
        for ($i = 0; $i < 16; $i++) $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        return $out;
    }

    private function validCsrf(): bool
    {
        $sent = (string) $this->input->post('csrf_token');
        $known = (string) $this->session->userdata('csrf_token');
        return $sent !== '' && $known !== '' && hash_equals($known, $sent);
    }

    private function ip(): string
    {
        return (string) $this->input->ip_address();
    }

    private function base(string $title, string $active): array
    {
        $state = $this->platform->state();
        $identity = $this->adminActor() ?: $this->currentUser();
        return [
            'title' => $title,
            'active' => $active,
            'adminUser' => $identity,
            'adminPerms' => $identity['permissions'] ?? [],
            'isSuperAdmin' => $this->isSuperAdmin($identity),
            'status' => ['tradingMode' => $state['tradingMode'], 'killSwitch' => $state['killSwitch'], 'providers' => $this->platform->providers->getAllHealth()],
            'csrfToken' => (string) $this->session->userdata('csrf_token'),
            'notice' => $this->session->flashdata('notice'),
            'error' => $this->session->flashdata('error'),
            'tempPassword' => $this->session->flashdata('temp_password'),
            'productName' => $this->portal->setting('product_name', 'WINDELS AI WORKFORCE'),
        ];
    }

    private function render(string $view, array $data): void
    {
        $this->load->view('admin/layout/header', $data);
        $this->load->view($view, $data);
        $this->load->view('admin/layout/footer');
    }

    private function flash(string $key, string $msg): void
    {
        $this->session->set_flashdata($key, $msg);
    }
}
