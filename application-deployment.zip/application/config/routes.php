<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| Traditional MVC pages (server-rendered views) plus a JSON API layer.
*/
$route['default_controller'] = 'site';
$route['404_override'] = '';
$route['about'] = 'site/about';
$route['services'] = 'site/services';
$route['how-it-works'] = 'site/how_it_works';
$route['locations'] = 'site/locations';
$route['coverage'] = 'site/locations';
$route['safety'] = 'site/safety';
$route['faq'] = 'site/faq';
$route['help'] = 'site/faq';
$route['contact'] = 'site/contact';
$route['contact/submit'] = 'site/contact_submit';
$route['login'] = 'auth/index';
$route['admin/login'] = 'auth/admin_login';
$route['login/submit'] = 'auth/login';
$route['register'] = 'auth/register';
$route['register/submit'] = 'auth/register_submit';
$route['forgot-password'] = 'auth/forgot';
$route['forgot-password/submit'] = 'auth/forgot_submit';
$route['access-denied'] = 'auth/denied';
$route['logout'] = 'auth/logout';
$route['account'] = 'auth/account';
$route['account/username'] = 'auth/update_username';
$route['account/email'] = 'auth/update_email';
$route['account/contact'] = 'auth/update_contact';
$route['account/recovery'] = 'auth/update_recovery';
$route['account/password'] = 'auth/change_password';
$route['account/avatar'] = 'auth/upload_avatar';
$route['account/avatar/remove'] = 'auth/remove_avatar';
$route['dashboard'] = 'workspace/index';
$route['analysis'] = 'welcome';
$route['robots.txt'] = 'seo/robots';
$route['sitemap.xml'] = 'seo/sitemap';
$route['admin'] = 'admin/index';
$route['admin/dashboard'] = 'admin/index';
$route['admin/users'] = 'admin/users';
$route['admin/users/create'] = 'admin/create_user';
$route['admin/users/(:num)/edit'] = 'admin/edit_user/$1';
$route['admin/users/(:num)/suspend'] = 'admin/suspend_user/$1';
$route['admin/users/(:num)/activate'] = 'admin/activate_user/$1';
$route['admin/users/(:num)/delete'] = 'admin/delete_user/$1';
$route['admin/users/(:num)/reset-password'] = 'admin/reset_password/$1';
$route['admin/users/(:num)/impersonate'] = 'admin/impersonate/$1';
$route['admin/users/(:num)/toggle'] = 'admin/toggle_user/$1';
$route['admin/users/(:num)'] = 'admin/user/$1';
$route['admin/impersonation/return'] = 'admin/stop_impersonation';
$route['admin/search'] = 'admin/search';
$route['admin/workforce'] = 'admin/workforce';
$route['admin/languages'] = 'admin/languages';
$route['admin/conversations'] = 'admin/conversations';
$route['admin/analytics'] = 'admin/analytics';
$route['admin/notifications'] = 'admin/notifications';
$route['admin/notifications/send'] = 'admin/notification_send';
$route['admin/reports'] = 'admin/reports';
$route['admin/settings'] = 'admin/settings';
$route['admin/settings/save'] = 'admin/settings_save';
$route['admin/settings/football-toggle'] = 'admin/football_provider_toggle';
$route['admin/api'] = 'admin/api';
$route['admin/api/create'] = 'admin/api_create';
$route['admin/api/save'] = 'admin/api_save';
$route['admin/api/(:num)/save'] = 'admin/api_save/$1';
$route['admin/api/(:num)/test'] = 'admin/api_test/$1';
$route['admin/api/(:num)/sync'] = 'admin/api_sync/$1';
$route['admin/api/(:num)/enable'] = 'admin/api_enable/$1';
$route['admin/api/(:num)/disable'] = 'admin/api_disable/$1';
$route['admin/api/(:num)/primary'] = 'admin/api_primary/$1';
$route['admin/api/(:num)/delete'] = 'admin/api_delete/$1';
$route['admin/api/(:num)'] = 'admin/api_show/$1';
$route['admin/test-email'] = 'admin/test_email';
$route['admin/admins'] = 'admin/admins';
$route['admin/admins/create'] = 'admin/create_admin';
$route['admin/admins/(:num)'] = 'admin/update_admin/$1';
$route['admin/logs'] = 'admin/logs';
$route['admin/security'] = 'admin/security';
$route['admin/protection'] = 'admin/protection';
$route['admin/protection/save'] = 'admin/protection_save';
$route['admin/protection/reset-peak'] = 'admin/protection_reset_peak';
$route['admin/protection/ea/limits'] = 'admin/protection_ea_limits';
$route['admin/protection/ea/policy'] = 'admin/protection_ea_policy';
$route['admin/protection/ea/account'] = 'admin/protection_ea_account';
$route['admin/protection/ea/remove'] = 'admin/protection_ea_remove';
$route['admin/protection/ea/sync'] = 'admin/protection_ea_sync';
$route['admin/cron'] = 'admin/cron';
$route['admin/cron/save'] = 'admin/cron_save';
$route['admin/cron/run/(:any)'] = 'admin/cron_run/$1';
$route['admin/cron/secret'] = 'admin/cron_secret';

// ---- Admin Inbox (contact messages + email templates) ----
$route['admin/inbox'] = 'admin/inbox';
$route['admin/inbox/templates'] = 'admin/inbox_templates';
$route['admin/inbox/templates/new'] = 'admin/inbox_template_new';
$route['admin/inbox/templates/save'] = 'admin/inbox_template_save';
$route['admin/inbox/templates/(:num)/edit'] = 'admin/inbox_template_edit/$1';
$route['admin/inbox/templates/(:num)/save'] = 'admin/inbox_template_save/$1';
$route['admin/inbox/templates/(:num)/delete'] = 'admin/inbox_template_delete/$1';
$route['admin/inbox/(:num)/reply'] = 'admin/inbox_reply/$1';
$route['admin/inbox/(:num)/star'] = 'admin/inbox_toggle_star/$1';
$route['admin/inbox/(:num)/status'] = 'admin/inbox_status/$1';
$route['admin/inbox/(:num)/delete'] = 'admin/inbox_delete/$1';
$route['admin/inbox/(:num)'] = 'admin/inbox_view/$1';

// ---- Direct member ⇄ admin messages ----
$route['admin/messages'] = 'admin/messages';
$route['admin/messages/send'] = 'admin/message_send';
$route['admin/messages/user/(:num)'] = 'admin/message_user/$1';
$route['messages'] = 'messages';
$route['messages/send'] = 'messages/send';

$route['translate_uri_dashes'] = false;

// ---- pretty URLs for the MVC pages ---------------------------------------
$route['strategy'] = 'strategy_lab';
$route['strategy/backtest'] = 'strategy_lab/run_backtest';
$route['strategy/optimize'] = 'strategy_lab/optimize';
$route['api/strategies/(:any)/optimize'] = 'api_strategies/optimize/$1';
$route['strategy/advance'] = 'strategy_lab/advance';
$route['mode'] = 'welcome/mode';
$route['execution'] = 'execution';
$route['execution/propose'] = 'execution/propose';
$route['execution/execute'] = 'execution/execute';
$route['execution/limits'] = 'execution/limits';
$route['execution/(:any)/decide'] = 'execution/decide/$1';
$route['execution/(:any)/route'] = 'execution/route/$1';
$route['app/trading'] = 'trading/index';
$route['app/workforce'] = 'workforce/index';
$route['app/agent-platform'] = 'agent_platform/index';
$route['workforce'] = 'workforce';
$route['agent-platform'] = 'agent_platform';
$route['app/trading/submit_order'] = 'trading/submit_order';
$route['app/trading/close_position'] = 'trading/close_position';
$route['app/trading/widget_data'] = 'trading/widget_data';
$route['app/trading/signals'] = 'trading/signals';
$route['app/trading/chart_data'] = 'trading/chart_data';
$route['app/trading/risk_dashboard'] = 'trading/risk_dashboard';
$route['app/trading/performance'] = 'trading/performance';
$route['trading'] = 'trading';
$route['brokers'] = 'brokers';
$route['brokers/sim-toggle'] = 'brokers/sim_toggle';
$route['brokers/connect'] = 'brokers/connect';
$route['brokers/connect/(:any)'] = 'brokers/connect/$1';
$route['brokers/save/(:any)'] = 'brokers/save/$1';
$route['brokers/disconnect/(:any)'] = 'brokers/disconnect/$1';
$route['brokers/test/(:any)'] = 'brokers/test/$1';
$route['risk'] = 'risk_center';
$route['risk/scan'] = 'risk_center/scan';
$route['risk/limits'] = 'risk_center/limits';
$route['paper'] = 'paper';
$route['paper/create'] = 'paper/create';
$route['paper/(:num)'] = 'paper/account/$1';
$route['paper/(:num)/order'] = 'paper/order/$1';
$route['paper/(:num)/tick'] = 'paper/tick/$1';
$route['paper/(:num)/deploy'] = 'paper/deploy/$1';
$route['paper/(:num)/positions/(:num)/close'] = 'paper/close/$1/$2';
$route['paper/(:num)/deployments/(:num)/toggle'] = 'paper/toggle/$1/$2';
$route['sports'] = 'sports';
$route['sports/tickets'] = 'sports/tickets'; // legacy URL
$route['sports/match-odds-records'] = 'sports/tickets'; // legacy display name
$route['sports/odds-prediction-ticket'] = 'sports/tickets';
$route['sports/sync'] = 'sports/sync';
$route['sports/generate-ticket'] = 'sports/generate_ticket';
$route['sports/generate'] = 'sports/generate_ticket';
$route['sports/(:any)/decide'] = 'sports/decide/$1';
$route['sports/(:any)/settle'] = 'sports/settle/$1';
$route['lottery'] = 'lottery';
$route['lottery/draw/(:num)'] = 'lottery/index';
$route['lottery/tickets'] = 'lottery/index';

// Public lottery pages — rendered by Api_lottery via lotteryHtml() (no login)
$route['lottery/statistics']     = 'api_lottery/statistics';
$route['lottery/statistics/(:any)'] = 'api_lottery/statistics/$1';
$route['lottery/system']         = 'api_lottery/system';
$route['lottery/backtests']      = 'api_lottery/backtests';

// Multiplier Intelligence
$route['app/multiplier'] = 'multiplier/index';
$route['multiplier'] = 'multiplier';
$route['multiplier/generate_signal'] = 'multiplier/generate_signal';
$route['multiplier/live'] = 'multiplier/live';
$route['multiplier/dashboard'] = 'multiplier/dashboard_data';
$route['multiplier/accuracy'] = 'multiplier/accuracy';
$route['multiplier/validate'] = 'multiplier/validate';
$route['multiplier/verify'] = 'multiplier/verify_integration';
$route['multiplier/test-sports'] = 'multiplier/test_sports_enrichment';
$route['multiplier/demo'] = 'multiplier/live_demo';
$route['multiplier/admin'] = 'multiplier_admin/index';
$route['multiplier/stream/live'] = 'multiplier_stream/live';
$route['multiplier/stream/signals'] = 'multiplier_stream/signals';

// AI Command Center
$route['command-center'] = 'command_center/index';
$route['ai-command-center'] = 'command_center/index';

// ---- JSON API (spec §17 subset for Phases 1–3) ---------------------------
$route['api/system/status'] = 'api_system/status';
$route['api/auth/login'] = 'api_auth/login';
$route['api/auth/logout'] = 'api_auth/logout';
$route['api/auth/me'] = 'api_auth/me';
$route['api/chat/respond'] = 'api_chat/respond';
$route['api/sports/status'] = 'api_sports/status';
$route['api/sports/dashboard'] = 'api_sports/dashboard';
$route['api/sports/performance'] = 'api_sports/performance';
$route['api/sports/fixtures'] = 'api_sports/fixtures';
$route['api/sports/matches'] = 'api_sports/matches';
$route['api/sports/matches/(:num)'] = 'api_sports/show_match/$1';
$route['api/sports/odds'] = 'api_sports/odds';
$route['api/sports/predictions'] = 'api_sports/predictions';
$route['api/sports/predictions/(:any)/decision'] = 'api_sports/decision_report/$1';
$route['api/sports/predict'] = 'api_sports/run_ticket_engine';
$route['api/sports/tickets'] = 'api_sports/tickets';
$route['api/sports/tickets/(:any)/decide'] = 'api_sports/decide_ticket/$1';
$route['api/sports/tickets/(:any)/settle'] = 'api_sports/settle_ticket/$1';
$route['api/sports/tickets/(:any)'] = 'api_sports/show_ticket/$1';
$route['api/sports/settle'] = 'api_sports/settle';
$route['fixtures'] = 'api_sports/fixtures';
$route['odds'] = 'api_sports/odds';
$route['predict'] = 'api_sports/run_ticket_engine';
$route['settle'] = 'api_sports/settle';
$route['api/sports/daily-tickets'] = 'api_sports/daily_tickets';
$route['api/sports/results'] = 'api_sports/results';
$route['api/sports/results/verify'] = 'api_sports/verify_result';
$route['api/sports/providers'] = 'api_sports/providers';
$route['api/sports/providers/(:num)/toggle'] = 'api_sports/toggle_provider/$1';
$route['api/sports/provider-drivers'] = 'api_sports/provider_drivers';
$route['api/sports/sync'] = 'api_sports/sync_provider';
$route['api/sports/live'] = 'api_sports/live';
$route['api/sports/topplayers'] = 'api_sports/top_players';
// CLI commands are documented with dashes, but translate_uri_dashes is off —
// map the documented forms explicitly or they 404.
$route['tools/sports-cron'] = 'tools/sports_cron';
$route['tools/lottery-cron'] = 'tools/lottery_cron';
$route['tools/lottery-smoke'] = 'tools/lottery_smoke';
$route['tools/sports-live'] = 'tools/sports_live';
$route['tools/scheduler'] = 'tools/scheduler';
$route['cron/run'] = 'cron/run';
$route['api/sports/models'] = 'api_sports/models';
$route['api/sports/models/performance'] = 'api_sports/model_performance';
$route['api/sports/calibrations'] = 'api_sports/calibrations';
$route['api/sports/calibrations/fit'] = 'api_sports/fit_calibration';
$route['api/sports/calibrations/(:any)/approve'] = 'api_sports/approve_calibration/$1';
$route['api/sports/calibrations/(:any)/reject'] = 'api_sports/reject_calibration/$1';
$route['api/sports/backtests'] = 'api_sports/backtests';
$route['api/sports/backtests/run'] = 'api_sports/run_backtest';
$route['api/sports/backtests/(:any)'] = 'api_sports/show_backtest/$1';
$route['api/sports/audit'] = 'api_sports/audit';
$route['api/sports/jobs'] = 'api_sports/jobs';
$route['api/sports/jobs/(:any)/run'] = 'api_sports/run_job/$1';
$route['api/sports/configuration'] = 'api_sports/configuration';
$route['api/sports/configuration/update'] = 'api_sports/update_configuration';
$route['api/sports/ticket-engine/run'] = 'api_sports/run_ticket_engine';
$route['api/sports/risk'] = 'api_sports/risk_monitor';
$route['api/sports/correlation'] = 'api_sports/correlation_monitor';

// Football Intelligence — console (§10/§11/§16)
$route['football'] = 'football';
$route['football/match/(:num)'] = 'football/match/$1';
$route['football/live'] = 'football/live';
$route['football/models'] = 'football/models';
$route['football/sync'] = 'football/sync';
// Generate the missing predictions for one page of matches (max 50).
$route['football/predict'] = 'football/predict';
$route['football/settle'] = 'football/settle';
$route['football/calibrate'] = 'football/calibrate';
$route['football/models/(:num)/decide'] = 'football/decide/$1';
// Football Intelligence API (§17). Read paths take sports.view; model
// approve/activate are admin-only and sit under /api/admin/football.
$route['api/football/status'] = 'api_football/status';
$route['api/football/provider/status'] = 'api_football/provider_status';
$route['api/football/dashboard'] = 'api_football/dashboard';
$route['api/football/fixtures'] = 'api_football/fixtures';
$route['api/football/fixtures/today'] = 'api_football/fixtures_today';
$route['api/football/fixtures/tomorrow'] = 'api_football/fixtures_tomorrow';
$route['api/football/fixtures/live'] = 'api_football/fixtures_live';
// The paginated match feed: 50 matches per page, 50 per generation request.
$route['api/football/matches'] = 'api_football/matches';
$route['api/football/matches/generate'] = 'api_football/generate_matches';
$route['api/football/competitions'] = 'api_football/competitions';
// Multi-provider: the provider catalogue, per-provider health, and a direct
// (canonicalized) read of the selected provider.
$route['api/football/providers'] = 'api_football/providers';
$route['api/football/providers/health'] = 'api_football/providers_health';
$route['api/football/matches/fetch'] = 'api_football/fetch_matches';
$route['api/football/markets'] = 'api_football/markets';
$route['api/football/matches/(:num)'] = 'api_football/show_match/$1';
$route['api/football/matches/(:num)/analysis'] = 'api_football/analysis/$1';
$route['api/football/matches/(:num)/prediction'] = 'api_football/prediction/$1';
$route['api/football/predictions/today'] = 'api_football/predictions_today';
$route['api/football/predictions/history'] = 'api_football/predictions_history';
// Generic prediction reads. They come AFTER the specific ones above: CI3 matches
// routes in the order they are declared, so `/predictions/today` still resolves
// to the board endpoint and only anything else falls through to these.
$route['api/football/predictions/(:any)'] = 'api_football/show_prediction/$1';
$route['api/football/predictions'] = 'api_football/predictions';
$route['api/football/performance'] = 'api_football/performance';
$route['api/football/models'] = 'api_football/models';
$route['api/football/models/active'] = 'api_football/models_active';
$route['api/football/calibrations'] = 'api_football/calibrations';
$route['api/football/sync'] = 'api_football/sync';
$route['api/football/sync/live'] = 'api_football/sync_live';
$route['api/football/settle'] = 'api_football/settle';
$route['api/football/calibrate'] = 'api_football/calibrate';
$route['api/football/jobs/(:any)/run'] = 'api_football/run_job/$1';
$route['api/admin/football/models/(:num)/approve'] = 'api_football/approve_model/$1';
$route['api/admin/football/models/(:num)/activate'] = 'api_football/activate_model/$1';
// CLI commands are documented with dashes, but translate_uri_dashes is off —
// map the documented form explicitly or it 404s.
$route['tools/football-cron'] = 'tools/football_cron';

// WINDELS Lottery Intelligence (EuroMillions first; provider-neutral)
$route['api/lottery/status'] = 'api_lottery/status';
$route['api/lottery/dashboard'] = 'api_lottery/dashboard';
$route['api/lottery/lotteries'] = 'api_lottery/lotteries';
$route['api/lottery/rules'] = 'api_lottery/rules';
$route['api/lottery/draws'] = 'api_lottery/draws';
$route['api/lottery/draws/(:num)'] = 'api_lottery/show_draw/$1';
$route['api/lottery/statistics'] = 'api_lottery/statistics';
$route['api/lottery/statistics/(:any)'] = 'api_lottery/statistics/$1';
$route['api/lottery/analyze'] = 'api_lottery/analyze';
$route['api/lottery/generate'] = 'api_lottery/generate';
$route['api/lottery/diversity'] = 'api_lottery/diversity';
$route['api/lottery/combinations'] = 'api_lottery/combinations';
$route['api/lottery/combinations/(:num)'] = 'api_lottery/show_combination/$1';
$route['api/lottery/system'] = 'api_lottery/system';
$route['api/lottery/system-build'] = 'api_lottery/system_build';
$route['api/lottery/backtests/(:num)'] = 'api_lottery/show_backtest/$1';
$route['api/lottery/backtests'] = 'api_lottery/backtests';
$route['api/lottery/backtest-compare'] = 'api_lottery/backtest_compare';
$route['api/lottery/backtest'] = 'api_lottery/backtest';
$route['api/lottery/models'] = 'api_lottery/models';
$route['api/lottery/performance'] = 'api_lottery/performance';
$route['api/lottery/intelligence'] = 'api_lottery/intelligence';
$route['api/lottery/intelligence/run'] = 'api_lottery/intelligence_run';
$route['api/lottery/tickets'] = 'api_lottery/tickets';
$route['api/lottery/tickets/(:num)/check'] = 'api_lottery/check_ticket/$1';
$route['api/lottery/tickets/(:num)/delete'] = 'api_lottery/delete_ticket/$1';
$route['api/lottery/tickets/(:num)'] = 'api_lottery/show_ticket/$1';
$route['api/lottery/providers'] = 'api_lottery/providers';
$route['api/lottery/health'] = 'api_lottery/health';
$route['api/lottery/jobs'] = 'api_lottery/jobs';
$route['api/lottery/sync'] = 'api_lottery/sync';
$route['api/system/features'] = 'api_system/features';
$route['api/system/protection'] = 'api_system/protection';
$route['api/system/protection/policy'] = 'api_system/protection_policy';
// §10 — MT4/MT5 Expert Advisor protection (heartbeat in, decision out).
$route['api/system/protection/ea/policy'] = 'api_system/protection_ea_policy';
$route['api/system/protection/ea/account'] = 'api_system/protection_ea_account';
$route['api/system/protection/ea/limits'] = 'api_system/protection_ea_limits';
$route['api/system/protection/ea/(:any)'] = 'api_system/protection_ea_decision/$1';
$route['api/system/protection/ea'] = 'api_system/protection_ea';
$route['api/agents/status'] = 'api_agents/status';
$route['api/agents/dispatch'] = 'api_agents/dispatch';
$route['api/agents/analyze-upload'] = 'api_agents/analyze_upload';

// Agent Platform API
$route['api/agent-platform/execute'] = 'api_agent_platform/execute';
$route['api/agent-platform/tool'] = 'api_agent_platform/tool';
$route['api/agent-platform/workflow'] = 'api_agent_platform/workflow';
$route['api/agent-platform/workflow/(:any)'] = 'api_agent_platform/workflow_status/$1';
$route['api/agent-platform/sessions'] = 'api_agent_platform/sessions';
$route['api/agent-platform/observability'] = 'api_agent_platform/observability';
$route['api/agent-platform/status'] = 'api_agent_platform/status';
$route['api/agent-platform/tools'] = 'api_agent_platform/tools';
$route['api/agent-platform/agents'] = 'api_agent_platform/agents';
$route['api/brokers'] = 'api_system/brokers';
$route['api/brokers/mt5/account'] = 'api_system/mt5_account';
$route['api/brokers/mt5/quote'] = 'api_system/mt5_quote';
$route['api/events'] = 'api_system/events';
$route['api/events/(:num)'] = 'api_system/events/$1';

$route['api/market-data/candles'] = 'api_marketdata/candles';
$route['api/market-data/quote'] = 'api_marketdata/quote';
$route['api/market-data/providers'] = 'api_marketdata/providers';
$route['api/market-data/live'] = 'api_marketdata/live';
$route['api/market-data/refresh'] = 'api_marketdata/refresh';

$route['api/analysis/run'] = 'api_analysis/run';
$route['api/analysis/history'] = 'api_analysis/history';
$route['api/analysis/(:any)'] = 'api_analysis/show/$1';
$route['api/agents'] = 'api_analysis/agents';
$route['api/agents/consensus'] = 'api_analysis/consensus';

$route['api/strategies'] = 'api_strategies/index';
$route['api/strategies/(:any)'] = 'api_strategies/show/$1';
$route['api/strategies/(:any)/status'] = 'api_strategies/status/$1';
$route['api/backtesting/run'] = 'api_strategies/run_backtest';
$route['api/backtesting/results'] = 'api_strategies/backtest_results';
$route['api/backtesting/results/(:any)'] = 'api_strategies/backtest_detail/$1';

$route['api/accounts'] = 'api_paper/accounts';
$route['api/accounts/create'] = 'api_paper/create_account';
$route['api/accounts/(:num)'] = 'api_paper/account/$1';
$route['api/accounts/(:num)/orders'] = 'api_paper/orders/$1';
$route['api/accounts/(:num)/order'] = 'api_paper/submit_order/$1';
$route['api/accounts/(:num)/positions'] = 'api_paper/positions/$1';
$route['api/accounts/(:num)/positions/(:num)/close'] = 'api_paper/close_position/$1/$2';
$route['api/accounts/(:num)/tick'] = 'api_paper/tick/$1';
$route['api/accounts/(:num)/deployments'] = 'api_paper/deployments/$1';
$route['api/accounts/(:num)/deploy'] = 'api_paper/deploy/$1';
$route['api/accounts/(:num)/deployments/(:num)/toggle'] = 'api_paper/toggle_deployment/$1/$2';

$route['api/journal'] = 'api_journal/index';
$route['api/journal/manual'] = 'api_journal/manual';
$route['api/analytics/summary'] = 'api_journal/summary';
$route['api/analytics/confidence-calibration'] = 'api_journal/calibration';

$route['api/risk/limits'] = 'api_system/risk_limits';
$route['api/risk/limits/update'] = 'api_system/update_risk_limits';
$route['api/trading/mode'] = 'api_system/trading_mode';
$route['api/trading/limits'] = 'api_system/automation_limits';
$route['api/trading/limits/update'] = 'api_system/update_automation_limits';
$route['api/trading/propose'] = 'api_system/execution_propose';
$route['api/trading/execute'] = 'api_system/execution_execute';
$route['api/trading/(:any)/approve'] = 'api_system/execution_decide/$1';
$route['api/trading/(:any)/route'] = 'api_system/execution_route/$1';
$route['api/execution/preflight'] = 'api_system/execution_preflight';
$route['api/execution/proposals'] = 'api_system/execution_approvals';
$route['api/execution/executions'] = 'api_system/execution_recent';
$route['api/execution/proposals/(:any)/decide'] = 'api_system/execution_decide/$1';
$route['api/execution/proposals/(:any)/route'] = 'api_system/execution_route/$1';
$route['api/portfolio/risk-scan'] = 'api_system/portfolio_scan';
$route['api/notifications'] = 'api_system/notifications';
$route['api/notifications/read-all'] = 'api_system/notification_read_all';
$route['api/notifications/(:any)/read'] = 'api_system/notification_read/$1';
$route['notifications'] = 'notifications';
$route['notifications/read-all'] = 'notifications/read_all';
$route['notifications/(:any)/read'] = 'notifications/read/$1';
$route['api/trading/synthetic-paper'] = 'api_system/synthetic_paper';

// ---- Standalone Lead Discovery & Sales Intelligence ----------------------
$route['leads'] = 'leads/index';
$route['lead-pipeline'] = 'leads/pipeline';
// ---- AI Language Learning (/api/v1/language-learning) ----------------------
$route['api/v1/language-learning/languages'] = 'api_lang_learning/languages';
$route['api/v1/language-learning/catalog'] = 'api_lang_learning/catalog';
$route['api/v1/language-learning/languages/(:any)'] = 'api_lang_learning/show_language/$1';
$route['api/v1/language-learning/translate'] = 'api_lang_learning/translate';
$route['api/v1/language-learning/detect'] = 'api_lang_learning/detect';
$route['api/v1/language-learning/voice-status'] = 'api_lang_learning/voice_status';
$route['api/v1/language-learning/profiles'] = 'api_lang_learning/profiles';
$route['api/v1/language-learning/teacher/interpret'] = 'api_lang_learning/interpret';
$route['api/v1/language-learning/profiles/(:num)/settings'] = 'api_lang_learning/update_profile/$1';
$route['api/v1/language-learning/profiles/(:num)/assessment/start'] = 'api_lang_learning/start_assessment/$1';
$route['api/v1/language-learning/profiles/(:num)/path'] = 'api_lang_learning/show_path/$1';
$route['api/v1/language-learning/profiles/(:num)/path/generate'] = 'api_lang_learning/generate_path/$1';
$route['api/v1/language-learning/profiles/(:num)/progress'] = 'api_lang_learning/progress/$1';
$route['api/v1/language-learning/profiles/(:num)'] = 'api_lang_learning/show_profile/$1';
$route['api/v1/language-learning/assessment/(:any)'] = 'api_lang_learning/show_assessment/$1';
$route['api/v1/language-learning/assessment/(:any)/answer'] = 'api_lang_learning/answer_assessment/$1';
$route['api/v1/language-learning/modules/(:any)/lesson/start'] = 'api_lang_learning/start_lesson/$1';
$route['api/v1/language-learning/modules/(:any)/lesson/answer'] = 'api_lang_learning/answer_lesson/$1';
$route['api/v1/language-learning/profiles/(:num)/conversations'] = 'api_lang_learning/conversations/$1';
$route['api/v1/language-learning/profiles/(:num)/conversations/start'] = 'api_lang_learning/start_conversation/$1';
$route['api/v1/language-learning/profiles/(:num)/writing/tasks'] = 'api_lang_learning/writing_tasks/$1';
$route['api/v1/language-learning/profiles/(:num)/writing/submit'] = 'api_lang_learning/submit_writing/$1';
$route['api/v1/language-learning/profiles/(:num)/grammar'] = 'api_lang_learning/grammar/$1';
$route['api/v1/language-learning/profiles/(:num)/grammar/(:any)/simple'] = 'api_lang_learning/grammar_simple/$1/$2';
$route['api/v1/language-learning/profiles/(:num)/vocabulary'] = 'api_lang_learning/vocabulary_catalog/$1';
$route['api/v1/language-learning/profiles/(:num)/vocabulary/add'] = 'api_lang_learning/vocabulary_add/$1';
$route['api/v1/language-learning/profiles/(:num)/vocabulary/due'] = 'api_lang_learning/vocabulary_due/$1';
$route['api/v1/language-learning/profiles/(:num)/vocabulary/review/start'] = 'api_lang_learning/vocabulary_review_start/$1';
$route['api/v1/language-learning/profiles/(:num)/vocabulary/review/submit'] = 'api_lang_learning/vocabulary_review_submit/$1';
$route['api/v1/language-learning/profiles/(:num)/vocabulary/progress'] = 'api_lang_learning/vocabulary_progress/$1';
$route['api/v1/language-learning/profiles/(:num)/listening/exercises'] = 'api_lang_learning/listening_exercises/$1';
$route['api/v1/language-learning/profiles/(:num)/listening/attempt'] = 'api_lang_learning/listening_attempt/$1';
$route['api/v1/language-learning/profiles/(:num)/speaking/prompts'] = 'api_lang_learning/speaking_prompts/$1';
$route['api/v1/language-learning/profiles/(:num)/speaking/attempt'] = 'api_lang_learning/speaking_attempt/$1';
$route['api/v1/language-learning/profiles/(:num)/adaptive/weaknesses'] = 'api_lang_learning/adaptive_weaknesses/$1';
$route['api/v1/language-learning/profiles/(:num)/adaptive/daily-plan'] = 'api_lang_learning/adaptive_daily_plan/$1';
$route['api/v1/language-learning/profiles/(:num)/adaptive/recommendations'] = 'api_lang_learning/adaptive_recommendations/$1';
$route['api/v1/language-learning/profiles/(:num)/adaptive/mastery'] = 'api_lang_learning/adaptive_mastery/$1';
$route['api/v1/language-learning/profiles/(:num)/history'] = 'api_lang_learning/history/$1';
$route['api/v1/language-learning/conversations/(:any)/turn'] = 'api_lang_learning/conversation_turn/$1';
$route['api/v1/language-learning/modules/(:any)/checkpoint/start'] = 'api_lang_learning/start_checkpoint/$1';
$route['api/v1/language-learning/modules/(:any)/checkpoint/answer'] = 'api_lang_learning/answer_checkpoint/$1';
// pages
$route['app/languages'] = 'lang_learn';
$route['app/languages/teacher'] = 'lang_learn/teacher';
$route['app/languages/teacher/ask'] = 'lang_learn/teacher_ask';
$route['app/languages/start'] = 'lang_learn/start';
$route['app/languages/begin'] = 'lang_learn/begin';
$route['app/languages/p/(:num)'] = 'lang_learn/profile/$1';
$route['app/languages/p/(:num)/goal'] = 'lang_learn/save_goal/$1';
$route['app/languages/p/(:num)/assessment/start'] = 'lang_learn/start_assessment/$1';
$route['app/languages/p/(:num)/path/generate'] = 'lang_learn/generate_path/$1';
$route['app/languages/a/(:any)'] = 'lang_learn/assessment/$1';
$route['app/languages/a/(:any)/answer'] = 'lang_learn/answer/$1';
$route['app/languages/m/(:any)/lesson'] = 'lang_learn/lesson/$1';
$route['app/languages/m/(:any)/lesson/answer'] = 'lang_learn/lesson_answer/$1';
$route['app/languages/c/(:any)'] = 'lang_learn/conversation_show/$1';
$route['app/languages/c/(:any)/say'] = 'lang_learn/conversation_say/$1';
$route['app/languages/conv/(:num)'] = 'lang_learn/conversation/$1';
$route['app/languages/conv/(:num)/start'] = 'lang_learn/conversation_go/$1';
$route['app/languages/w/(:num)'] = 'lang_learn/writing/$1';
$route['app/languages/w/(:num)/submit'] = 'lang_learn/writing_submit/$1';
$route['app/languages/g/(:num)'] = 'lang_learn/grammar/$1';
$route['app/languages/g/(:num)/(:any)/simple'] = 'lang_learn/grammar_simple/$1/$2';
$route['app/languages/v/(:num)'] = 'lang_learn/vocabulary/$1';
$route['app/languages/v/(:num)/add'] = 'lang_learn/vocabulary_add/$1';
$route['app/languages/vr/(:num)/(:any)'] = 'lang_learn/vocab_review/$1/$2';
$route['app/languages/vr/(:num)/(:any)/submit'] = 'lang_learn/vocab_submit/$1/$2';
$route['app/languages/l/(:num)'] = 'lang_learn/listening/$1';
$route['app/languages/l/(:num)/attempt'] = 'lang_learn/listening_attempt/$1';
$route['app/languages/s/(:num)'] = 'lang_learn/speaking/$1';
$route['app/languages/s/(:num)/attempt'] = 'lang_learn/speaking_attempt/$1';
$route['app/languages/d/(:num)'] = 'lang_learn/daily_plan/$1';
$route['app/languages/d/(:num)/regenerate'] = 'lang_learn/daily_plan_regenerate/$1';
$route['app/languages/h/(:num)'] = 'lang_learn/history/$1';
$route['app/languages/m/(:any)/checkpoint'] = 'lang_learn/checkpoint/$1';
$route['app/languages/m/(:any)/checkpoint/answer'] = 'lang_learn/answer_checkpoint/$1';

$route['api/v1/lead-discovery/workspaces'] = 'api_lead_discovery/workspaces';
$route['api/v1/lead-discovery/providers'] = 'api_lead_discovery/providers';
$route['api/v1/lead-discovery/modes'] = 'api_lead_discovery/modes';
$route['api/v1/lead-discovery/search'] = 'api_lead_discovery/search';
$route['api/v1/lead-discovery/leads'] = 'api_lead_discovery/leads';
$route['api/v1/lead-discovery/leads/(:any)/outreach'] = 'api_lead_discovery/outreach/$1';
$route['api/v1/lead-discovery/leads/(:any)'] = 'api_lead_discovery/leads/$1';
$route['api/v1/lead-discovery/leads/(:any)/status'] = 'api_lead_discovery/status/$1';
$route['api/v1/lead-discovery/leads/(:any)/owner'] = 'api_lead_discovery/owner/$1';
$route['api/v1/lead-discovery/leads/(:any)/notes'] = 'api_lead_discovery/notes/$1';
$route['api/v1/lead-discovery/leads/(:any)/activity'] = 'api_lead_discovery/activity/$1';
$route['api/v1/lead-discovery/collections'] = 'api_lead_discovery/collections';
$route['api/v1/lead-discovery/collections/(:any)'] = 'api_lead_discovery/collections/$1';
$route['api/v1/lead-discovery/collections/(:any)/leads'] = 'api_lead_discovery/collection_leads/$1';
$route['api/v1/lead-discovery/collections/(:any)/leads/(:any)'] = 'api_lead_discovery/collection_leads/$1/$2';
$route['api/v1/lead-discovery/coverage'] = 'api_lead_discovery/coverage';
$route['api/v1/lead-discovery/duplicates'] = 'api_lead_discovery/duplicates';
$route['api/v1/lead-discovery/duplicates/resolve'] = 'api_lead_discovery/duplicates/true';
$route['api/v1/lead-discovery/history'] = 'api_lead_discovery/history';
$route['api/v1/lead-discovery/summary'] = 'api_lead_discovery/summary';
$route['api/v1/lead-discovery/pipeline'] = 'api_lead_discovery/pipeline';
$route['api/v1/lead-discovery/export'] = 'api_lead_discovery/export';
$route['api/v1/lead-discovery/export/preview'] = 'api_lead_discovery/export';
$route['api/v1/lead-discovery/export/csv'] = 'api_lead_discovery/export/csv';
