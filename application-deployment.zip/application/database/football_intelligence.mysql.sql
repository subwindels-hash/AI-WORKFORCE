-- WINDELS Football Intelligence — persistence (MySQL/MariaDB).
--
-- Every table stores provider-sourced or model-computed facts only. Columns
-- that a provider did not supply stay NULL and are surfaced as DATA_UNAVAILABLE
-- by the read layer — never defaulted to zero and never back-filled with
-- invented values. data_state / coverage columns record WHY a value exists so
-- any figure on the dashboard is traceable to a provider row or a stored,
-- versioned model calculation.
--
-- football_fixtures.live_confirmed_at is the last time a provider LIVE snapshot
-- actually reported that fixture as in play. It is deliberately separate from
-- updated_at, which any unrelated write touches, because the Live Match panel
-- measures "is this still live" against a provider statement and nothing else.

CREATE TABLE IF NOT EXISTS football_providers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider_code VARCHAR(64) NOT NULL UNIQUE,
  display_name VARCHAR(120) NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'NOT_CONFIGURED',
  capabilities TEXT NULL,
  requests_used INT NOT NULL DEFAULT 0,
  requests_used_date DATE NULL,
  requests_budget INT NULL,
  rate_limit_per_minute INT NULL,
  backoff_until VARCHAR(32) NULL,
  last_success_at VARCHAR(32) NULL,
  last_failure_at VARCHAR(32) NULL,
  last_error VARCHAR(500) NULL,
  demo_mode TINYINT(1) NOT NULL DEFAULT 0,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_competitions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  external_id VARCHAR(64) NOT NULL,
  name VARCHAR(160) NOT NULL,
  country VARCHAR(80) NULL,
  code VARCHAR(32) NULL,
  season VARCHAR(16) NULL,
  tier INT NULL,
  coefficient DECIMAL(8,4) NULL,
  reliability DECIMAL(5,2) NULL,
  data_state VARCHAR(24) NOT NULL DEFAULT 'DATA_UNAVAILABLE',
  payload LONGTEXT NULL,
  fetched_at VARCHAR(32) NULL,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_competition (provider_id, external_id, season),
  INDEX idx_football_competition_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_teams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  external_id VARCHAR(64) NOT NULL,
  name VARCHAR(160) NOT NULL,
  short_code VARCHAR(16) NULL,
  logo VARCHAR(255) NULL,
  venue VARCHAR(160) NULL,
  country VARCHAR(80) NULL,
  data_state VARCHAR(24) NOT NULL DEFAULT 'DATA_UNAVAILABLE',
  payload LONGTEXT NULL,
  fetched_at VARCHAR(32) NULL,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_team (provider_id, external_id),
  INDEX idx_football_team_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_fixtures (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  external_id VARCHAR(64) NOT NULL,
  competition_id INT NULL,
  competition VARCHAR(160) NOT NULL DEFAULT 'DATA_UNAVAILABLE',
  country VARCHAR(80) NULL,
  season VARCHAR(16) NULL,
  round VARCHAR(64) NULL,
  kickoff_at VARCHAR(32) NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'SCHEDULED',
  match_state VARCHAR(32) NOT NULL DEFAULT 'PRE_MATCH',
  minute INT NULL,
  extra_minute INT NULL,
  home_team VARCHAR(160) NOT NULL,
  away_team VARCHAR(160) NOT NULL,
  home_team_id VARCHAR(64) NULL,
  away_team_id VARCHAR(64) NULL,
  home_score INT NULL,
  away_score INT NULL,
  half_time_home INT NULL,
  half_time_away INT NULL,
  home_red_cards INT NULL,
  away_red_cards INT NULL,
  venue VARCHAR(160) NULL,
  data_state VARCHAR(24) NOT NULL DEFAULT 'DATA_UNAVAILABLE',
  coverage TEXT NULL,
  payload LONGTEXT NULL,
  source_timestamp VARCHAR(32) NOT NULL,
  live_confirmed_at VARCHAR(32) NULL,
  settled_at VARCHAR(32) NULL,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_fixture (provider_id, external_id),
  INDEX idx_football_fixture_kickoff (kickoff_at),
  INDEX idx_football_fixture_status (status, kickoff_at),
  INDEX idx_football_fixture_settle (settled_at, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_team_statistics (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  team_external_id VARCHAR(64) NOT NULL,
  competition_external_id VARCHAR(64) NULL,
  season VARCHAR(16) NULL,
  team VARCHAR(160) NOT NULL,
  played INT NULL,
  wins INT NULL,
  draws INT NULL,
  losses INT NULL,
  goals_for INT NULL,
  goals_against INT NULL,
  points INT NULL,
  position INT NULL,
  home_played INT NULL,
  home_wins INT NULL,
  home_draws INT NULL,
  home_losses INT NULL,
  home_goals_for INT NULL,
  home_goals_against INT NULL,
  away_played INT NULL,
  away_wins INT NULL,
  away_draws INT NULL,
  away_losses INT NULL,
  away_goals_for INT NULL,
  away_goals_against INT NULL,
  clean_sheets INT NULL,
  failed_to_score INT NULL,
  form_last5 VARCHAR(20) NULL,
  form_last10 VARCHAR(40) NULL,
  last_matches TEXT NULL,
  data_state VARCHAR(24) NOT NULL DEFAULT 'DATA_UNAVAILABLE',
  coverage TEXT NULL,
  payload LONGTEXT NULL,
  fetched_at VARCHAR(32) NULL,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_team_stats (provider_id, team_external_id, competition_external_id, season),
  INDEX idx_football_team_stats_team (team_external_id, fetched_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_fixture_statistics (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  fixture_id BIGINT NOT NULL,
  provider_id INT NOT NULL,
  kind VARCHAR(32) NOT NULL DEFAULT 'MATCH',
  payload LONGTEXT NOT NULL,
  data_state VARCHAR(24) NOT NULL DEFAULT 'DATA_UNAVAILABLE',
  coverage TEXT NULL,
  fetched_at VARCHAR(32) NULL,
  created_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_fixture_stat (fixture_id, provider_id, kind),
  INDEX idx_football_fixture_stat_fetch (fetched_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_head_to_head (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  home_team_external_id VARCHAR(64) NOT NULL,
  away_team_external_id VARCHAR(64) NOT NULL,
  competition_external_id VARCHAR(64) NULL,
  meetings INT NOT NULL DEFAULT 0,
  home_wins INT NOT NULL DEFAULT 0,
  draws INT NOT NULL DEFAULT 0,
  away_wins INT NOT NULL DEFAULT 0,
  avg_home_goals DECIMAL(6,3) NULL,
  avg_away_goals DECIMAL(6,3) NULL,
  both_teams_scored INT NULL,
  over_15 INT NULL,
  over_25 INT NULL,
  oldest_kickoff VARCHAR(32) NULL,
  newest_kickoff VARCHAR(32) NULL,
  sample_age_days INT NULL,
  weight DECIMAL(5,4) NOT NULL DEFAULT 0.0000,
  data_state VARCHAR(24) NOT NULL DEFAULT 'DATA_UNAVAILABLE',
  matches TEXT NULL,
  fetched_at VARCHAR(32) NULL,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_h2h (provider_id, home_team_external_id, away_team_external_id, competition_external_id),
  INDEX idx_football_h2h_fetch (fetched_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_model_versions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  model_id VARCHAR(64) NOT NULL,
  model_name VARCHAR(120) NOT NULL,
  model_version VARCHAR(64) NOT NULL,
  algorithm VARCHAR(64) NOT NULL DEFAULT 'poisson-dixon-coles',
  feature_version VARCHAR(64) NOT NULL,
  training_dataset_version VARCHAR(64) NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
  created_at VARCHAR(32) NOT NULL,
  trained_at VARCHAR(32) NULL,
  validated_at VARCHAR(32) NULL,
  calibrated_at VARCHAR(32) NULL,
  approved_at VARCHAR(32) NULL,
  approved_by VARCHAR(64) NULL,
  activated_at VARCHAR(32) NULL,
  activated_by VARCHAR(64) NULL,
  retired_at VARCHAR(32) NULL,
  last_evaluated_at VARCHAR(32) NULL,
  calibration_version_id INT NULL,
  validation_sample_size INT NULL,
  training_sample_size INT NULL,
  accuracy DECIMAL(8,5) NULL,
  log_loss DECIMAL(10,6) NULL,
  brier_score DECIMAL(10,6) NULL,
  ece DECIMAL(10,6) NULL,
  parameters TEXT NULL,
  lifecycle_history TEXT NULL,
  rejection_reason VARCHAR(500) NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_model (model_name, model_version),
  INDEX idx_football_model_status (status, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_calibration_versions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  model_version_id INT NOT NULL,
  calibration_version VARCHAR(64) NOT NULL,
  method VARCHAR(32) NOT NULL DEFAULT 'platt',
  parameters TEXT NOT NULL,
  sample_size INT NOT NULL DEFAULT 0,
  accuracy DECIMAL(8,5) NULL,
  log_loss DECIMAL(10,6) NULL,
  brier DECIMAL(10,6) NULL,
  ece DECIMAL(10,6) NULL,
  mce DECIMAL(10,6) NULL,
  reliability_bins TEXT NULL,
  training_window_start VARCHAR(32) NULL,
  training_window_end VARCHAR(32) NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
  created_by VARCHAR(64) NULL,
  approved_by VARCHAR(64) NULL,
  approved_at VARCHAR(32) NULL,
  rejected_by VARCHAR(64) NULL,
  rejected_at VARCHAR(32) NULL,
  reason VARCHAR(500) NULL,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_calibration (model_version_id, calibration_version),
  INDEX idx_football_calibration_status (model_version_id, status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_match_predictions (
  id VARCHAR(40) PRIMARY KEY,
  fixture_id BIGINT NOT NULL,
  provider_id INT NOT NULL,
  model_version_id INT NULL,
  calibration_version_id INT NULL,
  calibration_state VARCHAR(24) NOT NULL DEFAULT 'CALIBRATION_PENDING',
  prediction_kind VARCHAR(16) NOT NULL DEFAULT 'PRE_MATCH',
  supersedes_prediction_id VARCHAR(40) NULL,
  generated_at VARCHAR(32) NOT NULL,
  kickoff_at VARCHAR(32) NOT NULL,
  status_at_prediction VARCHAR(24) NOT NULL DEFAULT 'SCHEDULED',
  predicted_result VARCHAR(24) NOT NULL,
  predicted_home_score INT NULL,
  predicted_away_score INT NULL,
  probability_home DECIMAL(8,6) NULL,
  probability_draw DECIMAL(8,6) NULL,
  probability_away DECIMAL(8,6) NULL,
  raw_home DECIMAL(8,6) NULL,
  raw_draw DECIMAL(8,6) NULL,
  raw_away DECIMAL(8,6) NULL,
  expected_total_goals DECIMAL(6,3) NULL,
  confidence DECIMAL(6,2) NULL,
  confidence_basis VARCHAR(32) NULL,
  data_quality_score INT NOT NULL DEFAULT 0,
  data_quality_band VARCHAR(16) NOT NULL DEFAULT 'REJECTED',
  quality_components TEXT NULL,
  feature_snapshot TEXT NOT NULL,
  probabilities_matrix TEXT NULL,
  alternative_scores TEXT NULL,
  reason VARCHAR(600) NULL,
  evidence TEXT NULL,
  outcome VARCHAR(600) NULL,
  eligibility VARCHAR(24) NOT NULL DEFAULT 'QUALIFIED',
  rejection_reasons TEXT NULL,
  settlement_state VARCHAR(16) NOT NULL DEFAULT 'OPEN',
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_prediction_kind (fixture_id, prediction_kind, model_version_id),
  INDEX idx_football_prediction_generated (generated_at),
  INDEX idx_football_prediction_settle (settlement_state, generated_at),
  INDEX idx_football_prediction_model (model_version_id, settlement_state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_score_probabilities (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  prediction_id VARCHAR(40) NOT NULL,
  home_goals INT NOT NULL,
  away_goals INT NOT NULL,
  probability DECIMAL(8,6) NOT NULL,
  rank INT NOT NULL DEFAULT 0,
  is_prediction TINYINT(1) NOT NULL DEFAULT 0,
  created_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_score_row (prediction_id, home_goals, away_goals),
  INDEX idx_football_score_rank (prediction_id, rank)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_prediction_settlements (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  prediction_id VARCHAR(40) NOT NULL,
  fixture_id BIGINT NOT NULL,
  actual_home_score INT NULL,
  actual_away_score INT NULL,
  actual_result VARCHAR(24) NOT NULL,
  predicted_result VARCHAR(24) NOT NULL,
  predicted_home_score INT NULL,
  predicted_away_score INT NULL,
  probability_home DECIMAL(8,6) NULL,
  probability_draw DECIMAL(8,6) NULL,
  probability_away DECIMAL(8,6) NULL,
  confidence DECIMAL(6,2) NULL,
  data_quality_score INT NULL,
  model_version_id INT NULL,
  calibration_version_id INT NULL,
  correct_result TINYINT(1) NULL,
  correct_exact_score TINYINT(1) NULL,
  brier DECIMAL(10,6) NULL,
  log_loss DECIMAL(10,6) NULL,
  absolute_goal_error DECIMAL(8,3) NULL,
  result_source VARCHAR(32) NOT NULL DEFAULT 'PROVIDER',
  settled_at VARCHAR(32) NOT NULL,
  created_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_settlement_prediction (prediction_id),
  INDEX idx_football_settlement_fixture (fixture_id),
  INDEX idx_football_settlement_settled (settled_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_model_performance (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  model_version_id INT NULL,
  calibration_version_id INT NULL,
  window_days INT NOT NULL DEFAULT 30,
  window_start VARCHAR(32) NOT NULL,
  window_end VARCHAR(32) NOT NULL,
  evaluated_predictions INT NOT NULL DEFAULT 0,
  correct_results INT NOT NULL DEFAULT 0,
  correct_scores INT NOT NULL DEFAULT 0,
  result_accuracy DECIMAL(8,5) NULL,
  exact_score_accuracy DECIMAL(8,5) NULL,
  average_confidence DECIMAL(8,4) NULL,
  average_data_quality DECIMAL(8,4) NULL,
  brier DECIMAL(10,6) NULL,
  ece DECIMAL(10,6) NULL,
  log_loss DECIMAL(10,6) NULL,
  payload LONGTEXT NOT NULL,
  computed_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_perf (model_version_id, window_days, window_start, window_end),
  INDEX idx_football_perf_computed (computed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS football_provider_sync_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NULL,
  provider_code VARCHAR(64) NULL,
  job_type VARCHAR(48) NOT NULL,
  status VARCHAR(24) NOT NULL,
  execution_key VARCHAR(190) NOT NULL,
  window_start VARCHAR(32) NULL,
  window_end VARCHAR(32) NULL,
  records_processed INT NOT NULL DEFAULT 0,
  records_created INT NOT NULL DEFAULT 0,
  records_updated INT NOT NULL DEFAULT 0,
  requests_made INT NOT NULL DEFAULT 0,
  rate_limit_remaining INT NULL,
  retry_after_seconds INT NULL,
  next_run_at VARCHAR(32) NULL,
  attempts INT NOT NULL DEFAULT 1,
  errors TEXT NULL,
  started_at VARCHAR(32) NOT NULL,
  ended_at VARCHAR(32) NULL,
  UNIQUE KEY uq_football_sync_key (execution_key),
  INDEX idx_football_sync_job (job_type, started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cross-provider identity. One real match can arrive from three feeds under
-- three different ids ("Man Utd" vs "Manchester United"), and the module must
-- recognise it as one fixture: one canonical row, one prediction. The mapping
-- keeps every provider's own id, so nothing is thrown away — the same match is
-- simply addressable by the identity each provider uses.
CREATE TABLE IF NOT EXISTS football_provider_matches (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  internal_match_id VARCHAR(190) NOT NULL,
  provider_id INT NULL,
  provider_code VARCHAR(64) NOT NULL,
  provider_match_id VARCHAR(190) NOT NULL,
  home_team_normalized VARCHAR(190) NOT NULL,
  away_team_normalized VARCHAR(190) NOT NULL,
  kickoff_date VARCHAR(10) NOT NULL,
  competition_internal_id VARCHAR(190) NULL,
  matched_by VARCHAR(32) NOT NULL DEFAULT 'PROVIDER_ID',
  confidence DECIMAL(5,4) NULL,
  first_seen_at VARCHAR(32) NOT NULL,
  last_seen_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_provider_match (provider_code, provider_match_id),
  UNIQUE KEY uq_football_match_provider (internal_match_id, provider_code),
  INDEX idx_football_match_internal (internal_match_id),
  INDEX idx_football_match_teams (home_team_normalized, away_team_normalized, kickoff_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Competition mapping. A premium league is an application-level classification,
-- not a provider id: every feed numbers the Premier League differently, so the
-- mapping carries the internal id, the name, the country, the tier and whether
-- this deployment treats the competition as premium.
CREATE TABLE IF NOT EXISTS football_competition_mapping (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  internal_id VARCHAR(190) NOT NULL,
  provider_id INT NULL,
  provider_code VARCHAR(64) NOT NULL,
  provider_competition_id VARCHAR(190) NOT NULL,
  competition_name VARCHAR(190) NOT NULL,
  country VARCHAR(96) NULL,
  tier VARCHAR(24) NOT NULL DEFAULT 'STANDARD',
  premium TINYINT(1) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at VARCHAR(32) NOT NULL,
  updated_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_competition_map (provider_code, provider_competition_id),
  UNIQUE KEY uq_football_competition_internal (internal_id, provider_code),
  INDEX idx_football_competition_premium (premium, active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Prediction revisions. One row per calculation of a fixture's prediction, kept
-- because the prediction row itself is unique per (fixture, kind, model version)
-- and is REPLACED when a stated reason justifies regenerating it. Movement — the
-- difference between what WINDELS said and what it now says — is only measurable
-- against a record of the earlier figure, so the trail is stored rather than
-- remembered. Keyed by prediction_id, which makes a re-run of the same sweep
-- idempotent instead of manufacturing a second data point.
CREATE TABLE IF NOT EXISTS football_prediction_revisions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  prediction_id VARCHAR(40) NOT NULL,
  fixture_id BIGINT NOT NULL,
  provider_id INT NULL,
  model_version_id INT NULL,
  prediction_kind VARCHAR(16) NOT NULL DEFAULT 'PRE_MATCH',
  probability_home DECIMAL(8,6) NULL,
  probability_draw DECIMAL(8,6) NULL,
  probability_away DECIMAL(8,6) NULL,
  predicted_result VARCHAR(8) NULL,
  predicted_home_score INT NULL,
  predicted_away_score INT NULL,
  confidence DECIMAL(6,2) NULL,
  data_quality_score INT NULL,
  data_quality_band VARCHAR(16) NULL,
  movement_points DECIMAL(7,4) NULL,
  movement_selection VARCHAR(24) NULL,
  previous_prediction_id VARCHAR(40) NULL,
  stability_state VARCHAR(16) NOT NULL DEFAULT 'BASELINE',
  trigger_codes TEXT NULL,
  kickoff_at VARCHAR(32) NULL,
  recorded_at VARCHAR(32) NOT NULL,
  created_at VARCHAR(32) NOT NULL,
  UNIQUE KEY uq_football_revision_prediction (prediction_id),
  INDEX idx_football_revision_fixture (fixture_id, prediction_kind, recorded_at),
  INDEX idx_football_revision_model (model_version_id, recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
