<?php
namespace LeadDiscovery;

/** Google Places API (New) Text Search adapter. No results are fabricated when unavailable. */
class GooglePlacesProvider implements LeadDiscoveryProvider
{
    private const URL = 'https://places.googleapis.com/v1/places:searchText';
    public function __construct(private ?string $apiKey = null, private int $timeoutSeconds = 12, private int $maxAttempts = 2)
    {
        if ($this->apiKey === null || $this->apiKey === '') {
            // Read the google_places row itself: lead_discovery also hosts
            // Apollo.io, and resolve() returns whichever provider is primary.
            $cfg = null;
            if (class_exists(\AIWorkforce\ApiProviders::class) && method_exists(\AIWorkforce\ApiProviders::class, 'resolveDriverForRequest')) {
                try { $cfg = \AIWorkforce\ApiProviders::resolveDriverForRequest('lead_discovery', 'google_places'); }
                catch (\Throwable $e) { $cfg = null; }
            }
            if (!is_array($cfg) && class_exists(\AIWorkforce\ApiProviders::class)) {
                $any = \AIWorkforce\ApiProviders::resolve('lead_discovery');
                $cfg = (is_array($any) && ($any['driver'] ?? '') === 'google_places') ? $any : null;
            }
            $managedKey = is_array($cfg) ? (string) ($cfg['secrets']['api_key'] ?? '') : '';
            $this->apiKey = $managedKey !== '' ? $managedKey : (string) (getenv('GOOGLE_PLACES_API_KEY') ?: '');
        }
    }
    public function name(): string { return 'google_places'; }
    public function healthCheck(): array
    { return $this->apiKey !== '' ? ['status'=>'IMPLEMENTED','detail'=>'Google Places Text Search configured'] : ['status'=>'DISABLED','detail'=>'Lead discovery provider is not configured']; }
    public function searchBusinesses(array $input): array
    {
        $health=$this->healthCheck(); if($health['status'] !== 'IMPLEMENTED') throw new ProviderException($health['detail'],503);
        $query=trim((string)($input['query']??'')); if($query==='') throw new ProviderException('search query is required',400);
        $payload=json_encode(['textQuery'=>$query,'maxResultCount'=>min(20,max(1,(int)($input['limit']??20)))]);
        $last=null;
        for($attempt=1;$attempt<=$this->maxAttempts;$attempt++) {
            try { return $this->normalize($this->post($payload)); }
            catch(ProviderException $e) { $last=$e; if(!$e->retryable || $attempt===$this->maxAttempts) throw $e; usleep(150000*$attempt); }
        }
        throw $last ?: new ProviderException('Google Places request failed');
    }
    /** Separated for deterministic integration tests with a staged transport. */
    protected function post(string $payload): array
    {
        $headers = [
            'Content-Type: application/json',
            'X-Goog-Api-Key: ' . $this->apiKey,
            'X-Goog-FieldMask: places.id,places.displayName,places.formattedAddress,places.types,places.nationalPhoneNumber,places.websiteUri,places.location',
        ];
        $status = 0;
        $body = '';
        $networkNote = '';
        // Prefer the same cURL-first transport the connection test uses
        // (ApiProviders::http). This provider used to rely on allow_url_fopen
        // / streams alone, so on hosts where that is Off but cURL works
        // (common on cPanel), Admin → Test Connection passed while the live
        // search failed with the opaque "feature temporarily unavailable".
        if (class_exists(\AIWorkforce\ApiProviders::class)
            && method_exists(\AIWorkforce\ApiProviders::class, 'http')) {
            $resp = \AIWorkforce\ApiProviders::http(self::URL, $headers, $payload);
            $status = (int) ($resp['status'] ?? 0);
            $body = (string) ($resp['body'] ?? '');
            $err = trim((string) ($resp['error'] ?? ''));
            if ($err !== '') $networkNote = ' (' . mb_substr($err, 0, 120) . ')';
        } else {
            // Standalone fallback (outside the CodeIgniter app): plain streams.
            $hdr = implode("\r\n", $headers) . "\r\n";
            $context = stream_context_create(['http' => [
                'method' => 'POST',
                'timeout' => $this->timeoutSeconds,
                'ignore_errors' => true,
                'header' => $hdr,
                'content' => $payload,
            ]]);
            $raw = @file_get_contents(self::URL, false, $context);
            foreach (($http_response_header ?? []) as $line) {
                if (preg_match('#HTTP/\S+\s+(\d+)#', $line, $m)) { $status = (int) $m[1]; break; }
            }
            if ($raw === false) {
                throw new ProviderException('Google Places request timed out or could not connect' . $networkNote, 503, true);
            }
            $body = (string) $raw;
        }
        if ($status === 0 && $body === '') {
            throw new ProviderException('Google Places request timed out or could not connect' . $networkNote, 503, true);
        }
        $decoded = json_decode($body, true);
        if (!is_array($decoded)) throw new ProviderException('Google Places returned an invalid response', 502, true);
        if ($status >= 400 || isset($decoded['error'])) {
            $message = (string) ($decoded['error']['message'] ?? 'Google Places request failed');
            throw new ProviderException($message, $status ?: 502, $status === 429 || $status >= 500);
        }
        return $decoded;
    }
    private function normalize(array $payload): array
    {
        $out=[]; foreach(($payload['places']??[]) as $p) { $sourceId=(string)($p['id']??''); if($sourceId==='') continue; $types=array_values($p['types']??[]); $out[]=['sourceId'=>$sourceId,'name'=>(string)($p['displayName']['text']??'Unnamed business'),'category'=>implode(', ',array_slice($types,0,3))?:null,'address'=>$p['formattedAddress']??null,'phone'=>$p['nationalPhoneNumber']??null,'website'=>$p['websiteUri']??null,'latitude'=>isset($p['location']['latitude'])?(float)$p['location']['latitude']:null,'longitude'=>isset($p['location']['longitude'])?(float)$p['location']['longitude']:null,'metadata'=>['provider'=>'Windels G','types'=>$types]]; }
        return $out;
    }
}
