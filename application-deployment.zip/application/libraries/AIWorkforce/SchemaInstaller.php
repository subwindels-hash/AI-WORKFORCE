<?php
namespace AIWorkforce;

/**
 * Single source of truth for which SQL modules make a working database.
 *
 * Used by php tools/install.php, php index.php tools install, and the first
 * request against an empty sqlite file so the offline runtime can boot
 * without a separate install step.
 */
final class SchemaInstaller
{
    /** SQL stems under application/database/{stem}.{sqlite|mysql}.sql */
    public const MODULES = [
        'schema',
        'sports_identity',
        'sports',
        'sports_decisions',
        'sports_results',
        'sports_intelligence',
        'football_intelligence',
        'langlearn',
        'lottery',
        'admin_portal',
        'admin_inbox',
        'direct_messages',
        'multiplier_intelligence',
    ];

    /** Every table created by the module files. Installers verify this list. */
    public const EXPECTED_TABLES = [
        'ci_sessions', 'platform_state', 'strategies', 'backtests', 'analysis_runs',
        'journal_entries', 'paper_accounts', 'paper_orders', 'paper_positions',
        'paper_trades', 'paper_deployments', 'audit_logs',
        'leads', 'lead_notes', 'lead_activities', 'collections', 'collection_leads',
        'search_history', 'duplicate_candidates', 'duplicate_resolutions', 'export_history',
        'lead_outreach', 'lead_organizations', 'lead_organization_members',
        'trade_proposals', 'trade_executions', 'notifications',
        'users', 'roles', 'permissions', 'user_roles', 'role_permissions', 'auth_events',
        'sports_data_sources', 'sports_provider_health', 'sports_matches', 'sports_odds',
        'sports_data_quality_assessments', 'sports_sync_runs', 'sports_model_versions',
        'sports_predictions', 'sports_tickets', 'sports_ticket_selections', 'sports_results',
        'sports_configurations', 'sports_calibrations', 'sports_job_runs', 'sports_backtests',
        'sports_model_metrics', 'sports_daily_tickets', 'sports_performance_snapshots',
        'football_providers', 'football_competitions', 'football_teams', 'football_fixtures',
        'football_team_statistics', 'football_fixture_statistics', 'football_head_to_head',
        'football_model_versions', 'football_calibration_versions', 'football_match_predictions',
        'football_score_probabilities', 'football_prediction_settlements',
        'football_model_performance', 'football_provider_sync_logs',
        'football_provider_matches', 'football_competition_mapping', 'football_prediction_revisions',
        'languages', 'user_language_profiles', 'language_assessments', 'learning_paths',
        'learning_modules', 'lesson_attempts', 'study_sessions', 'language_progress',
        'conversation_sessions', 'writing_attempts', 'vocabulary', 'user_vocabulary',
        'listening_attempts', 'speaking_attempts', 'daily_learning_plans', 'ai_learning_recommendations',
        'lotteries', 'lottery_rules', 'lottery_data_sources', 'lottery_provider_health',
        'lottery_draws', 'lottery_draw_numbers', 'lottery_sync_runs',
        'lottery_combinations', 'lottery_ai_decisions', 'lottery_tickets', 'lottery_ticket_lines',
        'lottery_backtests', 'lottery_model_versions',
        'admin_activity_logs', 'impersonation_sessions', 'platform_settings', 'api_providers',
        'contact_messages', 'contact_message_replies', 'email_templates',
        'direct_messages',
        'user_broker_connections',
        'crash_game_providers', 'crash_game_provider_health', 'crash_game_rounds',
        'crash_game_models', 'crash_game_predictions', 'crash_game_agent_executions',
        'crash_game_accuracy_snapshots', 'crash_game_active_signals',
    ];

    /** Representative tables — if any are missing, re-apply CREATE IF NOT EXISTS. */
    public const CORE_TABLES = ['users', 'languages', 'leads', 'lotteries', 'api_providers', 'sports_matches', 'contact_messages', 'football_fixtures'];

    private static bool $done = false;

    /**
     * Persistent cache version for the request-time schema guard. Bump whenever
     * idempotent upgrade logic changes without a matching SQL-file mtime change.
     */
    // Bumped after the daily-ticket migration guard was made column-aware.
    // Existing deployments may already have a stamp from a request that saw
    // the table but silently missed one of its ALTERs.
    // Bumped again for football_fixtures.live_confirmed_at: a stamped database
    // would otherwise skip the upgrade pass and never gain the column the Live
    // Match freshness gate now reads.
    private const STAMP_VERSION = '2026-09-15-handicap-lineless-odds-purge-v1';

    public static function databaseDir(): string
    {
        if (defined('APPPATH')) {
            return rtrim((string) APPPATH, '/\\') . DIRECTORY_SEPARATOR . 'database';
        }
        return dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'database';
    }

    public static function isSqlite(object|string $dbOrDriver): bool
    {
        if (is_string($dbOrDriver)) {
            return str_contains($dbOrDriver, 'sqlite');
        }
        $driver = (string) ($dbOrDriver->dbdriver ?? $dbOrDriver->platform ?? '');
        $sub = (string) ($dbOrDriver->subdriver ?? '');
        if (method_exists($dbOrDriver, 'platform')) {
            try { $driver .= ' ' . (string) $dbOrDriver->platform(); } catch (\Throwable $e) { /* ignore */ }
        }
        return str_contains($driver, 'sqlite') || $sub === 'sqlite';
    }

    /** PostgreSQL driver (native `postgre` or PDO `pdo_pgsql`). */
    public static function isPgsql(object|string $dbOrDriver): bool
    {
        if (is_string($dbOrDriver)) {
            $d = strtolower($dbOrDriver);
            return str_contains($d, 'pgsql') || str_contains($d, 'postgre');
        }
        $driver = strtolower((string) ($dbOrDriver->dbdriver ?? ''));
        $sub = strtolower((string) ($dbOrDriver->subdriver ?? ''));
        return str_contains($driver, 'pgsql') || str_contains($driver, 'postgre') || $sub === 'pgsql';
    }

    /** Normalised dialect key: 'sqlite' | 'pgsql' | 'mysql'. */
    public static function dialect(object|string $dbOrDriver): string
    {
        if (self::isSqlite($dbOrDriver)) return 'sqlite';
        if (self::isPgsql($dbOrDriver)) return 'pgsql';
        return 'mysql';
    }

    /** @return list<string> existing module SQL paths for one dialect */
    public static function files(string $dialect): array
    {
        $dir = self::databaseDir();
        $ext = match ($dialect) {
            'sqlite' => 'sqlite',
            'pgsql' => 'pgsql',
            default => 'mysql',
        };
        $out = [];
        foreach (self::MODULES as $stem) {
            $path = $dir . DIRECTORY_SEPARATOR . $stem . '.' . $ext . '.sql';
            if (is_file($path)) $out[] = $path;
        }
        return $out;
    }

    /** @return list<string> */
    public static function statementsFrom(string $sql): array
    {
        $sql = preg_replace('/^\s*--[^\r\n]*[\r\n]?/m', '', $sql) ?? $sql;
        $parts = preg_split('/;\s*(?:\r?\n|$)/', $sql) ?: [];
        $out = [];
        foreach ($parts as $stmt) {
            $stmt = trim($stmt);
            $stmt = rtrim($stmt, ';');
            $stmt = trim($stmt);
            if ($stmt !== '') $out[] = $stmt;
        }
        return $out;
    }

    /** @param callable(string):mixed $exec */
    public static function applyFiles(callable $exec, string $dialect): void
    {
        foreach (self::files($dialect) as $file) {
            $sql = (string) file_get_contents($file);
            if (str_contains(basename($file), 'langlearn.') && !str_contains($sql, 'daily_minutes')) {
                throw new \RuntimeException('langlearn schema is missing daily_minutes: ' . $file);
            }
            foreach (self::statementsFrom($sql) as $stmt) {
                $exec($stmt);
            }
        }
    }

    /** Idempotent ALTERs + indexes for databases created from older schemas. */
    /** @param callable(string):mixed $exec */
    /** Idempotent ALTERs + indexes for databases created from older schemas. */
    /** @param callable(string):mixed $exec */
    public static function upgrade(callable $exec, string $dialect): void
    {
        $sqlite = $dialect === 'sqlite';
        $pgsql = $dialect === 'pgsql';
        /** Pick the statement for this dialect: (sqlite, mysql, pgsql). */
        $pick = static fn(string $sq, string $my, ?string $pg = null): string => $sqlite ? $sq : ($pgsql ? ($pg ?? $my) : $my);

        $alters = [
            $pick(
                'ALTER TABLE user_language_profiles ADD COLUMN daily_minutes INTEGER NOT NULL DEFAULT 20',
                'ALTER TABLE user_language_profiles ADD COLUMN daily_minutes INT NOT NULL DEFAULT 20',
                'ALTER TABLE user_language_profiles ADD COLUMN IF NOT EXISTS daily_minutes INTEGER NOT NULL DEFAULT 20',
            ),
            // Adaptive confidence tiers (requirements #1/#8) on existing
            // installs. NULL means "derive from min_confidence and
            // min_data_quality", so upgrading changes no operator's policy.
            $pick('ALTER TABLE sports_configurations ADD COLUMN confidence_policy TEXT', 'ALTER TABLE sports_configurations ADD COLUMN confidence_policy TEXT NULL', 'ALTER TABLE sports_configurations ADD COLUMN IF NOT EXISTS confidence_policy TEXT'),
            // Staking discipline (2026-09-17): FLAT keeps the fixed
            // stake_amount; FRACTIONAL_KELLY sizes each ticket's stake as
            // kelly_fraction × full Kelly against bankroll (see StakeSizer).
            // Existing installs default to FLAT — upgrading changes nobody's
            // staking behaviour.
            $pick("ALTER TABLE sports_configurations ADD COLUMN staking_mode TEXT NOT NULL DEFAULT 'FLAT'", "ALTER TABLE sports_configurations ADD COLUMN staking_mode VARCHAR(20) NOT NULL DEFAULT 'FLAT'", "ALTER TABLE sports_configurations ADD COLUMN IF NOT EXISTS staking_mode VARCHAR(20) NOT NULL DEFAULT 'FLAT'"),
            $pick('ALTER TABLE sports_configurations ADD COLUMN bankroll REAL NOT NULL DEFAULT 1000', 'ALTER TABLE sports_configurations ADD COLUMN bankroll DECIMAL(14,2) NOT NULL DEFAULT 1000', 'ALTER TABLE sports_configurations ADD COLUMN IF NOT EXISTS bankroll DECIMAL(14,2) NOT NULL DEFAULT 1000'),
            $pick('ALTER TABLE sports_configurations ADD COLUMN kelly_fraction REAL NOT NULL DEFAULT 0.25', 'ALTER TABLE sports_configurations ADD COLUMN kelly_fraction DECIMAL(5,4) NOT NULL DEFAULT 0.25', 'ALTER TABLE sports_configurations ADD COLUMN IF NOT EXISTS kelly_fraction DECIMAL(5,4) NOT NULL DEFAULT 0.25'),
            $pick('ALTER TABLE sports_tickets ADD COLUMN stake REAL', 'ALTER TABLE sports_tickets ADD COLUMN stake DECIMAL(12,2) NULL', 'ALTER TABLE sports_tickets ADD COLUMN IF NOT EXISTS stake DECIMAL(12,2)'),
            $pick('ALTER TABLE sports_tickets ADD COLUMN pnl REAL', 'ALTER TABLE sports_tickets ADD COLUMN pnl DECIMAL(14,4) NULL', 'ALTER TABLE sports_tickets ADD COLUMN IF NOT EXISTS pnl DECIMAL(14,4)'),
            $pick('ALTER TABLE sports_tickets ADD COLUMN average_confidence REAL', 'ALTER TABLE sports_tickets ADD COLUMN average_confidence DECIMAL(10,4) NULL', 'ALTER TABLE sports_tickets ADD COLUMN IF NOT EXISTS average_confidence DECIMAL(10,4)'),
            $pick('ALTER TABLE sports_tickets ADD COLUMN average_data_quality REAL', 'ALTER TABLE sports_tickets ADD COLUMN average_data_quality DECIMAL(10,4) NULL', 'ALTER TABLE sports_tickets ADD COLUMN IF NOT EXISTS average_data_quality DECIMAL(10,4)'),
            $pick('ALTER TABLE sports_tickets ADD COLUMN odds_calculation TEXT', 'ALTER TABLE sports_tickets ADD COLUMN odds_calculation TEXT NULL', 'ALTER TABLE sports_tickets ADD COLUMN IF NOT EXISTS odds_calculation TEXT'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN fixture_id TEXT', 'ALTER TABLE sports_ticket_selections ADD COLUMN fixture_id VARCHAR(128) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS fixture_id VARCHAR(128)'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN home_team TEXT', 'ALTER TABLE sports_ticket_selections ADD COLUMN home_team VARCHAR(255) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS home_team VARCHAR(255)'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN away_team TEXT', 'ALTER TABLE sports_ticket_selections ADD COLUMN away_team VARCHAR(255) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS away_team VARCHAR(255)'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN kickoff_time TEXT', 'ALTER TABLE sports_ticket_selections ADD COLUMN kickoff_time VARCHAR(32) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS kickoff_time VARCHAR(32)'),
            // Team crest URLs, carried through from the provider fixture so a
            // ticket leg can show each side's logo. Null for providers (or
            // legacy rows) that never sent one — never a guessed image.
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN home_team_logo TEXT', 'ALTER TABLE sports_ticket_selections ADD COLUMN home_team_logo VARCHAR(500) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS home_team_logo VARCHAR(500)'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN away_team_logo TEXT', 'ALTER TABLE sports_ticket_selections ADD COLUMN away_team_logo VARCHAR(500) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS away_team_logo VARCHAR(500)'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN confidence REAL', 'ALTER TABLE sports_ticket_selections ADD COLUMN confidence DECIMAL(10,4) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS confidence DECIMAL(10,4)'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN data_quality REAL', 'ALTER TABLE sports_ticket_selections ADD COLUMN data_quality DECIMAL(10,4) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS data_quality DECIMAL(10,4)'),
            // Odds provenance on the leg itself: which feed supplied the real
            // bookmaker price, and the model's own fair odds kept beside it so
            // a reader can never mistake one number for the other.
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN odds_source TEXT', 'ALTER TABLE sports_ticket_selections ADD COLUMN odds_source VARCHAR(32) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS odds_source VARCHAR(32)'),
            $pick('ALTER TABLE sports_ticket_selections ADD COLUMN fair_odds REAL', 'ALTER TABLE sports_ticket_selections ADD COLUMN fair_odds DECIMAL(14,6) NULL', 'ALTER TABLE sports_ticket_selections ADD COLUMN IF NOT EXISTS fair_odds DECIMAL(14,6)'),
            $pick('ALTER TABLE sports_predictions ADD COLUMN odds REAL', 'ALTER TABLE sports_predictions ADD COLUMN odds DECIMAL(14,6) NULL', 'ALTER TABLE sports_predictions ADD COLUMN IF NOT EXISTS odds DECIMAL(14,6)'),
            $pick('ALTER TABLE sports_predictions ADD COLUMN odds_timestamp TEXT', 'ALTER TABLE sports_predictions ADD COLUMN odds_timestamp VARCHAR(32) NULL', 'ALTER TABLE sports_predictions ADD COLUMN IF NOT EXISTS odds_timestamp VARCHAR(32)'),
            // Daily odds-prediction generation state. `status` remains the
            // public prediction outcome; generation_status is the lock/retry
            // state and reaches GENERATED only after a ticket exists.
            $pick("ALTER TABLE sports_configurations ADD COLUMN system_timezone TEXT NOT NULL DEFAULT 'UTC'", "ALTER TABLE sports_configurations ADD COLUMN system_timezone VARCHAR(64) NOT NULL DEFAULT 'UTC'", "ALTER TABLE sports_configurations ADD COLUMN IF NOT EXISTS system_timezone VARCHAR(64) NOT NULL DEFAULT 'UTC'"),
            $pick("ALTER TABLE sports_daily_tickets ADD COLUMN ticket_type TEXT NOT NULL DEFAULT 'ODDS_PREDICTION'", "ALTER TABLE sports_daily_tickets ADD COLUMN ticket_type VARCHAR(32) NOT NULL DEFAULT 'ODDS_PREDICTION'", "ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS ticket_type VARCHAR(32) NOT NULL DEFAULT 'ODDS_PREDICTION'"),
            $pick("ALTER TABLE sports_daily_tickets ADD COLUMN generation_status TEXT NOT NULL DEFAULT 'PENDING'", "ALTER TABLE sports_daily_tickets ADD COLUMN generation_status VARCHAR(16) NOT NULL DEFAULT 'PENDING'", "ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS generation_status VARCHAR(16) NOT NULL DEFAULT 'PENDING'"),
            $pick('ALTER TABLE sports_daily_tickets ADD COLUMN attempt_count INTEGER NOT NULL DEFAULT 0', 'ALTER TABLE sports_daily_tickets ADD COLUMN attempt_count INT NOT NULL DEFAULT 0', 'ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS attempt_count INTEGER NOT NULL DEFAULT 0'),
            $pick('ALTER TABLE sports_daily_tickets ADD COLUMN next_retry_at TEXT', 'ALTER TABLE sports_daily_tickets ADD COLUMN next_retry_at DATETIME NULL', 'ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS next_retry_at TIMESTAMP NULL'),
            $pick('ALTER TABLE sports_daily_tickets ADD COLUMN last_error_code TEXT', 'ALTER TABLE sports_daily_tickets ADD COLUMN last_error_code VARCHAR(64) NULL', 'ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS last_error_code VARCHAR(64)'),
            $pick('ALTER TABLE sports_daily_tickets ADD COLUMN generated_at TEXT', 'ALTER TABLE sports_daily_tickets ADD COLUMN generated_at DATETIME NULL', 'ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS generated_at TIMESTAMP NULL'),
            $pick("ALTER TABLE sports_daily_tickets ADD COLUMN system_timezone TEXT NOT NULL DEFAULT 'UTC'", "ALTER TABLE sports_daily_tickets ADD COLUMN system_timezone VARCHAR(64) NOT NULL DEFAULT 'UTC'", "ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS system_timezone VARCHAR(64) NOT NULL DEFAULT 'UTC'"),
            $pick('ALTER TABLE sports_daily_tickets ADD COLUMN window_start_utc TEXT', 'ALTER TABLE sports_daily_tickets ADD COLUMN window_start_utc VARCHAR(32) NULL', 'ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS window_start_utc VARCHAR(32)'),
            $pick('ALTER TABLE sports_daily_tickets ADD COLUMN window_end_utc TEXT', 'ALTER TABLE sports_daily_tickets ADD COLUMN window_end_utc VARCHAR(32) NULL', 'ALTER TABLE sports_daily_tickets ADD COLUMN IF NOT EXISTS window_end_utc VARCHAR(32)'),
            $pick('ALTER TABLE lottery_sync_runs ADD COLUMN payload TEXT', 'ALTER TABLE lottery_sync_runs ADD COLUMN payload MEDIUMTEXT NULL', 'ALTER TABLE lottery_sync_runs ADD COLUMN IF NOT EXISTS payload TEXT'),
            $pick('ALTER TABLE sports_matches ADD COLUMN round_id TEXT', 'ALTER TABLE sports_matches ADD COLUMN round_id VARCHAR(64) NULL', 'ALTER TABLE sports_matches ADD COLUMN IF NOT EXISTS round_id VARCHAR(64)'),
            $pick('ALTER TABLE users ADD COLUMN username TEXT', 'ALTER TABLE users ADD COLUMN username VARCHAR(64) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(64)'),
            $pick('ALTER TABLE users ADD COLUMN user_uid TEXT', 'ALTER TABLE users ADD COLUMN user_uid CHAR(6) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS user_uid CHAR(6)'),
            $pick('ALTER TABLE users ADD COLUMN profile_image TEXT', 'ALTER TABLE users ADD COLUMN profile_image VARCHAR(255) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_image VARCHAR(255)'),
            $pick('ALTER TABLE users ADD COLUMN phone TEXT', 'ALTER TABLE users ADD COLUMN phone VARCHAR(40) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(40)'),
            $pick('ALTER TABLE users ADD COLUMN address TEXT', 'ALTER TABLE users ADD COLUMN address VARCHAR(255) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS address VARCHAR(255)'),
            $pick('ALTER TABLE users ADD COLUMN security_pin TEXT', 'ALTER TABLE users ADD COLUMN security_pin CHAR(4) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS security_pin CHAR(4)'),
            $pick('ALTER TABLE users ADD COLUMN security_question TEXT', 'ALTER TABLE users ADD COLUMN security_question VARCHAR(255) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS security_question VARCHAR(255)'),
            $pick('ALTER TABLE users ADD COLUMN security_answer TEXT', 'ALTER TABLE users ADD COLUMN security_answer VARCHAR(255) NULL', 'ALTER TABLE users ADD COLUMN IF NOT EXISTS security_answer VARCHAR(255)'),
            // Football: the daily provider-request counter is only trusted for the
            // day it was written, so a ceiling cannot leak across midnight.
            $pick('ALTER TABLE football_providers ADD COLUMN requests_used_date TEXT', 'ALTER TABLE football_providers ADD COLUMN requests_used_date DATE NULL', 'ALTER TABLE football_providers ADD COLUMN IF NOT EXISTS requests_used_date DATE'),
            // Football: when a provider live snapshot last reported this fixture
            // as in play. Live Match reads this column and not `updated_at`,
            // which any unrelated write (a day sweep, a statistics collection,
            // a competition link) refreshes — that is what used to keep a
            // finished match pinned to the Live now section indefinitely.
            $pick('ALTER TABLE football_fixtures ADD COLUMN live_confirmed_at TEXT', 'ALTER TABLE football_fixtures ADD COLUMN live_confirmed_at VARCHAR(32) NULL', 'ALTER TABLE football_fixtures ADD COLUMN IF NOT EXISTS live_confirmed_at VARCHAR(32)'),
            $pick('ALTER TABLE leads ADD COLUMN email TEXT', 'ALTER TABLE leads ADD COLUMN email VARCHAR(255) NULL', 'ALTER TABLE leads ADD COLUMN IF NOT EXISTS email VARCHAR(255)'),
            $pick('ALTER TABLE leads ADD COLUMN job_title TEXT', 'ALTER TABLE leads ADD COLUMN job_title VARCHAR(255) NULL', 'ALTER TABLE leads ADD COLUMN IF NOT EXISTS job_title VARCHAR(255)'),
            $pick('ALTER TABLE leads ADD COLUMN company_name TEXT', 'ALTER TABLE leads ADD COLUMN company_name VARCHAR(255) NULL', 'ALTER TABLE leads ADD COLUMN IF NOT EXISTS company_name VARCHAR(255)'),
            $pick('ALTER TABLE leads ADD COLUMN linkedin_url TEXT', 'ALTER TABLE leads ADD COLUMN linkedin_url TEXT NULL', 'ALTER TABLE leads ADD COLUMN IF NOT EXISTS linkedin_url TEXT'),
            $pick(
                "ALTER TABLE leads ADD COLUMN lead_kind TEXT NOT NULL DEFAULT 'business'",
                "ALTER TABLE leads ADD COLUMN lead_kind VARCHAR(20) NOT NULL DEFAULT 'business'",
                "ALTER TABLE leads ADD COLUMN IF NOT EXISTS lead_kind VARCHAR(20) NOT NULL DEFAULT 'business'",
            ),
        ];
        foreach ($alters as $sql) {
            try { $exec($sql); } catch (\Throwable $e) { /* column already exists */ }
        }

        // Column-width contract for the sports calibration + audit paths.
        // sports_calibrations.method was VARCHAR(16): the 18-character
        // 'identity-bootstrap' marker was silently truncated (or rejected in
        // strict mode), so the engine's cold-start bootstrap row could never
        // be read back and prediction stayed locked out. audit_logs.actor
        // was VARCHAR(8) and type VARCHAR(32): long actors such as
        // 'system:daily-ticket' and dynamic transition types such as
        // 'AUTOMATIC_PROTECTION_AUTOMATIC_PAUSED' (35 chars) failed the
        // insert, losing the audit trail the engines depend on.
        // The CREATE statements now ship 32/64/64; these ALTERs repair
        // existing MySQL/PostgreSQL databases and are harmless on re-runs
        // (MODIFY to the same definition is a no-op). SQLite stores these as
        // TEXT and enforces no length, so there is nothing to widen there.
        if (!$sqlite) {
            $widthFixes = $pgsql
                ? [
                    'ALTER TABLE sports_calibrations ALTER COLUMN "method" TYPE VARCHAR(32)',
                    'ALTER TABLE audit_logs ALTER COLUMN "actor" TYPE VARCHAR(64)',
                    'ALTER TABLE audit_logs ALTER COLUMN "type" TYPE VARCHAR(64)',
                ]
                : [
                    // sports_daily_tickets.rejection_summary was TEXT (65,535
                    // bytes). The run diagnostics stored with the daily row
                    // (stage ledger, up to 100 rejection-audit rows, the
                    // per-failure-code run summary) exceed that on a busy
                    // fixture day, and MySQL strict mode then rejected the
                    // whole UPDATE — [1406] Data too long for column
                    // 'rejection_summary' — failing a generation run whose
                    // ticket had already been produced. MEDIUMTEXT (16MB) is
                    // the width the CREATE statements now ship.
                    'ALTER TABLE sports_daily_tickets MODIFY rejection_summary MEDIUMTEXT NULL',
                    "ALTER TABLE sports_calibrations MODIFY method VARCHAR(32) NOT NULL DEFAULT 'platt'",
                    "ALTER TABLE audit_logs MODIFY actor VARCHAR(64) NOT NULL DEFAULT 'system'",
                    'ALTER TABLE audit_logs MODIFY type VARCHAR(64) NOT NULL',
                ];
            foreach ($widthFixes as $sql) {
                try { $exec($sql); } catch (\Throwable $e) { /* already wide / table missing on partial installs */ }
            }
        }

        // Repair the built-in sports ticket policy (2026-09-17) — 30%+
        // confidence, quality 55+, +3% minimum edge, LOW correlation, at most
        // 2 selections inside a 2.00–3.50 combined-odds window. Only the
        // untouched system default row is amended;
        // operator-authored configuration versions remain append-only and
        // under admin control.
        try {
            $exec("UPDATE sports_configurations SET min_confidence = 30, min_data_quality = 55, min_expected_value = 0.03, max_correlation = 'LOW', max_selections = 2, target_odds_min = 2.0, target_odds_max = 3.5 WHERE version = 0 AND updated_by = 'system' AND reason = 'built-in defaults' AND (min_confidence <> 30 OR min_data_quality <> 55 OR min_expected_value <> 0.03 OR max_correlation <> 'LOW' OR max_selections <> 2 OR target_odds_min <> 2.0 OR target_odds_max <> 3.5)");
        } catch (\Throwable $e) { /* table may not exist yet on partial installs */ }

        // Purge handicap odds ingested WITHOUT their line. api-football sends
        // the line in a separate `handicap` field, and the pre-match mapper
        // used to drop it, so "Away +2" and "Away -2" both landed as a bare
        // AWAY: two different bets on one market:selection key, where the last
        // row ingested won and its price was then attributed to whichever line
        // the model priced (the 2026-09-15 "549% edge" ticket).
        //
        // These rows are unusable rather than merely wrong — a lineless
        // selection cannot be priced or settled, so ScoreGridPricer already
        // refuses them. Deleting them lets the next provider sync repopulate
        // the same fixtures with line-qualified rows instead of leaving dead
        // records that can only ever be skipped.
        //
        // Deliberately narrow: only handicap markets, only selections that are
        // EXACTLY a bare side. A line-qualified row (AWAY_PLUS_2) and every
        // non-handicap market (MATCH_RESULT's legitimate bare HOME/AWAY) are
        // untouched. Prices are re-fetched from the provider, never invented.
        try {
            $exec("DELETE FROM sports_odds WHERE market IN ('ASIAN_HANDICAP', 'EUROPEAN_HANDICAP') AND selection IN ('HOME', 'AWAY', 'DRAW')");
        } catch (\Throwable $e) { /* table may not exist yet on partial installs */ }

        // Heal legacy daily rows. A ticket reference is evidence of a generated
        // result; an attempt/status without a ticket is deliberately NOT.
        try {
            $exec("UPDATE sports_daily_tickets SET ticket_type = 'ODDS_PREDICTION', generation_status = CASE WHEN ticket_id IS NOT NULL AND ticket_id <> '' THEN 'GENERATED' WHEN status = 'DATA_UNAVAILABLE' THEN 'RETRYING' ELSE 'PENDING' END, generated_at = CASE WHEN ticket_id IS NOT NULL AND ticket_id <> '' THEN updated_at ELSE NULL END WHERE generation_status IS NULL OR generation_status = 'PENDING'");
        } catch (\Throwable $e) { /* table/columns may be absent on partial installs */ }

        $userBrokers = $pick(
            "CREATE TABLE IF NOT EXISTS user_broker_connections (
                  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, broker TEXT NOT NULL,
                  label TEXT NULL, base_url TEXT NOT NULL, extra_url TEXT NULL, token_ciphertext TEXT NULL,
                  token_nonce TEXT NULL, account_hint TEXT NULL, enabled INTEGER NOT NULL DEFAULT 0,
                  trading_enabled INTEGER NOT NULL DEFAULT 0, live_allowed INTEGER NOT NULL DEFAULT 0,
                  last_test_ok INTEGER NULL, last_test_message TEXT NULL, last_test_at TEXT NULL,
                  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(user_id, broker))",
            "CREATE TABLE IF NOT EXISTS user_broker_connections (
                  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, broker VARCHAR(40) NOT NULL,
                  label VARCHAR(120) NULL, base_url VARCHAR(255) NOT NULL, extra_url VARCHAR(255) NULL,
                  token_ciphertext TEXT NULL, token_nonce VARCHAR(64) NULL, account_hint VARCHAR(120) NULL,
                  enabled TINYINT(1) NOT NULL DEFAULT 0, trading_enabled TINYINT(1) NOT NULL DEFAULT 0,
                  live_allowed TINYINT(1) NOT NULL DEFAULT 0, last_test_ok TINYINT(1) NULL,
                  last_test_message VARCHAR(255) NULL, last_test_at VARCHAR(32) NULL,
                  created_at VARCHAR(32) NOT NULL, updated_at VARCHAR(32) NOT NULL,
                  UNIQUE KEY uq_user_broker (user_id, broker), KEY idx_user_enabled (user_id, enabled)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS user_broker_connections (
                  id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, broker VARCHAR(40) NOT NULL,
                  label VARCHAR(120) NULL, base_url VARCHAR(255) NOT NULL, extra_url VARCHAR(255) NULL,
                  token_ciphertext TEXT NULL, token_nonce VARCHAR(64) NULL, account_hint VARCHAR(120) NULL,
                  enabled SMALLINT NOT NULL DEFAULT 0, trading_enabled SMALLINT NOT NULL DEFAULT 0,
                  live_allowed SMALLINT NOT NULL DEFAULT 0, last_test_ok SMALLINT NULL,
                  last_test_message VARCHAR(255) NULL, last_test_at VARCHAR(32) NULL,
                  created_at VARCHAR(32) NOT NULL, updated_at VARCHAR(32) NOT NULL,
                  CONSTRAINT uq_user_broker UNIQUE (user_id, broker))",
        );
        try { $exec($userBrokers); } catch (\Throwable $e) { /* already exists */ }

        $outreach = $pick(
            "CREATE TABLE IF NOT EXISTS lead_outreach (
                  id TEXT PRIMARY KEY, organization_id TEXT NOT NULL, lead_id TEXT NOT NULL,
                  actor_id INTEGER, channel TEXT NOT NULL, subject TEXT, body TEXT NOT NULL,
                  status TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
                )",
            "CREATE TABLE IF NOT EXISTS lead_outreach (
                  id VARCHAR(36) PRIMARY KEY, organization_id VARCHAR(80) NOT NULL, lead_id VARCHAR(36) NOT NULL,
                  actor_id INT NULL, channel VARCHAR(20) NOT NULL, subject VARCHAR(200) NULL, body TEXT NOT NULL,
                  status VARCHAR(20) NOT NULL, detail LONGTEXT NOT NULL, created_at VARCHAR(32) NOT NULL,
                  KEY idx_outreach_lead (organization_id, lead_id, created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS lead_outreach (
                  id VARCHAR(36) PRIMARY KEY, organization_id VARCHAR(80) NOT NULL, lead_id VARCHAR(36) NOT NULL,
                  actor_id INTEGER NULL, channel VARCHAR(20) NOT NULL, subject VARCHAR(200) NULL, body TEXT NOT NULL,
                  status VARCHAR(20) NOT NULL, detail TEXT NOT NULL DEFAULT '{}', created_at VARCHAR(32) NOT NULL)",
        );
        try { $exec($outreach); } catch (\Throwable $e) { /* already exists */ }

        // `IF NOT EXISTS` is supported by SQLite and PostgreSQL; MySQL uses the
        // classic form. The two unique user indexes carry MySQL's canonical names.
        $ifne = $sqlite || $pgsql ? 'IF NOT EXISTS ' : '';
        $indexes = [
            $pick('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username)', 'CREATE UNIQUE INDEX uq_users_username ON users(username)', 'CREATE UNIQUE INDEX IF NOT EXISTS uq_users_username ON users(username)'),
            $pick('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_user_uid ON users(user_uid)', 'CREATE UNIQUE INDEX uq_users_user_uid ON users(user_uid)', 'CREATE UNIQUE INDEX IF NOT EXISTS uq_users_user_uid ON users(user_uid)'),
            // Database-level concurrency guard: one odds-prediction daily slot
            // per configured-local calendar date. Legacy databases may also
            // retain their stronger UNIQUE(date) index; both are compatible.
            $pick('CREATE UNIQUE INDEX IF NOT EXISTS uq_sports_daily_ticket_type_date ON sports_daily_tickets(ticket_type, date)', 'CREATE UNIQUE INDEX uq_sports_daily_ticket_type_date ON sports_daily_tickets(ticket_type, date)', 'CREATE UNIQUE INDEX IF NOT EXISTS uq_sports_daily_ticket_type_date ON sports_daily_tickets(ticket_type, date)'),
            'CREATE INDEX ' . $ifne . 'idx_outreach_lead ON lead_outreach(organization_id, lead_id, created_at)',
            'CREATE INDEX ' . $ifne . 'idx_sports_odds_provider ON sports_odds (provider_id, observed_at)',
            'CREATE INDEX ' . $ifne . 'idx_sports_matches_provider_kickoff ON sports_matches (provider_id, kickoff_at)',
            'CREATE INDEX ' . $ifne . 'idx_sports_matches_round ON sports_matches (provider_id, round_id)',
            'CREATE INDEX ' . $ifne . 'idx_sports_predictions_market ON sports_predictions (market, created_at)',
            'CREATE INDEX ' . $ifne . 'idx_sports_selections_market ON sports_ticket_selections (market, selection)',
            'CREATE INDEX ' . $ifne . 'idx_sports_selections_match ON sports_ticket_selections (match_id)',
            'CREATE INDEX ' . $ifne . 'idx_sports_predictions_created ON sports_predictions (created_at)',
            'CREATE INDEX ' . $ifne . 'idx_sports_health_provider ON sports_provider_health (provider_id, observed_at)',
            // Football intelligence read paths: date board, live sweep, settlement queue.
            'CREATE INDEX ' . $ifne . 'idx_football_fixture_kickoff ON football_fixtures (kickoff_at)',
            'CREATE INDEX ' . $ifne . 'idx_football_fixture_status ON football_fixtures (status, kickoff_at)',
            'CREATE INDEX ' . $ifne . 'idx_football_fixture_settle ON football_fixtures (settled_at, status)',
            'CREATE INDEX ' . $ifne . 'idx_football_prediction_generated ON football_match_predictions (generated_at)',
            'CREATE INDEX ' . $ifne . 'idx_football_prediction_settle ON football_match_predictions (settlement_state, generated_at)',
            'CREATE INDEX ' . $ifne . 'idx_football_settlement_settled ON football_prediction_settlements (settled_at)',
            'CREATE INDEX ' . $ifne . 'idx_football_team_stats_team ON football_team_statistics (team_external_id, fetched_at)',
            'CREATE INDEX ' . $ifne . 'idx_football_sync_job ON football_provider_sync_logs (job_type, started_at)',
            // Hot-path indexes for the WASM dashboard: countPredictions by date
            // (kickoff_at range) and listTeamRecentResults (provider+status+kickoff)
            // previously did full table scans under pdo_sqlite (~10ms/scan).
            'CREATE INDEX ' . $ifne . 'idx_football_prediction_kickoff ON football_match_predictions (kickoff_at)',
            'CREATE INDEX ' . $ifne . 'idx_football_prediction_fixture ON football_match_predictions (fixture_id, prediction_kind)',
            'CREATE INDEX ' . $ifne . 'idx_football_fixture_provider_status ON football_fixtures (provider_id, status, kickoff_at)',
        ];
        foreach ($indexes as $sql) {
            try { $exec($sql); } catch (\Throwable $e) { /* already exists */ }
        }
    }


    /** First-request / CI boot: create any missing modules, then run upgrades. */
    public static function ensure(object $db): void
    {
        if (self::$done) return;
        self::$done = true;
        $dialect = self::dialect($db);

        // PHP-FPM and the WASM preview both start a fresh PHP request context, so
        // the static guard above only helps inside one request. Without this small
        // persistent stamp every page load re-ran the full migration guard: table
        // inventory, dozens of failed ALTER COLUMN attempts, and index creation
        // probes. That is safe but very slow. A valid stamp means a previous
        // request/install verified this exact schema-file fingerprint.
        if (self::stampFresh($db, $dialect)) return;

        // Apply module files whenever any expected table is missing, not just core.
        // CREATE IF NOT EXISTS makes this idempotent and cheap on healthy boots.
        $missing = !self::hasExpectedTables($db, $dialect);
        $exec = function (string $sql) use ($db) {
            try { $db->query($sql); } catch (\Throwable $e) { /* duplicate / racing request */ }
        };
        if ($missing) self::applyFiles($exec, $dialect);
        self::upgrade($exec, $dialect);

        // Only stamp healthy databases. If a migration failed or permissions hide
        // metadata, keep the old fail-safe behaviour and try again next request.
        if (self::hasExpectedTables($db, $dialect)
            && self::hasDailyTicketColumns($db, $dialect)) {
            self::writeStamp($db, $dialect);
        }
    }

    /**
     * The request-time fast path must verify the contract that is most likely
     * to break a generation run. Table existence alone is insufficient for
     * legacy databases because CREATE TABLE IF NOT EXISTS does not add columns.
     */
    private static function hasDailyTicketColumns(object $db, string $dialect): bool
    {
        $required = [
            'id', 'date', 'ticket_type', 'ticket_id', 'status', 'generation_status',
            'configuration_version', 'candidates_evaluated', 'predictions_recorded',
            'rejections', 'rejection_summary', 'message', 'provider', 'run_id',
            'attempt_count', 'next_retry_at', 'last_error_code', 'generated_at',
            'system_timezone', 'window_start_utc', 'window_end_utc', 'created_at', 'updated_at',
        ];
        try {
            if ($dialect === 'sqlite') {
                $result = $db->query("PRAGMA table_info('sports_daily_tickets')");
            } elseif ($dialect === 'pgsql') {
                $result = $db->query("SELECT column_name FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'sports_daily_tickets'");
            } else {
                $result = $db->query('SHOW COLUMNS FROM sports_daily_tickets');
            }
            if (!$result || !method_exists($result, 'result_array')) return false;
            $columns = [];
            foreach ($result->result_array() as $row) {
                $name = $row['name'] ?? $row['column_name'] ?? $row['Field'] ?? reset($row);
                if ($name !== false && $name !== null) $columns[] = strtolower((string) $name);
            }
            return count(array_diff($required, $columns)) === 0;
        } catch (\Throwable $e) {
            return false;
        }
    }

    private static function hasExpectedTables(object $db, string $dialect): bool
    {
        try {
            $have = [];
            if ($dialect === 'sqlite') {
                $r = $db->query("SELECT name FROM sqlite_master WHERE type='table'");
                foreach ($r->result_array() as $row) $have[] = (string) (reset($row));
            } elseif ($dialect === 'pgsql') {
                $r = $db->query("SELECT table_name FROM information_schema.tables WHERE table_schema = current_schema()");
                foreach ($r->result_array() as $row) $have[] = (string) (reset($row));
            } else {
                $r = $db->query('SHOW TABLES');
                foreach ($r->result_array() as $row) $have[] = (string) (reset($row));
            }
            foreach (self::EXPECTED_TABLES as $t) {
                if (!in_array($t, $have, true)) return false;
            }
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    private static function fingerprint(string $dialect): string
    {
        $parts = [self::STAMP_VERSION, $dialect];
        foreach (self::files($dialect) as $file) {
            $parts[] = basename($file) . ':' . (string) @filesize($file) . ':' . (string) @filemtime($file);
        }
        return hash('sha256', implode('|', $parts));
    }

    private static function stampPath(object $db, string $dialect): string
    {
        $cacheDir = defined('APPPATH') ? rtrim((string) APPPATH, '/\\') . DIRECTORY_SEPARATOR . 'cache' : sys_get_temp_dir();
        if (!is_dir($cacheDir)) @mkdir($cacheDir, 0775, true);
        if (!is_writable($cacheDir)) $cacheDir = sys_get_temp_dir();
        $dbKey = hash('sha256', implode('|', [
            $dialect,
            (string) ($db->hostname ?? ''),
            (string) ($db->database ?? ''),
            (string) ($db->dsn ?? ''),
            (string) ($db->subdriver ?? ''),
        ]));
        return rtrim($cacheDir, '/\\') . DIRECTORY_SEPARATOR . 'ai_workforce_schema_' . $dbKey . '.stamp.json';
    }

    private static function stampFresh(object $db, string $dialect): bool
    {
        $path = self::stampPath($db, $dialect);
        if (!is_file($path)) return false;
        $stamp = json_decode((string) @file_get_contents($path), true);
        if (!is_array($stamp)
            || ($stamp['version'] ?? null) !== self::STAMP_VERSION
            || ($stamp['dialect'] ?? null) !== $dialect
            || ($stamp['fingerprint'] ?? null) !== self::fingerprint($dialect)) {
            return false;
        }

        // A stamp only proves that a previous request ran the migration guard;
        // older guards could still stamp a database after CodeIgniter returned
        // false for an ALTER while db_debug was disabled. Verify the columns
        // used by the atomic daily claim before trusting the fast path.
        return self::hasDailyTicketColumns($db, $dialect);
    }

    private static function writeStamp(object $db, string $dialect): void
    {
        @file_put_contents(self::stampPath($db, $dialect), json_encode([
            'version' => self::STAMP_VERSION,
            'dialect' => $dialect,
            'fingerprint' => self::fingerprint($dialect),
            'written_at' => gmdate('c'),
        ], JSON_UNESCAPED_SLASHES));
    }

    public static function installCi(object $db): void
    {
        $dialect = self::dialect($db);
        $exec = function (string $sql) use ($db) {
            $db->query($sql);
        };
        self::applyFiles($exec, $dialect);
        self::upgrade(function (string $sql) use ($db) {
            try { $db->query($sql); } catch (\Throwable $e) { /* duplicate */ }
        }, $dialect);
        self::$done = true;
        if (self::hasExpectedTables($db, $dialect)
            && self::hasDailyTicketColumns($db, $dialect)) {
            self::writeStamp($db, $dialect);
        }
    }

    /**
     * Direct PDO install used by tools/install.php.
     *
     * @return list<string> missing table names (empty = success)
     */
    public static function installPdo(\PDO $pdo, string $driver): array
    {
        $dialect = self::dialect($driver);
        $exec = function (string $sql) use ($pdo) {
            $pdo->exec($sql);
        };
        self::applyFiles($exec, $dialect);
        self::upgrade(function (string $sql) use ($pdo) {
            try { $pdo->exec($sql); } catch (\Throwable $e) { /* duplicate */ }
        }, $dialect);
        if ($dialect === 'sqlite') {
            $rows = $pdo->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(\PDO::FETCH_COLUMN);
        } elseif ($dialect === 'pgsql') {
            $rows = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = current_schema()")->fetchAll(\PDO::FETCH_COLUMN);
        } else {
            $rows = $pdo->query('SHOW TABLES')->fetchAll(\PDO::FETCH_COLUMN);
        }
        $have = array_map('strval', is_array($rows) ? $rows : []);
        return array_values(array_diff(self::EXPECTED_TABLES, $have));
    }
}
