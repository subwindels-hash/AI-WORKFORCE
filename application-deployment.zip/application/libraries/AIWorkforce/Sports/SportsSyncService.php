<?php
namespace AIWorkforce\Sports;

use AIWorkforce\Backtest\Backtester;
use AIWorkforce\Persistence\AuditRepository;
use AIWorkforce\Persistence\SportsRepository;
use AIWorkforce\Sports\Providers\ProviderCircuitBreaker;
use AIWorkforce\Sports\Providers\ProviderException;
use AIWorkforce\Sports\Providers\SportsDataProvider;

/** Idempotent fixture ingestion. Provider exceptions and malformed records are counted, never hidden. */
class SportsSyncService
{
    private FormResolver $formResolver;
    private ?ProviderCircuitBreaker $breaker = null;

    public function __construct(private SportsRepository $repo, private AuditRepository $audit, private DataQualityEngine $quality, ?FormResolver $formResolver = null)
    {
        $this->formResolver = $formResolver ?? new FormResolver();
    }

    /**
     * Share the provider manager's circuit breaker so per-provider syncs
     * (cron fixture sweep, web "Sync now") respect an OPEN circuit too — a
     * quota-dead api-football is skipped here exactly as in withFallback().
     */
    public function setCircuitBreaker(ProviderCircuitBreaker $breaker): void
    {
        $this->breaker = $breaker;
    }

    /**
     * Pre-flight for every sync: circuit check, live health probe, persisted
     * observation. Throws a CLASSIFIED ProviderException (never a bare
     * "provider is not ONLINE") so the sync run's error list says
     * "DAILY_QUOTA_EXHAUSTED: daily quota used (100/100 on the Free plan)".
     */
    private function preflight(SportsDataProvider $provider, int $sourceId): array
    {
        $id = $provider->id();
        if ($this->breaker !== null) {
            $circuit = $this->breaker->state($id);
            if ($circuit['state'] === ProviderCircuitBreaker::OPEN) {
                $status = (string) ($circuit['reason'] ?? ProviderException::OFFLINE);
                $this->repo->saveHealth($sourceId, ['status' => $status, 'lastFailureAt' => $circuit['lastFailureAt'], 'lastSuccessAt' => $circuit['lastSuccessAt'], 'missingFields' => ['circuit' => 'OPEN', 'retryAt' => $circuit['retryAt']]]);
                throw new ProviderException('circuit open until ' . ($circuit['retryAt'] ?? '?') . ' (skipped, no request sent)' . ($circuit['detail'] ? ' — ' . $circuit['detail'] : ''), $status, null, ['retryAt' => $circuit['retryAt']]);
            }
        }
        $health = $provider->health();
        $status = (string) ($health['status'] ?? ProviderException::DATA_ERROR);
        $this->repo->saveHealth($sourceId, array_merge($health, ['status' => $status]));
        if ($status !== 'ONLINE') {
            $e = new ProviderException((string) ($health['detail'] ?? 'provider self-reported ' . $status), in_array($status, [ProviderException::DAILY_QUOTA_EXHAUSTED, ProviderException::RATE_LIMITED, ProviderException::AUTHENTICATION_ERROR, ProviderException::BAD_REQUEST, ProviderException::NOT_FOUND, ProviderException::TIMEOUT, ProviderException::OFFLINE, ProviderException::DEGRADED, ProviderException::DATA_ERROR], true) ? $status : ProviderException::OFFLINE, null, isset($health['retryAt']) ? ['retryAt' => $health['retryAt']] : []);
            $this->breaker?->recordFailure($id, $e);
            throw $e;
        }
        return $health;
    }

    /** Feed the sync outcome back to the breaker; format the error for the run log. */
    private function settle(SportsDataProvider $provider, ?\Throwable $e): string
    {
        if ($e === null) { $this->breaker?->recordSuccess($provider->id()); return ''; }
        if ($e instanceof ProviderException) {
            $this->breaker?->recordFailure($provider->id(), $e);
            return $e->status . ': ' . mb_substr($e->getMessage(), 0, 180);
        }
        return mb_substr($e->getMessage(), 0, 200);
    }

    /**
     * A provider that just COMPLETED a sync proved it is reachable — mark it
     * enabled so enabled-only consumers (dashboard widgets, provider lists)
     * reflect reality. New provider rows boot disabled; operators can still
     * switch a flaky feed off. Never breaks a completed sync.
     */
    private function markProviderReachable(int $sourceId): void
    {
        try { $this->repo->setProviderEnabled($sourceId, true); } catch (\Throwable $e) { /* enabling must never break a completed sync */ }
    }

    public function syncResults(SportsDataProvider $provider, string $fixtureExternalId, string $executionKey): array
    {
        $source=$this->repo->ensureProvider($provider->id(),$provider->id()); $run=['id'=>Backtester::uuid(),'providerId'=>(int)$source['id'],'jobType'=>'RESULTS','executionKey'=>$executionKey];
        if($this->repo->startSync($run)===null) return ['status'=>'DUPLICATE_SKIPPED','executionKey'=>$executionKey]; $processed=0;$errors=[];
        try { $health=$this->preflight($provider,(int)$source['id']); $match=$this->repo->findMatch((int)$source['id'],$fixtureExternalId); if(!$match) throw new \RuntimeException('fixture is not synchronized for this provider'); foreach($provider->results($fixtureExternalId) as $raw){$processed++; try{$this->repo->saveResult((int)$match['id'],(int)$source['id'],SportsResultNormalizer::normalize($raw,$provider->id()));}catch(\Throwable $e){$errors[]=$e->getMessage();}} $this->settle($provider,null); $result=['status'=>'COMPLETED','processed'=>$processed,'created'=>$processed-count($errors),'updated'=>0,'errors'=>$errors]; } catch(\Throwable $e){$result=['status'=>'FAILED','processed'=>$processed,'created'=>0,'updated'=>0,'errors'=>[$this->settle($provider,$e)]];}
        $this->repo->finishSync($run['id'],$result); if($result['status']==='COMPLETED')$this->markProviderReachable((int)$source['id']); $this->audit->emit($result['status']==='COMPLETED'?'SPORTS_RESULT_SYNC_COMPLETED':'SPORTS_RESULT_SYNC_FAILED','Sports result sync '.strtolower($result['status']),['provider'=>$provider->id(),'result'=>$result]); return array_merge(['runId'=>$run['id']],$result);
    }

    public function syncOdds(SportsDataProvider $provider, string $fixtureExternalId, string $executionKey): array
    {
        $source = $this->repo->ensureProvider($provider->id(), $provider->id());
        $run = ['id' => Backtester::uuid(), 'providerId' => (int) $source['id'], 'jobType' => 'ODDS', 'executionKey' => $executionKey];
        if ($this->repo->startSync($run) === null) return ['status' => 'DUPLICATE_SKIPPED', 'executionKey' => $executionKey];
        $processed = 0; $invalid = 0; $errors = [];
        try {
            $health = $this->preflight($provider, (int) $source['id']);
            $match = $this->repo->findMatch((int) $source['id'], $fixtureExternalId);
            if (!$match) throw new \RuntimeException('fixture is not synchronized for this provider');
            foreach ($provider->odds($fixtureExternalId) as $raw) {
                $processed++;
                try { $this->repo->saveOdds((int) $match['id'], (int) $source['id'], SportsDataNormalizer::odds($raw, $provider->id())); }
                catch (\Throwable $e) { $invalid++; $errors[] = mb_substr($e->getMessage(), 0, 200); }
            }
            if ($processed === 0) $errors[] = 'provider returned no odds; no odds-dependent ticket may be generated';
            $this->settle($provider, null);
            $result = ['status' => 'COMPLETED', 'processed' => $processed, 'created' => $processed - $invalid, 'updated' => 0, 'errors' => $errors];
        } catch (\Throwable $e) { $result = ['status' => 'FAILED', 'processed' => $processed, 'created' => 0, 'updated' => 0, 'errors' => [$this->settle($provider, $e)]]; }
        $this->repo->finishSync($run['id'], $result);
        if ($result['status'] === 'COMPLETED') $this->markProviderReachable((int) $source['id']);
        $this->audit->emit($result['status'] === 'COMPLETED' ? 'SPORTS_ODDS_SYNC_COMPLETED' : 'SPORTS_ODDS_SYNC_FAILED', 'Sports odds sync ' . strtolower($result['status']), ['provider' => $provider->id(), 'fixture' => $fixtureExternalId, 'runId' => $run['id'], 'result' => $result]);
        return array_merge(['runId' => $run['id']], $result);
    }

    /**
     * Bulk-sync a whole matchday (round) in ONE provider request: fixtures,
     * bookmaker odds and results together (SportMonks round endpoint).
     * Idempotent per execution key like the per-fixture sync jobs; one bad
     * fixture is counted, never hidden.
     *
     * $options: 'odds' (default true) persist the round's odds; 'results'
     * (default true) persist the round's results. Callers that only refresh
     * odds (e.g. the cron odds job) pass ['results' => false] so already
     * verified results are never re-written.
     */
    public function syncRound(SportsDataProvider $provider, string $roundExternalId, string $executionKey, array $options = []): array
    {
        $withOdds = (bool) ($options['odds'] ?? true);
        $withResults = (bool) ($options['results'] ?? true);
        $source = $this->repo->ensureProvider($provider->id(), $provider->id());
        $run = ['id' => Backtester::uuid(), 'providerId' => (int) $source['id'], 'jobType' => 'ROUND', 'executionKey' => $executionKey];
        if ($this->repo->startSync($run) === null) return ['status' => 'DUPLICATE_SKIPPED', 'executionKey' => $executionKey];
        $processed = 0; $created = 0; $updated = 0; $invalid = 0; $invalidOdds = 0; $invalidResults = 0; $errors = [];
        try {
            $health = $this->preflight($provider, (int) $source['id']);
            if (!method_exists($provider, 'round')) throw new \RuntimeException('provider does not support round sync (no round endpoint)');
            $round = $provider->round($roundExternalId);
            $oddsByFixture = [];
            if ($withOdds) {
                foreach (($round['odds'] ?? []) as $o) {
                    if (is_array($o) && !empty($o['fixtureId'])) $oddsByFixture[(string) $o['fixtureId']][] = $o;
                }
            }
            $resultsByFixture = [];
            if ($withResults) {
                foreach (($round['results'] ?? []) as $r) {
                    if (is_array($r) && isset($r['externalId'])) $resultsByFixture[(string) $r['externalId']] = $r;
                }
            }
            foreach (($round['fixtures'] ?? []) as $raw) {
                $processed++;
                try {
                    $match = SportsDataNormalizer::fixture($raw, $provider->id());
                    $existing = $this->repo->saveMatch((int) $source['id'], $match);
                    !empty($existing['created_at']) && $existing['created_at'] === $existing['updated_at'] ? $created++ : $updated++;
                    $assessment = $this->quality->assess($match, ['oddsAvailable' => $withOdds && isset($oddsByFixture[$match['externalId']]), 'recentFormAvailable' => !empty($match['context']['recentForm']), 'providerReliability' => (float) ($health['reliability'] ?? 0), 'dataAgeSeconds' => 0]);
                    $this->repo->saveQuality((int) $existing['id'], $assessment);
                    // Odds and result for this fixture come from the same round call.
                    // One malformed odds row or result rejects ITSELF — counted
                    // and named — instead of failing the whole fixture whose
                    // match row is already saved.
                    foreach (($oddsByFixture[$match['externalId']] ?? []) as $rawOdds) {
                        try {
                            $this->repo->saveOdds((int) $existing['id'], (int) $source['id'], SportsDataNormalizer::odds($rawOdds, $provider->id()));
                        } catch (\Throwable $e) { $invalidOdds++; $errors[] = 'odds rejected for fixture ' . $match['externalId'] . ': ' . mb_substr($e->getMessage(), 0, 160); }
                    }
                    $rawResult = $resultsByFixture[$match['externalId']] ?? null;
                    if (is_array($rawResult) && ($rawResult['homeScore'] !== null || $rawResult['awayScore'] !== null)) {
                        try {
                            $this->repo->saveResult((int) $existing['id'], (int) $source['id'], SportsResultNormalizer::normalize($rawResult, $provider->id()));
                        } catch (\Throwable $e) { $invalidResults++; $errors[] = 'result rejected for fixture ' . $match['externalId'] . ': ' . mb_substr($e->getMessage(), 0, 160); }
                    }
                } catch (\Throwable $e) { $invalid++; $errors[] = mb_substr($e->getMessage(), 0, 200); }
            }
            if ($processed === 0) $errors[] = 'round returned no fixtures; nothing synchronized';
            $this->settle($provider, null);
            $result = ['status' => 'COMPLETED', 'processed' => $processed, 'created' => $created, 'updated' => $updated, 'invalidOdds' => $invalidOdds, 'invalidResults' => $invalidResults, 'errors' => $errors];
        } catch (\Throwable $e) {
            $result = ['status' => 'FAILED', 'processed' => $processed, 'created' => 0, 'updated' => 0, 'errors' => [$this->settle($provider, $e)]];
        }
        $this->repo->finishSync($run['id'], $result);
        if ($result['status'] === 'COMPLETED') $this->markProviderReachable((int) $source['id']);
        $this->audit->emit($result['status'] === 'COMPLETED' ? 'SPORTS_ROUND_SYNC_COMPLETED' : 'SPORTS_ROUND_SYNC_FAILED', 'Sports round sync ' . strtolower($result['status']) . ' for round ' . $roundExternalId, ['provider' => $provider->id(), 'round' => $roundExternalId, 'runId' => $run['id'], 'result' => $result]);
        return array_merge(['runId' => $run['id']], $result);
    }

    /**
     * Live sweep: refresh every in-play fixture the provider reports (status,
     * minute, current goal score) in ONE live-endpoint request, and record a
     * SPORTS_GOAL_SCORED audit event the moment the provider's total goals is
     * higher than the last stored one — that event is what the console's live
     * board flashes as "GOAL".
     *
     * Detection rules (nothing is invented):
     *  - the FIRST observation of a live match emits nothing (no previous
     *    state to compare with — a board that already shows 1-0 is not a goal);
     *  - a higher total emits one event carrying the delta (the provider does
     *    not report individual goal minutes for a multi-goal jump);
     *  - a lower or equal total (correction, re-observation) updates the row
     *    silently. Scores only ever come from the provider payload.
     */
    public function syncLive(SportsDataProvider $provider, string $executionKey): array
    {
        $source = $this->repo->ensureProvider($provider->id(), $provider->id());
        $run = ['id' => Backtester::uuid(), 'providerId' => (int) $source['id'], 'jobType' => 'LIVE', 'executionKey' => $executionKey];
        if ($this->repo->startSync($run) === null) return ['status' => 'DUPLICATE_SKIPPED', 'executionKey' => $executionKey, 'goalEvents' => [], 'errors' => []];
        $processed = 0; $created = 0; $updated = 0; $invalid = 0; $errors = []; $goalEvents = [];
        try {
            $health = $this->preflight($provider, (int) $source['id']);
            if (!method_exists($provider, 'liveFixtures')) throw new \RuntimeException('provider does not support live fixtures (no live endpoint)');
            foreach ($provider->liveFixtures() as $raw) {
                $processed++;
                try {
                    $match = SportsDataNormalizer::fixture($raw, $provider->id());
                    $existing = $this->repo->findMatch((int) $source['id'], $match['externalId']);
                    $stored = $this->repo->saveMatch((int) $source['id'], $match);
                    !empty($stored['created_at']) && $stored['created_at'] === $stored['updated_at'] ? $created++ : $updated++;
                    $assessment = $this->quality->assess($match, [
                        'oddsAvailable' => $this->repo->latestOdds((int) $stored['id']) !== null,
                        'recentFormAvailable' => !empty($match['context']['recentForm']),
                        'providerReliability' => (float) ($health['reliability'] ?? 0),
                        'dataAgeSeconds' => 0,
                    ]);
                    $this->repo->saveQuality((int) $stored['id'], $assessment);
                    $goalEvents = array_merge($goalEvents, $this->recordGoalEvents($provider->id(), $existing, $match));
                } catch (\Throwable $e) { $invalid++; $errors[] = mb_substr($e->getMessage(), 0, 200); }
            }
            $this->settle($provider, null);
            $result = ['status' => 'COMPLETED', 'processed' => $processed, 'created' => $created, 'updated' => $updated, 'goalEvents' => $goalEvents, 'errors' => $errors];
        } catch (\Throwable $e) {
            $result = ['status' => 'FAILED', 'processed' => $processed, 'created' => 0, 'updated' => 0, 'goalEvents' => $goalEvents, 'errors' => [$this->settle($provider, $e)]];
        }
        $this->repo->finishSync($run['id'], $result);
        if ($result['status'] === 'COMPLETED') $this->markProviderReachable((int) $source['id']);
        $this->audit->emit($result['status'] === 'COMPLETED' ? 'SPORTS_LIVE_SYNC_COMPLETED' : 'SPORTS_LIVE_SYNC_FAILED', 'Sports live score sync ' . strtolower($result['status']), ['provider' => $provider->id(), 'runId' => $run['id'], 'goals' => count($goalEvents), 'result' => ['processed' => $processed, 'created' => $created, 'updated' => $updated, 'errors' => $errors]]);
        return array_merge(['runId' => $run['id']], $result);
    }

    /**
     * Compare the freshly normalized live state with the stored one and audit
     * one SPORTS_GOAL_SCORED event per match whose total goals increased.
     *
     * @param array|null $existing stored match row (payload may still be a JSON string depending on the repository backend)
     * @return list<array<string,mixed>> the recorded goal events
     */
    private function recordGoalEvents(string $providerId, ?array $existing, array $match): array
    {
        $new = is_array($match['live'] ?? null) ? $match['live'] : [];
        if (!isset($new['homeScore'], $new['awayScore'])) return [];    // provider stated no score
        if ($existing === null) return [];                              // first observation — nothing to compare
        // Same document, either shape: the repository may hand the stored
        // payload back decoded or as the raw JSON text of its column.
        $payload = SportsDataNormalizer::document($existing['payload'] ?? null);
        $old = is_array($payload['live'] ?? null) ? $payload['live'] : [];
        if (!isset($old['homeScore'], $old['awayScore'])) return [];    // no previous score — cannot call it a goal
        $newTotal = (int) $new['homeScore'] + (int) $new['awayScore'];
        $oldTotal = (int) $old['homeScore'] + (int) $old['awayScore'];
        if ($newTotal <= $oldTotal) return [];                          // unchanged or a provider correction
        $side = (int) $new['homeScore'] > (int) $old['homeScore'] ? 'home' : 'away';
        $event = [
            'type' => 'GOAL',
            'occurredAt' => gmdate('c'),
            'matchId' => (int) ($existing['id'] ?? 0),
            'provider' => $providerId,
            'externalId' => (string) $match['externalId'],
            'homeTeam' => $match['homeTeam'],
            'awayTeam' => $match['awayTeam'],
            'competition' => $match['competition'],
            'previous' => ['home' => (int) $old['homeScore'], 'away' => (int) $old['awayScore']],
            'score' => ['home' => (int) $new['homeScore'], 'away' => (int) $new['awayScore']],
            'delta' => $newTotal - $oldTotal,
            'side' => $side,
            'minute' => isset($new['minute']) ? (int) $new['minute'] : null,
        ];
        $this->audit->emit('SPORTS_GOAL_SCORED', sprintf('GOAL — %s %d-%d %s (%s, %s%s)',
            $match['homeTeam'], $event['score']['home'], $event['score']['away'], $match['awayTeam'],
            $match['competition'], $event['minute'] !== null ? $event['minute'] . "' " : '', $side === 'home' ? $match['homeTeam'] : $match['awayTeam']), $event);
        return [$event];
    }

    public function syncFixtures(SportsDataProvider $provider, array $query, string $executionKey): array
    {
        $source = $this->repo->ensureProvider($provider->id(), $provider->id());
        $run = ['id' => Backtester::uuid(), 'providerId' => (int) $source['id'], 'jobType' => 'FIXTURES', 'executionKey' => $executionKey];
        if ($this->repo->startSync($run) === null) return ['status' => 'DUPLICATE_SKIPPED', 'executionKey' => $executionKey];
        $created = 0; $updated = 0; $invalid = 0; $processed = 0; $errors = [];
        try {
            $health = $this->preflight($provider, (int) $source['id']);
            $rawFixtures = $provider->fixtures($query);
            // Enrich fixtures with recentForm context from team statistics
            $rawFixtures = $this->formResolver->enrich($provider, $rawFixtures);
            foreach ($rawFixtures as $raw) {
                $processed++;
                try {
                    $match = SportsDataNormalizer::fixture($raw, $provider->id());
                    $existing = $this->repo->saveMatch((int) $source['id'], $match);
                    // Repository upserts; source payload decides whether this was logically created/updated.
                    !empty($existing['created_at']) && $existing['created_at'] === $existing['updated_at'] ? $created++ : $updated++;
                    $assessment = $this->quality->assess($match, ['oddsAvailable' => false, 'recentFormAvailable' => !empty($match['context']['recentForm']), 'providerReliability' => (float) ($health['reliability'] ?? 0), 'dataAgeSeconds' => 0]);
                    $this->repo->saveQuality((int) $existing['id'], $assessment);
                } catch (\Throwable $e) { $invalid++; $errors[] = mb_substr($e->getMessage(), 0, 200); }
            }
            $this->settle($provider, null);
            $result = ['status' => 'COMPLETED', 'processed' => $processed, 'created' => $created, 'updated' => $updated, 'errors' => $errors];
        } catch (\Throwable $e) {
            $result = ['status' => 'FAILED', 'processed' => $processed, 'created' => $created, 'updated' => $updated, 'errors' => [$this->settle($provider, $e)]];
        }
        $this->repo->finishSync($run['id'], $result);
        if ($result['status'] === 'COMPLETED') $this->markProviderReachable((int) $source['id']);
        $this->audit->emit($result['status'] === 'COMPLETED' ? 'SPORTS_FIXTURE_SYNC_COMPLETED' : 'SPORTS_FIXTURE_SYNC_FAILED', 'Sports fixture sync ' . strtolower($result['status']), ['provider' => $provider->id(), 'runId' => $run['id'], 'result' => $result]);
        return array_merge(['runId' => $run['id']], $result);
    }
}
