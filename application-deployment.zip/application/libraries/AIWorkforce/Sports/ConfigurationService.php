<?php
namespace AIWorkforce\Sports;

use AIWorkforce\Persistence\AuditRepository;
use AIWorkforce\Persistence\SportsRepository;

/**
 * Ticket-engine configuration (spec §16/§34).
 *
 * Append-only, versioned: every change inserts a new configuration row with
 * a monotonically increasing version and an audit event carrying the acting
 * administrator, timestamp, the original values, the new values, and the
 * reason. Tickets always store the configuration version that produced them
 * so any historical decision can be reconstructed.
 *
 * AUTOMATED_EXECUTION is refused unless the operator explicitly passes
 * allowAutomatedExecution (spec §20): automated external execution stays
 * disabled by default and there is no external execution connector at all.
 */
class ConfigurationService
{
    public const PLATFORM_MODES = ['SANDBOX', 'PAPER', 'PRODUCTION'];
    public const ENGINE_MODES = ['VIEW_ONLY', 'AI_ANALYSIS', 'AI_TICKET_GENERATION', 'USER_APPROVAL_REQUIRED', 'AUTOMATED_EXECUTION'];
    public const RISK_LEVELS = ['CONSERVATIVE', 'MODERATE', 'AGGRESSIVE'];
    public const CORRELATION_LIMITS = ['LOW', 'MEDIUM'];
    public const VOID_POLICIES = ['RESTITUTE_ODDS', 'ALL_VOID_ONLY'];

    /**
     * The lowest confidence an operator may configure as the eligibility floor.
     *
     * A measured 25% read on verified data is a real signal and may be
     * considered; the engine reports it as 25% and ranks it accordingly. This
     * is a bound on what is CONFIGURABLE, not a promise about any prediction:
     * the shipped default is still 75 (see defaults()), confidence is never
     * inflated to clear a floor, and the data-quality gate is unchanged — a
     * fixture below the quality floor is still rejected outright whatever its
     * confidence happens to be.
     */
    public const MIN_CONFIDENCE_FLOOR = 25.0;

    public function __construct(private SportsRepository $repo, private AuditRepository $audit) {}

    /** Current active configuration (latest version), or a safe default when none exists yet. */
    public function active(): array
    {
        $row = $this->repo->activeConfiguration();
        if ($row === null) return self::defaults();
        // Layer the stored row OVER the defaults. Configuration is
        // append-only, so an active row may have been written by an older
        // app version before a column existed (the deployed row predating
        // require_calibration is the cautionary tale: the daily engine read
        // the missing key as "bootstrap not needed" at one site and as
        // "calibration enforced" at another — a hard lock-out no operator
        // chose). Stored values always win; defaults only fill absent keys.
        $row = array_merge(self::defaults(), $row);
        $row['module_enabled'] = (int) (bool) $row['module_enabled'];
        $row['ticket_engine_enabled'] = (int) (bool) $row['ticket_engine_enabled'];
        $row['system_timezone'] = DailyTicketDate::configuredTimezone((string) ($row['system_timezone'] ?? ''));
        $row['require_calibration'] = (int) (bool) $row['require_calibration'];
        $row['min_confidence'] = (float) $row['min_confidence'];
        $row['min_data_quality'] = (int) $row['min_data_quality'];
        // Kept as stored (JSON string or array); ConfidencePolicy normalises
        // it and falls back to the derived ladder when it is absent/invalid.
        $row['confidence_policy'] = $row['confidence_policy'] ?? null;
        $row['version'] = (int) $row['version'];
        $row['allowed_markets'] = $row['allowed_markets'] ?? [];
        $row['allowed_leagues'] = $row['allowed_leagues'] ?? [];
        return $row;
    }

    public static function defaults(): array
    {
        return [
            'version' => 0,
            'module_enabled' => 1,
            'ticket_engine_enabled' => 1,
            // The daily ticket date is this local calendar date; fixture and
            // odds timestamps remain UTC. Can also be supplied at deployment
            // time through WINDELS_SYSTEM_TIMEZONE / APP_TIMEZONE.
            'system_timezone' => DailyTicketDate::configuredTimezone(),
            'platform_mode' => 'SANDBOX',
            'engine_mode' => 'USER_APPROVAL_REQUIRED',
            'target_odds_min' => 5.0,
            'target_odds_max' => 8.0,
            'max_selections' => 5,
            'risk_level' => 'CONSERVATIVE',
            // Qualified-ticket policy: only strong, well-evidenced predictions
            // may enter a daily ticket — 75%+ WINDELS confidence, data quality
            // 80+, LOW correlation between legs. Anything weaker is rejected
            // and the day honestly reports NO QUALIFIED TICKET instead of a
            // forced combination. Operators can still lower these floors
            // explicitly (append-only, audited); the validation range below
            // only rules out self-contradictory gates.
            'min_confidence' => 75.0,
            'min_expected_value' => 0.02,
            'max_correlation' => 'LOW',
            'min_data_quality' => 80,
            // Adaptive confidence policy (requirements #1/#8). NULL means the
            // tiers are DERIVED from the two floors above: with the stock
            // 75 / 80 that is data quality >=85 → 75% confidence required,
            // 75-84 → 70%, 65-74 → 65% and safer markets only, <65 → rejected.
            // Set it explicitly to author the tiers directly; nothing in the
            // engine hard-codes a threshold.
            'confidence_policy' => null,
            'min_liquidity' => null,
            // Every market the model can price AND settle (requirement #5).
            // Draw No Bet is included: it is fully supported end to end, and
            // leaving it out would have the engine generate predictions the
            // configuration then discards as OUTSIDE_CONFIGURATION.
            'allowed_markets' => ['MATCH_RESULT', 'TOTAL_GOALS', 'BTTS', 'DOUBLE_CHANCE', 'DRAW_NO_BET'],
            'allowed_leagues' => [],
            'max_exposure' => 100.0,
            'stake_amount' => 10.0,
            'void_policy' => 'RESTITUTE_ODDS',
            'require_calibration' => 1,
            'updated_by' => 'system',
            'reason' => 'built-in defaults',
        ];
    }

    /**
     * Validate a patch and persist it as the next configuration version.
     * Returns ['ok' => bool, 'reason' => string, 'configuration' => array].
     */
    public function update(array $patch, string $actor, string $reason = '', bool $allowAutomatedExecution = false): array
    {
        $base = $this->active();
        $next = array_merge($base, array_intersect_key($patch, array_flip([
            'module_enabled', 'ticket_engine_enabled', 'system_timezone', 'platform_mode', 'engine_mode',
            'target_odds_min', 'target_odds_max', 'max_selections', 'risk_level',
            'min_confidence', 'min_expected_value', 'max_correlation', 'min_data_quality',
            'confidence_policy',
            'min_liquidity', 'allowed_markets', 'allowed_leagues', 'max_exposure',
            'stake_amount', 'void_policy', 'require_calibration',
        ])));

        $error = $this->validate($next, $allowAutomatedExecution);
        if ($error !== null) return ['ok' => false, 'reason' => $error, 'configuration' => null];

        $present = fn($v) => $this->presentable($v);
        $previous = array_map($present, $base);
        $row = [
            'version' => (int) $base['version'] + 1,
            'module_enabled' => (int) (bool) $next['module_enabled'],
            'ticket_engine_enabled' => (int) (bool) $next['ticket_engine_enabled'],
            'system_timezone' => DailyTicketDate::configuredTimezone((string) $next['system_timezone']),
            'platform_mode' => (string) $next['platform_mode'],
            'engine_mode' => (string) $next['engine_mode'],
            'target_odds_min' => (float) $next['target_odds_min'],
            'target_odds_max' => (float) $next['target_odds_max'],
            'max_selections' => (int) $next['max_selections'],
            'risk_level' => (string) $next['risk_level'],
            'min_confidence' => (float) $next['min_confidence'],
            'min_expected_value' => (float) $next['min_expected_value'],
            'max_correlation' => (string) $next['max_correlation'],
            'min_data_quality' => (int) $next['min_data_quality'],
            // Adaptive confidence tiers. NULL keeps the derived ladder, so a
            // configuration that never mentions the policy behaves exactly as
            // its two floors describe (requirements #1/#8).
            'confidence_policy' => self::encodePolicy($next['confidence_policy'] ?? null),
            'min_liquidity' => $next['min_liquidity'] === null ? null : (float) $next['min_liquidity'],
            'allowed_markets' => json_encode(array_values((array) $next['allowed_markets'])),
            'allowed_leagues' => json_encode(array_values((array) $next['allowed_leagues'])),
            'max_exposure' => (float) $next['max_exposure'],
            'stake_amount' => (float) $next['stake_amount'],
            'void_policy' => (string) $next['void_policy'],
            'require_calibration' => (int) (bool) $next['require_calibration'],
            'updated_by' => $actor,
            'reason' => mb_substr($reason, 0, 500),
            'created_at' => gmdate('c'),
        ];
        $id = $this->repo->saveConfiguration($row);
        $stored = $this->repo->findConfiguration($id);
        $this->audit->emit('SPORTS_CONFIGURATION_UPDATED', 'Sports ticket-engine configuration updated to v' . $row['version'], [
            'version' => $row['version'], 'changed' => array_diff_assoc(array_map($present, $stored), $previous),
            'previous' => $previous, 'new' => array_map($present, $stored), 'reason' => $row['reason'],
        ], $actor);
        return ['ok' => true, 'reason' => 'configuration saved', 'configuration' => $stored];
    }

    /** Store an explicit policy as canonical JSON; null when none is set. */
    private static function encodePolicy($policy): ?string
    {
        if ($policy === null || $policy === '' || $policy === []) return null;
        $normalized = ConfidencePolicy::normalizePolicy($policy);
        return $normalized === null ? null : json_encode($normalized);
    }

    private function presentable($v)
    {
        if (is_string($v) && $v !== '' && (str_starts_with($v, '[') || str_starts_with($v, '{'))) return json_decode($v, true);
        return $v;
    }

    /** @return string|null error message, or null when valid */
    private function validate(array $c, bool $allowAutomatedExecution): ?string
    {
        try {
            $timezone = trim((string) ($c['system_timezone'] ?? ''));
            if ($timezone === '') return 'system_timezone is required';
            new \DateTimeZone($timezone);
        } catch (\Throwable $e) {
            return 'system_timezone must be a valid IANA timezone (for example UTC, Europe/London or Africa/Johannesburg)';
        }
        if (!in_array($c['platform_mode'], self::PLATFORM_MODES, true)) return 'platform_mode must be one of ' . implode(', ', self::PLATFORM_MODES);
        if (!in_array($c['engine_mode'], self::ENGINE_MODES, true)) return 'engine_mode must be one of ' . implode(', ', self::ENGINE_MODES);
        if ($c['engine_mode'] === 'AUTOMATED_EXECUTION' && !$allowAutomatedExecution) {
            return 'AUTOMATED_EXECUTION requires explicit authorization (allowAutomatedExecution) and remains disabled in this deployment';
        }
        if (!in_array($c['risk_level'], self::RISK_LEVELS, true)) return 'risk_level must be one of ' . implode(', ', self::RISK_LEVELS);
        if (!in_array($c['max_correlation'], self::CORRELATION_LIMITS, true)) return 'max_correlation must be LOW or MEDIUM';
        if (!in_array($c['void_policy'], self::VOID_POLICIES, true)) return 'void_policy must be one of ' . implode(', ', self::VOID_POLICIES);
        $min = (float) $c['target_odds_min']; $max = (float) $c['target_odds_max'];
        if ($min <= 1.0 || $max <= $min) return 'target odds range must satisfy 1.0 < min <= max';
        $maxSel = (int) $c['max_selections'];
        if ($maxSel < 1 || $maxSel > 12) return 'max_selections must be within [1, 12]';
        // The configurable floor is 25, not 30: a legitimately measured 25%
        // read on verified data is a usable signal and an operator is allowed
        // to admit it. This only widens what an operator MAY configure — the
        // shipped default remains 75 (ConfigurationService::defaults()), and
        // the adaptive ladder still derives from whatever is configured, so
        // nothing is loosened unless an administrator explicitly lowers it.
        // Confidence is never inflated to clear a floor; see ConfidencePolicy.
        $conf = (float) $c['min_confidence'];
        if ($conf < self::MIN_CONFIDENCE_FLOOR || $conf > 100) {
            return 'min_confidence must be within [' . (int) self::MIN_CONFIDENCE_FLOOR . ', 100]';
        }
        if ((float) $c['min_expected_value'] < 0) return 'min_expected_value must be >= 0';
        $dq = (int) $c['min_data_quality'];
        if ($dq < 50 || $dq > 100) return 'min_data_quality must be within [50, 100]';
        // An explicit adaptive policy must be readable, or the engine would
        // silently fall back to the derived ladder and the operator would
        // believe tiers are in force that are not.
        $policy = $c['confidence_policy'] ?? null;
        if ($policy !== null && $policy !== '' && $policy !== []) {
            if (ConfidencePolicy::normalizePolicy($policy) === null) {
                return 'confidence_policy must be a list of tiers, each with numeric minDataQuality and minConfidence within [0, 100]';
            }
        }
        if ((float) $c['max_exposure'] <= 0) return 'max_exposure must be > 0';
        if ((float) $c['stake_amount'] <= 0) return 'stake_amount must be > 0';
        if ((float) $c['stake_amount'] > (float) $c['max_exposure']) return 'stake_amount cannot exceed max_exposure';
        if ($c['min_liquidity'] !== null && (float) $c['min_liquidity'] < 0) return 'min_liquidity must be >= 0';
        foreach (['allowed_markets', 'allowed_leagues'] as $listKey) {
            $list = $c[$listKey];
            if (!is_array($list)) return "{$listKey} must be an array";
            foreach ($list as $item) if (!is_string($item) || trim($item) === '') return "{$listKey} entries must be non-empty strings";
        }
        return null;
    }
}
