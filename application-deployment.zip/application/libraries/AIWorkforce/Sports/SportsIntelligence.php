<?php
namespace AIWorkforce\Sports;

use AIWorkforce\Notifications\Notifier;
use AIWorkforce\Persistence\AuditRepository;
use AIWorkforce\Persistence\SportsRepository;
use AIWorkforce\Sports\Providers\ApiFootballProvider;
use AIWorkforce\Sports\Providers\HttpSportsProvider;
use AIWorkforce\Sports\Providers\ProviderException;
use AIWorkforce\Sports\Providers\SandboxSportsProvider;
use AIWorkforce\Sports\Providers\SportMonksProvider;
use AIWorkforce\Sports\Providers\SportsProviderManager;
use AIWorkforce\Sports\Providers\TheSportsDbProvider;

/**
 * WINDELS Sports Intelligence — domain service container (spec §2/§43).
 *
 * Boots from the environment:
 *  - WINDELS_SPORTS_ENABLED=1      module switch
 *  - WINDELS_SPORTS_MODE           SANDBOX | PAPER | PRODUCTION
 *  - WINDELS_SPORTS_SANDBOX=1      explicitly enables the labeled simulation
 *                                  provider (SANDBOX mode only)
 *  - WINDELS_SPORTS_HTTP_{ID,BASE_URL,TOKEN,TIMEOUT}  real REST provider
 *
 * With no provider the module reports DISABLED_NO_PROVIDER and never creates
 * fixtures, odds, predictions, or tickets.
 */
class SportsIntelligence
{
    public readonly SportsProviderManager $providers;
    public readonly DataQualityEngine $quality;
    public readonly OddsFreshnessEngine $oddsFreshness;
    public readonly MatchIntelligenceEngine $matchIntelligence;
    public readonly FeatureEngineeringEngine $features;
    public readonly PredictionEngine $predictions;
    public readonly ValueEngine $value;
    public readonly RiskEngine $risk;
    public readonly CorrelationEngine $correlation;
    public readonly ConfidenceEngine $confidence;
    public readonly CalibrationEngine $calibration;
    public readonly TicketOptimizer $tickets;
    public readonly DecisionRecorder $decisions;
    public readonly TicketGovernance $governance;
    public readonly ResultVerificationEngine $results;
    public readonly TicketSettlementService $settlement;
    public readonly PersistedResultVerifier $resultVerifier;
    public readonly PerformanceAnalytics $performance;
    public readonly SportsSyncService $sync;
    public readonly LiveScoreService $liveScores;
    public readonly ConfigurationService $configuration;
    public readonly PredictionPipeline $pipeline;
    public readonly DailyTicketService $dailyTickets;
    public readonly ProviderHealthMonitor $providerHealth;
    public readonly ModelPerformanceService $modelPerformance;
    public readonly ModelDriftMonitor $driftMonitor;
    public readonly SportsBacktester $backtester;
    public readonly FormResolver $formResolver;

    public function __construct(
        private SportsRepository $repository,
        AuditRepository $audit,
        ?Notifier $notifications = null,
        private ?object $providerDb = null
    )
    {
        $this->providers = new SportsProviderManager();
        $this->quality = new DataQualityEngine();
        $this->oddsFreshness = new OddsFreshnessEngine();
        $this->matchIntelligence = new MatchIntelligenceEngine($this->oddsFreshness);
        $this->features = new FeatureEngineeringEngine();
        $this->predictions = new PredictionEngine();
        $this->value = new ValueEngine();
        $this->risk = new RiskEngine();
        $this->correlation = new CorrelationEngine();
        $this->confidence = new ConfidenceEngine();
        $this->calibration = new CalibrationEngine();

        $this->decisions = new DecisionRecorder($repository, $audit);
        $this->governance = new TicketGovernance($repository, $audit, $this->correlation);
        $this->results = new ResultVerificationEngine();
        $this->settlement = new TicketSettlementService($repository, $this->results, $audit);
        $this->resultVerifier = new PersistedResultVerifier($repository, $audit);
        $this->performance = new PerformanceAnalytics();
        $this->formResolver = new FormResolver();
        $this->sync = new SportsSyncService($repository, $audit, $this->quality, $this->formResolver);
        // Live goal scores: one throttled refresh (board poll + cron funnel
        // here) so a goal lands on the console automatically right after the
        // provider reports it, without per-viewer provider traffic.
        $this->liveScores = new LiveScoreService($repository, $audit, $this->sync, $this->providers);
        $this->configuration = new ConfigurationService($repository, $audit);
        $this->pipeline = new PredictionPipeline($this->matchIntelligence, $this->features, $this->predictions, $this->value, $this->risk, $this->correlation, $this->confidence);
        $this->dailyTickets = new DailyTicketService($repository, $audit, $this->providers, $this->configuration, $this->quality, $this->pipeline, new TicketOptimizer($this->correlation), $this->governance, $this->decisions, $this->formResolver);
        $this->providerHealth = new ProviderHealthMonitor();
        $this->modelPerformance = new ModelPerformanceService($repository, $audit);
        $this->driftMonitor = new ModelDriftMonitor($repository, $audit, $notifications);
        $this->backtester = new SportsBacktester($repository, $audit, $this->pipeline, $this->quality, $this->modelPerformance);

        $this->registerProviders();
        $this->hydrateCircuits();
        $this->sync->setCircuitBreaker($this->providers->breaker());
        $this->providers->setHealthObserver(function (object $provider, string $operation, ?\Throwable $error, array $payload) use ($repository, $audit) {
            try {
                $source = $repository->ensureProvider($provider->id(), $provider->id());
                // A skipped provider (circuit OPEN) is recorded WITHOUT calling
                // it — probing a quota-dead feed on every observation is the
                // exact hammering the breaker exists to stop.
                if (isset($payload['skipped']) && isset($payload['circuit'])) {
                    $repository->saveHealth((int) $source['id'], [
                        'status' => (string) $payload['skipped'],
                        'lastFailureAt' => $payload['circuit']['lastFailureAt'] ?? null,
                        'lastSuccessAt' => $payload['circuit']['lastSuccessAt'] ?? null,
                        'missingFields' => ['circuit' => $payload['circuit']['state'] ?? 'OPEN', 'retryAt' => $payload['circuit']['retryAt'] ?? null, 'skipped' => $operation],
                    ]);
                    return;
                }
                $health = $error instanceof ProviderException && isset($payload['skipped'])
                    ? ['status' => $error->status, 'detail' => $error->getMessage()]   // health() was just called by the manager; do not call it twice
                    : $provider->health();
                if ($error instanceof ProviderException) $health['status'] = $error->status;
                $health['lastFailureAt'] = $error !== null ? gmdate('c') : ($health['lastFailureAt'] ?? null);
                $health['lastSuccessAt'] = $error === null ? gmdate('c') : ($health['lastSuccessAt'] ?? null);
                $health['lastOddsSyncAt'] = $operation === 'odds' && $error === null ? gmdate('c') : ($health['lastOddsSyncAt'] ?? null);
                $health['lastFixtureSyncAt'] = $operation === 'fixtures' && $error === null ? gmdate('c') : ($health['lastFixtureSyncAt'] ?? null);
                $health['lastResultSyncAt'] = $operation === 'results' && $error === null ? gmdate('c') : ($health['lastResultSyncAt'] ?? null);
                if ($error instanceof ProviderException) {
                    // Structured, secret-free diagnostic: endpoint / method /
                    // query / HTTP status / body snippet — what an operator
                    // needs to fix a 400 or 404 without reading raw logs.
                    $d = $error->details;
                    $health['missingFields'] = array_filter([
                        'operation' => $operation,
                        'endpoint' => $d['endpoint'] ?? null,
                        'method' => $d['method'] ?? null,
                        'query' => $d['query'] ?? null,
                        'httpStatus' => $d['httpStatus'] ?? null,
                        'bodySnippet' => $d['bodySnippet'] ?? null,
                        'retryAt' => $d['retryAt'] ?? null,
                        'message' => mb_substr($error->getMessage(), 0, 300),
                    ], fn($v) => $v !== null && $v !== '' && $v !== []);
                }
                $repository->saveHealth((int) $source['id'], $health);
                if ($error !== null) {
                    $status = $error instanceof ProviderException ? $error->status : 'DATA_ERROR';
                    $audit->emit('SPORTS_PROVIDER_FAILURE', "Provider {$provider->id()} failed ({$status}) on {$operation}", [
                        'provider' => $provider->id(), 'operation' => $operation, 'status' => $status,
                        'message' => mb_substr($error->getMessage(), 0, 300),
                        'diagnostic' => $error instanceof ProviderException ? array_intersect_key($error->details, array_flip(['endpoint', 'method', 'query', 'httpStatus', 'bodySnippet', 'retryAt', 'errorField'])) : [],
                    ]);
                }
            } catch (\Throwable $e) { /* health recording must never break the pipeline */ }
        });
    }

    /**
     * Re-open circuits from the persisted health history so a new PHP
     * process (cron at 09:05, a page view at 09:06) remembers that
     * api-football's quota died at 08:40 and does not spend the morning
     * re-discovering it one request at a time.
     */
    private function hydrateCircuits(): void
    {
        try {
            $latest = [];
            foreach ($this->repository->listProviders() as $source) {
                $code = (string) ($source['provider_code'] ?? '');
                if ($code === '' || $this->providers->provider($code) === null) continue;
                $row = $this->repository->latestHealth((int) $source['id']);
                if ($row !== null) $latest[$code] = $row;
            }
            if ($latest !== []) $this->providers->breaker()->hydrate($latest);
        } catch (\Throwable $e) { /* a missing table on first boot must not break the module */ }
    }

    /** Register providers from environment configuration only — no secrets in code. */
    private function registerProviders(): void
    {
        // First-class vendor adapters. Each is optional and only registered when
        // its server-side key is present; this makes fallback and health status
        // work consistently across all three vendors.
        // api-football resolves through ApiProviders::footballCredential() so
        // both API_FOOTBALL_KEY (documented primary) and the legacy
        // WINDELS_API_FOOTBALL_KEY alias connect — the variable names live in
        // exactly one place.
        $football = \AIWorkforce\ApiProviders::footballCredential();
        $vendors = [
            ['api-football', $football['key'], $football['baseUrl'], 'api-football'],
            ['thesportsdb', 'WINDELS_THESPORTSDB_KEY', 'https://www.thesportsdb.com/api/v1/json', 'thesportsdb'],
            ['sportmonks', 'WINDELS_SPORTMONKS_TOKEN', 'https://api.sportmonks.com/v3/football', 'sportmonks'],
        ];
        foreach ($vendors as [$id, $keyOrName, $defaultBase, $kind]) {
            // Named-variable vendors resolve through getenv(); api-football's
            // credential was already resolved above (empty key = not set).
            $key = $kind === 'api-football'
                ? $keyOrName
                : ((($value = getenv($keyOrName)) && is_string($value) && trim($value) !== '') ? trim($value) : '');
            if ($key !== '') {
                // api-football: $defaultBase is the resolved API_FOOTBALL_BASE_URL
                // (or the canonical v3 host); the other vendors keep their
                // per-vendor WINDELS_*_BASE_URL override.
                $base = $kind === 'api-football'
                    ? $defaultBase
                    : (string)(getenv('WINDELS_'.strtoupper(str_replace('-', '_', $id)).'_BASE_URL') ?: $defaultBase);
                $timeout = (int)(getenv('WINDELS_SPORTS_HTTP_TIMEOUT') ?: 10);
                // Register the native adapter directly (not the legacy
                // FootballApiProvider wrapper): capability checks
                // (method_exists/instanceof for round sync, team statistics,
                // standings, top players) must see the real class, otherwise
                // env-configured providers silently lose form enrichment,
                // round sync and the smoke-test layers.
                $native = match ($kind) {
                    'api-football' => new ApiFootballProvider($key, $base, $timeout),
                    'thesportsdb' => new TheSportsDbProvider($key, $base, $timeout),
                    'sportmonks' => new SportMonksProvider($key, $base, $timeout),
                };
                $this->providers->register($native);
            }
        }
        // Also discover native providers from the central ApiProviders store
        // (Admin → API). These can coexist with or supplement env-based keys.
        $this->registerFromStore();
        if ($this->mode() === 'SANDBOX' && getenv('WINDELS_SPORTS_SANDBOX') === '1') {
            $this->providers->register(new SandboxSportsProvider());
        }
        $baseUrl = getenv('WINDELS_SPORTS_HTTP_BASE_URL');
        if (is_string($baseUrl) && $baseUrl !== '' && filter_var($baseUrl, FILTER_VALIDATE_URL)) {
            $id = (string) (getenv('WINDELS_SPORTS_HTTP_ID') ?: 'http-provider');
            $this->providers->register(new HttpSportsProvider(
                $id,
                rtrim($baseUrl, '/'),
                (string) (getenv('WINDELS_SPORTS_HTTP_TOKEN') ?: ''),
                (int) (getenv('WINDELS_SPORTS_HTTP_TIMEOUT') ?: 10)
            ));
        }
        $managed = \AIWorkforce\ApiProviders::resolve('sports');
        if (is_array($managed) && !empty($managed['base_url']) && filter_var($managed['base_url'], FILTER_VALIDATE_URL)) {
            $driver = $managed['driver'] ?? '';
            // Skip native drivers here — they are registered via registerFromStore()
            if (!in_array($driver, ['api_football', 'thesportsdb', 'sportmonks'], true)) {
                $this->providers->register(new HttpSportsProvider(
                    'managed-sports-' . (int) ($managed['id'] ?? 0),
                    rtrim((string) $managed['base_url'], '/'),
                    (string) ($managed['secrets']['token'] ?? $managed['secrets']['api_key'] ?? ''),
                    (int) ($managed['extra']['timeout'] ?? 10)
                ));
            }
        }
    }

    /**
     * Discover and register native sports providers from the central
     * ApiProviders store (Admin → API). This allows operators to manage
     * provider credentials through the dashboard rather than environment files.
     */
    private function registerFromStore(): void
    {
        // ApiProviders::chain() requires the server-side database handle to
        // decrypt credentials. Passing only the service name made this call
        // throw on every request, so credentials saved in Admin → API were
        // invisible to Sports Intelligence and multiplier enrichment.
        $db = $this->providerDb;
        if (!$db) {
            // Keep compatibility with direct instantiation outside Platform.
            $ci = function_exists('get_instance') ? get_instance() : null;
            $db = ($ci && isset($ci->AIWorkforce_model)) ? $ci->AIWorkforce_model->db : null;
        }
        if (!$db) return;

        try {
            $chain = \AIWorkforce\ApiProviders::chain($db, 'sports');
        } catch (\Throwable $e) { return; }
        foreach ($chain as $cfg) {
            $driver = $cfg['driver'] ?? '';
            $id = (int) ($cfg['id'] ?? 0);
            $timeout = (int) ($cfg['extra']['timeout'] ?? 10);
            $secrets = $cfg['secrets'] ?? [];
            $key = $secrets['api_key'] ?? $secrets['token'] ?? '';
            if ($key === '') continue;
            try {
                if ($driver === 'api_football') {
                    $base = $cfg['base_url'] ?: 'https://v3.football.api-sports.io';
                    $this->providers->register(new ApiFootballProvider(
                        $key, rtrim($base, '/'), $timeout
                    ));
                } elseif ($driver === 'thesportsdb') {
                    $base = $cfg['base_url'] ?: 'https://www.thesportsdb.com/api/v1/json';
                    $this->providers->register(new TheSportsDbProvider(
                        $key, rtrim($base, '/'), $timeout
                    ));
                } elseif ($driver === 'sportmonks') {
                    $base = $cfg['base_url'] ?: 'https://api.sportmonks.com/v3/football';
                    $this->providers->register(new SportMonksProvider(
                        $key, rtrim($base, '/'), $timeout
                    ));
                }
            } catch (\Throwable $e) { /* skip invalid store entries silently */ }
        }
    }

    public function mode(): string
    {
        $mode = (string) (getenv('WINDELS_SPORTS_MODE') ?: 'SANDBOX');
        return in_array($mode, ConfigurationService::PLATFORM_MODES, true) ? $mode : 'SANDBOX';
    }

    public function performanceReport(array $filter = []): array
    {
        $tickets = $this->repository->listTickets($filter);
        $selections = $this->repository->settledSelections($filter);
        $outcomes = $this->repository->predictionOutcomes(empty($filter['modelVersionId']) ? null : (int) $filter['modelVersionId']);
        $since = $filter['from'] ?? null;
        if ($since) {
            $selections = array_values(array_filter($selections, fn($s) => ($s['ticket_created_at'] ?? $s['created_at'] ?? '') >= $since));
            $outcomes = array_values(array_filter($outcomes, fn($o) => ($o['created_at'] ?? '') >= $since));
        }
        $report = $this->performance->report($tickets, $selections, $outcomes, ['mode' => $this->mode(), 'totalPredictions' => count($this->repository->listPredictions($filter, 1000))]);
        // Tickets still awaiting settlement in this window: what the console's
        // measured-results panel explains itself with when nothing is settled
        // yet (and what its Settle-all action targets). Counted from the same
        // window-scoped ticket list the report itself used.
        $pendingTickets = count(array_filter($tickets, static fn(array $t): bool => ($t['settlement_status'] ?? $t['status'] ?? '') === 'PENDING'));
        return array_merge($report, ['pendingTickets' => $pendingTickets, 'filter' => $filter]);
    }

    /**
     * Top players for a league + season from a native provider that supports it
     * (api-football /players/top* — scorers, assists, yellow cards, red cards).
     *
     * @param string|null $providerId explicit provider id ('api-football'), or
     *        null to walk the configured providers (health-aware fallback chain)
     *        and use the first one with a topPlayers() method
     * @throws \InvalidArgumentException when no configured provider can serve it
     * @throws ProviderException upstream failure from the selected provider
     */
    public function topPlayers(?string $providerId, string $leagueId, string $season, string $type): array
    {
        if ($providerId !== null) {
            $provider = $this->providers->provider($providerId);
            if (!$provider) throw new \InvalidArgumentException('provider not registered: ' . $providerId);
            if (!method_exists($provider, 'topPlayers')) throw new \InvalidArgumentException('provider does not support top players: ' . $providerId);
            return ['provider' => $provider->id()] + $provider->topPlayers($leagueId, $season, $type);
        }
        $attempt = $this->providers->withFallback('topPlayers', function ($p) use ($leagueId, $season, $type) {
            if (!method_exists($p, 'topPlayers')) throw new ProviderException('top players not supported', ProviderException::DATA_ERROR);
            return $p->topPlayers($leagueId, $season, $type);
        });
        if (empty($attempt['ok'])) {
            $failed = implode(', ', array_keys($attempt['failures'] ?? [])) ?: 'none configured';
            throw new \InvalidArgumentException("no configured provider can serve top players ({$failed})");
        }
        return ['provider' => $attempt['provider']] + $attempt['result'];
    }

    public function status(): array
    {
        $providers = [];
        foreach ($this->repository->listProviders() as $p) {
            $health = $this->providerHealth->assess($p, $this->repository->listHealth((int) $p['id'], 20), $this->repository->listJobRuns(null, 50));
            // Strip provider identity — users see Feed N, not provider names/codes/URLs.
            $providers[] = [
                'id' => (int) ($p['id'] ?? 0),
                'derivedStatus' => $health['status'],
                'reliability' => $health['reliability'],
                'detail' => $health['detail'],
            ];
        }
        $readiness = $this->providers->readiness();
        $liveHealth = $this->providers->health();
        $message = match (true) {
            !$this->providers->configured() => 'This feature is temporarily unavailable. Please try again later.',
            $readiness['operational'] === 0 => 'All configured sports-data providers are unavailable — the prediction engine is BLOCKED until at least one recovers.',
            default => sprintf('%d/%d sports data provider(s) operational', $readiness['operational'], $readiness['total']),
        };
        return [
            'module' => 'WINDELS Sports Intelligence',
            'enabled' => getenv('WINDELS_SPORTS_ENABLED') === '1',
            'mode' => $this->mode(),
            'isDemoData' => $this->mode() === 'SANDBOX',
            'providersConfigured' => $this->providers->configured(),
            'providers' => array_values($providers),
            'liveHealth' => $liveHealth,
            // Operational count + engine readiness: READY when ≥1 provider can
            // serve fixtures, BLOCKED when 0/N can (quota, 400, 404, offline).
            'readiness' => $readiness,
            'ticketEngine' => $this->providers->configured() ? $this->configuration->active()['engine_mode'] : 'DISABLED_NO_PROVIDER',
            // Why there is no feed and what to do about it. DISABLED_NO_PROVIDER
            // is honest but not actionable on its own; this block names the
            // exact next step (never a credential value).
            'providerSetup' => ProviderSetupAdvisor::diagnose($this->providers, $readiness, null, $this->credentialStoreHasSports()),
            'predictionEngine' => $readiness['engine'],
            'configuration' => $this->configuration->active(),
            'message' => $message,
        ];
    }

    /** Whether Admin → API holds a sports credential (null when unknowable here). */
    private function credentialStoreHasSports(): ?bool
    {
        $db = $this->providerDb;
        if (!$db) {
            $ci = function_exists('get_instance') ? get_instance() : null;
            $db = ($ci && isset($ci->AIWorkforce_model)) ? $ci->AIWorkforce_model->db : null;
        }
        if (!$db) return null;
        try { return \AIWorkforce\ApiProviders::chain($db, 'sports') !== []; }
        catch (\Throwable $e) { return null; }
    }

    /**
     * The configured-local day a dashboard call reports. A day that is not a
     * real calendar date is never rolled into a neighbour (2026-02-30 must not
     * become a March day): it falls back to today in the configured timezone.
     */
    private static function resolveDay(?string $date, string $timezone = 'UTC'): string
    {
        try { return DailyTicketDate::normalize($date, $timezone); }
        catch (\Throwable $e) { return DailyTicketDate::today($timezone); }
    }

    /** Metric keys printed in the /sports generation-run sidebar. */
    private const DASHBOARD_RUN_METRIC_KEYS = [
        'eligibleFixtures',
        'fixturesEvaluated',
        'predictionsGenerated',
        'fixturesWithFreshOdds',
        'fixturesRejectedStaleOdds',
        'correlationQualifiedCandidates',
        'finalQualifiedCandidates',
    ];

    /** @return array<string,int|null> */
    private static function emptyDashboardRunMetrics(): array
    {
        return array_fill_keys(self::DASHBOARD_RUN_METRIC_KEYS, null);
    }

    private static function numericMetric(array $source, string $key): ?int
    {
        if (!array_key_exists($key, $source)) return null;
        $value = $source[$key];
        if ($value === null || $value === '' || !is_numeric($value)) return null;
        return max(0, (int) $value);
    }

    private static function firstNumericMetric(array ...$candidates): ?int
    {
        foreach ($candidates as $candidate) {
            if (!isset($candidate[0], $candidate[1]) || !is_array($candidate[0])) continue;
            $value = self::numericMetric($candidate[0], (string) $candidate[1]);
            if ($value !== null) return $value;
        }
        return null;
    }

    /** Sum numeric rejection-summary buckets while ignoring provider ledgers and diagnostics arrays. */
    private static function rejectionCount(array $summary, array $keys): int
    {
        $total = 0;
        foreach ($keys as $key) {
            $value = $summary[(string) $key] ?? null;
            if (is_numeric($value)) $total += max(0, (int) $value);
        }
        return $total;
    }

    private static function distinctCount(array $rows, string $field): int
    {
        $seen = [];
        foreach ($rows as $row) {
            if (!is_array($row) || !isset($row[$field]) || (string) $row[$field] === '') continue;
            $seen[(string) $row[$field]] = true;
        }
        return count($seen);
    }

    /**
     * Normalize the generation-run funnel used by /sports.
     *
     * Newer DailyTicketService rows carry `_diagnostics`, which is the primary
     * source. Legacy rows may only have the daily counters, rejection buckets,
     * predictions and ticket selections; those are still persisted facts, so the
     * sidebar can show the best reconstructable values instead of misleading
     * zeros. A missing daily row remains unavailable (`null`) because no run was
     * recorded for that date.
     *
     * @return array<string,int|null>
     */
    private function dashboardRunMetrics(?array $daily, ?array $ticket, array $ticketSelections, array $todayPredictions): array
    {
        $metrics = self::emptyDashboardRunMetrics();
        if ($daily === null) return $metrics;

        $summary = is_array($daily['rejection_summary'] ?? null) ? $daily['rejection_summary'] : [];
        $diag = is_array($summary['_diagnostics'] ?? null) ? $summary['_diagnostics'] : [];
        $runSummary = is_array($diag['runSummary'] ?? null) ? $diag['runSummary'] : [];

        $selectedPicks = count($ticketSelections);
        if ($ticket !== null) {
            $ticketSelectionCount = self::numericMetric($ticket, 'selection_count');
            if ($ticketSelectionCount !== null) $selectedPicks = max($selectedPicks, $ticketSelectionCount);
        }
        $selectedMatches = self::distinctCount($ticketSelections, 'match_id');
        $selectedPredictionIds = self::distinctCount($ticketSelections, 'prediction_id');
        $qualifiedPredictions = array_values(array_filter($todayPredictions, static fn($p): bool => is_array($p) && ($p['decision'] ?? '') === 'PREDICTION_READY'));

        $fixturesEvaluated = self::firstNumericMetric([$diag, 'fixturesEvaluated'], [$daily, 'candidates_evaluated'], [$runSummary, 'matchesDiscovered']);
        if ($fixturesEvaluated === null) $fixturesEvaluated = 0;

        $fixtureStageRejected = self::rejectionCount($summary, [
            'FIXTURE_NOT_NS_OR_TOO_SOON', 'MATCH_FINISHED', 'MATCH_ALREADY_STARTED', 'KICKOFF_TOO_CLOSE',
            'MATCH_NOT_FOUND', 'MATCH_STATUS_INVALID', 'MATCH_DATA_INVALID', 'NOT_SUPPORTED_SPORT',
        ]);
        $eligibleFixtures = self::firstNumericMetric([$diag, 'eligibleFixtures'], [$runSummary, 'matchesEvaluated']);
        if ($eligibleFixtures === null) $eligibleFixtures = max(0, $fixturesEvaluated - $fixtureStageRejected);

        $staleOdds = self::firstNumericMetric([$diag, 'fixturesRejectedStaleOdds']);
        if ($staleOdds === null) $staleOdds = self::rejectionCount($summary, ['STALE_ODDS', 'ODDS_STALE']);

        $oddsStageRejected = $staleOdds + self::rejectionCount($summary, [
            'ODDS_UNAVAILABLE', 'SUPPORTED_ODDS_UNAVAILABLE', 'MARKET_UNAVAILABLE', 'ODDS_TIMESTAMP_INVALID',
            'ODDS_INVALID', 'UNPRICEABLE_MARKET', 'NO_QUOTABLE_PRICE', 'UNREALISTIC_ODDS',
            'MARKET_SUSPENDED', 'NO_SUPPORTED_MARKET',
        ]);
        $freshOdds = self::firstNumericMetric([$diag, 'fixturesWithFreshOdds']);
        if ($freshOdds === null) $freshOdds = max(0, $eligibleFixtures - $oddsStageRejected);

        // If a legacy row's rejection buckets are incomplete, stored decisions
        // and selected legs still prove at least these many fixtures/markets
        // reached later stages of the same run. They are lower bounds, never
        // guesses.
        $predictionFixtureFloor = self::distinctCount($todayPredictions, 'match_id');
        $freshOdds = max($freshOdds, $predictionFixtureFloor, $selectedMatches);
        $eligibleFixtures = max($eligibleFixtures, $freshOdds, $selectedMatches);
        $fixturesEvaluated = max($fixturesEvaluated, $eligibleFixtures);

        $predictionsGenerated = self::numericMetric($diag, 'predictionsGenerated');
        if ($predictionsGenerated === null) {
            $predictionsGenerated = max(
                (int) (self::numericMetric($runSummary, 'predictionsGenerated') ?? 0),
                (int) (self::numericMetric($daily, 'predictions_recorded') ?? 0),
                count($todayPredictions),
                $selectedPredictionIds
            );
        } else {
            $predictionsGenerated = max($predictionsGenerated, $selectedPredictionIds);
        }

        $qualifiedCandidates = self::firstNumericMetric(
            [$diag, 'correlationQualifiedCandidates'],
            [$diag, 'riskQualifiedCandidates'],
            [$diag, 'positiveValueCandidates'],
            [$diag, 'confidenceQualifiedCandidates'],
            [$diag, 'eligiblePoolSize']
        );
        if ($qualifiedCandidates === null) $qualifiedCandidates = max(count($qualifiedPredictions), $selectedPicks);
        else $qualifiedCandidates = max($qualifiedCandidates, $selectedPicks);

        $finalQualified = self::numericMetric($diag, 'finalQualifiedCandidates');
        if ($finalQualified === null) $finalQualified = $selectedPicks;
        else $finalQualified = max($finalQualified, $selectedPicks);

        $metrics['eligibleFixtures'] = $eligibleFixtures;
        $metrics['fixturesEvaluated'] = $fixturesEvaluated;
        $metrics['predictionsGenerated'] = $predictionsGenerated;
        $metrics['fixturesWithFreshOdds'] = $freshOdds;
        $metrics['fixturesRejectedStaleOdds'] = $staleOdds;
        $metrics['correlationQualifiedCandidates'] = $qualifiedCandidates;
        $metrics['finalQualifiedCandidates'] = $finalQualified;

        return $metrics;
    }

    /**
     * Dashboard aggregation (spec §37) — everything from stored data.
     *
     * @param string|null $date Configured-local day (YYYY-MM-DD) the console is viewing.
     *        Null (or anything that is not a real calendar date) reports today,
     *        so existing callers keep working unchanged. The payload keeps its
     *        historic `todayIntelligence` / `today` key names for backward
     *        compatibility — the `date` inside them is the day actually reported.
     */
    public function dashboard(?string $date = null): array
    {
        $status = $this->status();
        $config = $status['configuration'];
        $timezone = DailyTicketDate::configuredTimezone((string) ($config['system_timezone'] ?? 'UTC'));
        $day = self::resolveDay($date, $timezone);
        $window = DailyTicketDate::utcWindow($day, $timezone);
        $dayStart = $window['start'];
        $dayEnd = gmdate('Y-m-d\TH:i:sP', $window['endTimestamp'] - 1);
        $upcoming = $this->repository->listMatches(['status' => 'SCHEDULED', 'from' => $dayStart, 'to' => $dayEnd], 50);
        // Live board: only matches with a canonical in-progress status
        // (LIVE, HALFTIME, EXTRA_TIME, PENALTIES) that were confirmed recently.
        // Never inferred from kickoff time; stale or terminal rows are hidden.
        $threshold = $this->liveScores->staleThresholdSeconds();
        $now = time();
        $rawLive = $this->repository->listMatches(['status' => LiveScoreService::LIVE_STATUSES], 200);
        $live = [];
        foreach ($rawLive as $m) {
            $matchStatus = strtoupper((string) ($m['status'] ?? ''));
            if (!in_array($matchStatus, LiveScoreService::LIVE_STATUSES, true)) continue;
            $updatedTs = strtotime((string) ($m['updated_at'] ?? ''));
            if ($updatedTs === false || ($now - $updatedTs) > $threshold) continue;
            $payload = SportsDataNormalizer::document($m['payload'] ?? null);
            $m['liveState'] = is_array($payload['live'] ?? null) ? $payload['live'] : [];
            $m['simulated'] = !empty($payload['simulated']);
            $live[] = $m;
            if (count($live) >= 50) break;
        }
        $todayPredictions = $this->repository->listPredictions(['from' => $dayStart, 'to' => $dayEnd], 500);
        $qualified = array_values(array_filter($todayPredictions, fn($p) => ($p['decision'] ?? '') === 'PREDICTION_READY'));
        $rejected = array_values(array_filter($todayPredictions, fn($p) => ($p['decision'] ?? '') !== 'PREDICTION_READY'));
        $daily = $this->repository->findDailyTicket($day);
        $ticket = is_array($daily) && !empty($daily['ticket_id']) ? $this->repository->findTicket((string) $daily['ticket_id']) : null;
        $ticketSelections = $ticket ? $this->repository->ticketSelections((string) $ticket['id']) : [];
        foreach ($ticketSelections as &$selection) {
            $match = $this->repository->findMatchById((int) ($selection['match_id'] ?? 0));
            if ($match !== null) {
                $selection['home_team'] = $match['home_team'] ?? null;
                $selection['away_team'] = $match['away_team'] ?? null;
                $selection['competition'] = $match['competition'] ?? null;
                $selection['kickoff_time'] = $selection['kickoff_time'] ?? $match['kickoff_at'] ?? null;
            }
        }
        unset($selection);
        $runMetrics = $this->dashboardRunMetrics($daily, $ticket, $ticketSelections, $todayPredictions);
        $confidenceValues = array_values(array_filter(array_map(fn($p) => is_numeric($p['confidence']) ? (float) $p['confidence'] : null, $todayPredictions)));
        $riskDist = ['LOW' => 0, 'MEDIUM' => 0, 'HIGH' => 0, 'REJECTED' => 0];
        foreach ($todayPredictions as $p) {
            $r = $p['risk'] ?? 'REJECTED';
            $riskDist[$r] = ($riskDist[$r] ?? 0) + 1;
        }
        // Trailing 30-day window ending on the viewed day, so a past day shows
        // the performance known at that point rather than today's.
        $perf = $this->performanceReport(['from' => gmdate('Y-m-d', strtotime($day . ' -29 days')) . 'T00:00:00+00:00', 'to' => $dayEnd]);
        $models = $this->modelPerformance->listModels();
        $calibrations = $this->repository->listCalibrations(null, 'APPROVED', 10);
        $lastSyncs = array_slice($this->repository->listJobRuns(null, 30), 0, 8);
        $qualityRows = array_map(fn($m) => ['match' => $m, 'quality' => $this->repository->latestQuality((int) $m['id'])], array_merge($upcoming, $live));
        $recentSyncs = [];
        try { $recentSyncs = $this->repository->listSyncRuns(null, 8); } catch (\Throwable $e) { $recentSyncs = []; }
        return [
            // The moment this dashboard payload was read from storage — the
            // page's honest "last updated" stamp (it never claims provider
            // freshness, which lives in the Data feed panel).
            'generatedAt' => gmdate('c'),
            'systemStatus' => [
                'enabled' => $status['enabled'], 'mode' => $status['mode'], 'isDemoData' => $status['isDemoData'],
                'providers' => $status['providers'], 'liveHealth' => $status['liveHealth'],
                'providersConfigured' => $status['providersConfigured'], 'configuredIds' => array_keys($this->providers->all()),
                'lastSyncs' => $lastSyncs, 'recentSyncs' => $recentSyncs, 'ticketEngine' => $status['ticketEngine'],
                'readiness' => $status['readiness'], 'predictionEngine' => $status['predictionEngine'],
            ],
            'todayIntelligence' => [
                'date' => $day,
                'upcomingCount' => count($upcoming),
                'upcoming' => $upcoming,
                'live' => $live,
                'qualifiedPredictions' => count($qualified),
                'rejectedPredictions' => count($rejected),
                'averageConfidence' => $confidenceValues ? round(array_sum($confidenceValues) / count($confidenceValues), 2) : null,
                'riskDistribution' => $riskDist,
                'dataQuality' => array_values(array_filter(array_map(fn($q) => $q['quality'] ? ['matchId' => $q['match']['id'], 'score' => $q['quality']['score'], 'band' => $q['quality']['band']] : null, $qualityRows))),
            ],
            'ticketEngine' => [
                'configuration' => $config,
                'today' => $daily,
                'ticket' => $ticket,
                'ticketSelections' => $ticketSelections,
                'runMetrics' => $runMetrics,
            ],
            'performance' => $perf,
            'models' => ['versions' => $models, 'approvedCalibrations' => $calibrations],
        ];
    }
}
