<?php
namespace AIWorkforce\Sports;

use AIWorkforce\Persistence\AuditRepository;
use AIWorkforce\Persistence\SportsRepository;

/**
 * Ticket record + approval governance (spec §18/§20).
 *
 * Default mode is USER_APPROVAL_REQUIRED: a generated ticket is PENDING until
 * a human with sports.approve decides. Under an explicitly authorized
 * AUTOMATED_EXECUTION configuration the decision is recorded as
 * APPROVED_NOT_EXECUTED — and external execution STILL does not exist in this
 * deployment (there is no external execution connector by design).
 */
class TicketGovernance
{
    private const RISK_ORDER = ['LOW' => 0, 'MEDIUM' => 1, 'HIGH' => 2];

    public function __construct(private SportsRepository $repo, private AuditRepository $audit, private CorrelationEngine $correlation = new CorrelationEngine()) {}

    /**
     * Persist a QUALIFIED optimized ticket.
     * @param array $optimized TicketOptimizer QUALIFIED output (selections = pipeline candidates)
     * @param string $configurationVersion active configuration version
     * @param int|null $modelVersionId
     * @param array $config active configuration (stake, mode…)
     */
    public function record(array $optimized, string $configurationVersion, ?int $modelVersionId = null, array $config = []): array
    {
        if (($optimized['status'] ?? '') !== 'QUALIFIED') {
            // Round 3b: never a bare NO_QUALIFIED_TICKET with no explanation —
            // carry through the exact machine-readable failure code and the
            // full candidate-level decision trace TicketOptimizer already built.
            return [
                'status' => 'NO_QUALIFIED_TICKET',
                'failureCode' => $optimized['failureCode'] ?? FailureTaxonomy::NO_COMBINABLE_TICKET,
                'reason' => $optimized['reason'] ?? 'No compliant combination',
                'candidateDecisions' => $optimized['candidateDecisions'] ?? [],
            ];
        }
        $sels = $optimized['selections'];
        // The 5.0 combined-odds floor is enforced one last time at the moment
        // of persistence: no ticket is ever stored below 5.0 total odds, no
        // matter how it was optimized. This is the final backstop behind the
        // optimizer's own floor, so a future caller that assembles an
        // "optimized" array by hand can never slip a sub-floor ticket into the
        // database. Nothing is padded to reach the number — a ticket that
        // cannot honestly clear 5.0 is simply not recorded.
        if ((float) ($optimized['totalOdds'] ?? 0) + 1e-9 < ConfigurationService::MIN_TARGET_ODDS_FLOOR) {
            return [
                'status' => 'NO_QUALIFIED_TICKET',
                'failureCode' => FailureTaxonomy::NO_COMBINABLE_TICKET,
                'reason' => sprintf('combined odds %.2f are below the %.2f minimum — no ticket is generated below %.1f combined odds',
                    (float) ($optimized['totalOdds'] ?? 0), ConfigurationService::MIN_TARGET_ODDS_FLOOR, ConfigurationService::MIN_TARGET_ODDS_FLOOR),
                'candidateDecisions' => $optimized['candidateDecisions'] ?? [],
            ];
        }
        // A ticket is only as honest as its legs. Every selection is validated
        // BEFORE anything is persisted: a real internal match id (never 0 or
        // missing), a supported market/selection from verified odds data, a
        // quotable price, and the observed timestamp that came with it. A leg
        // that fails validation aborts the whole ticket — a partially invented
        // ticket must never be stored.
        foreach ($sels as $index => $selection) $this->assertValidSelection($selection, (int) $index);

        $confidences = array_values(array_filter(array_map(fn($s) => is_numeric($s['confidence']['confidence'] ?? null) ? (float) $s['confidence']['confidence'] : null, $sels), fn($v) => $v !== null));
        $qualities = array_map(fn($s) => (int) ($s['quality']['score'] ?? 0), $sels);
        $combined = 1.0;
        $oddsCalc = ['formula' => [], 'unroundedProduct' => 1.0, 'displayTotalOdds' => $optimized['totalOdds']];
        foreach ($sels as $s) {
            $combined *= (float) ($s['prediction']['calibratedProbability'] ?? 0.5);
            $legOdds = (float) ($s['value']['odds'] ?? $s['odds'] ?? 0);
            $oddsCalc['formula'][] = $legOdds;
            $oddsCalc['unroundedProduct'] *= $legOdds;
        }
        $pairwise = $this->correlation->classifySelections($sels);
        $risk = 'LOW';
        foreach ($sels as $s) {
            $r = $s['risk']['classification'] ?? 'HIGH';
            if (isset(self::RISK_ORDER[$r]) && self::RISK_ORDER[$r] > self::RISK_ORDER[$risk]) $risk = $r;
        }
        $automated = (($config['engine_mode'] ?? '') === 'AUTOMATED_EXECUTION');

        $id = $optimized['ticketId'];
        $this->repo->saveTicket([
            'id' => $id, 'created_at' => gmdate('c'), 'model_version_id' => $modelVersionId,
            'configuration_version' => (string) $configurationVersion,
            'total_odds' => $optimized['totalOdds'], 'selection_count' => count($sels),
            'combined_probability' => round($combined, 8),
            'confidence' => $confidences ? round(min($confidences), 2) : null,
            'average_confidence' => $confidences ? round(array_sum($confidences) / count($confidences), 2) : null,
            'risk' => $risk, 'correlation' => $pairwise['classification'],
            'data_quality_score' => min($qualities),
            'average_data_quality' => $qualities ? round(array_sum($qualities) / count($qualities), 2) : null,
            'odds_calculation' => json_encode($oddsCalc),
            'status' => $automated ? 'APPROVED' : 'PENDING',
            'approval_status' => $automated ? 'APPROVED_NOT_EXECUTED' : 'PENDING_USER_APPROVAL',
            'settlement_status' => 'PENDING',
            'stake' => $config['stake_amount'] ?? null,
            'reason' => null,
        ]);
        foreach ($sels as $s) {
            $this->repo->saveTicketSelection([
                'ticket_id' => $id, 'prediction_id' => $s['predictionId'] ?? 'unlinked',
                'match_id' => (int) $s['matchId'],
                'fixture_id' => $s['match']['fixtureId'] ?? null,
                'home_team' => $s['match']['homeTeam'] ?? null,
                'away_team' => $s['match']['awayTeam'] ?? null,
                'kickoff_time' => $s['match']['kickoff'] ?? null,
                // Provider-supplied crest URLs (or the SANDBOX simulation's
                // own labeled placeholder), never invented for a provider
                // that sent none.
                'home_team_logo' => $s['match']['homeTeamLogo'] ?? null,
                'away_team_logo' => $s['match']['awayTeamLogo'] ?? null,
                'market' => $s['market'], 'selection' => $s['selection'],
                'odds' => $s['value']['odds'] ?? $s['odds'], 'odds_timestamp' => $s['oddsTimestamp'],
                // Which feed supplied the real bookmaker price (provenance),
                // beside WINDELS' own fair odds — never the same column.
                'odds_source' => $s['oddsSource'] ?? null,
                'fair_odds' => $s['value']['fairOdds'] ?? null,
                'confidence' => $s['confidence']['confidence'] ?? null,
                'data_quality' => $s['quality']['score'] ?? null,
                'model_probability' => $s['prediction']['rawModelProbability'] ?? null,
                'calibrated_probability' => $s['prediction']['calibratedProbability'] ?? null,
                'expected_value' => $s['value']['expectedValue'], 'risk' => $s['risk']['classification'],
                'result' => null, 'status' => 'PENDING',
            ]);
        }
        $this->audit->emit('SPORTS_TICKET_RECORDED', 'Sports ticket generated, ' . ($automated ? 'auto-approved under AUTOMATED_EXECUTION (no external execution)' : 'awaiting user approval'), [
            'ticketId' => $id, 'configurationVersion' => $configurationVersion, 'totalOdds' => $optimized['totalOdds'],
            'selectionCount' => count($sels), 'risk' => $risk, 'correlation' => $pairwise['classification'], 'automated' => $automated,
        ]);
        return ['status' => $automated ? 'APPROVED_NOT_EXECUTED' : 'PENDING_USER_APPROVAL', 'ticketId' => $id];
    }

    /**
     * One ticket leg's identity, market and price — validated, never defaulted.
     *
     * @throws \InvalidArgumentException when the leg has no real internal
     * match id, no supported market/selection, no quotable price, or no
     * observed odds timestamp. The caller aborts the ticket: storing the leg
     * with 0/UNSPECIFIED/a fresh timestamp would invent the missing data.
     */
    private function assertValidSelection(array $selection, int $index): void
    {
        $leg = 'ticket selection ' . ($index + 1);
        $matchId = $selection['matchId'] ?? null;
        if ((!is_int($matchId) && !ctype_digit((string) $matchId)) || (int) $matchId <= 0) {
            throw new \InvalidArgumentException($leg . ' has no valid internal match id');
        }
        $market = $selection['market'] ?? null;
        $pick = $selection['selection'] ?? null;
        if (!is_string($market) || trim($market) === '' || !is_string($pick) || trim($pick) === '') {
            throw new \InvalidArgumentException($leg . ' has no market/selection from verified odds data');
        }
        if (!PredictionEngine::isSupportedMarketSelection($market, $pick)) {
            throw new \InvalidArgumentException($leg . ' market ' . $market . '/' . $pick . ' is not a supported ticket market');
        }
        $odds = $selection['value']['odds'] ?? $selection['odds'] ?? null;
        if (!OddsBounds::validDecimalOdds($odds, $market)) {
            throw new \InvalidArgumentException($leg . ' has no quotable price for ' . $market . '/' . $pick);
        }
        $stamp = $selection['oddsTimestamp'] ?? null;
        if (!is_string($stamp) || trim($stamp) === '') {
            throw new \InvalidArgumentException($leg . ' carries no observed odds timestamp');
        }
        try { new \DateTimeImmutable($stamp); }
        catch (\Throwable $e) { throw new \InvalidArgumentException($leg . ' carries an invalid odds timestamp'); }
    }

    /** Human (or authorized-automated) decision. Always audited with the actor. */
    public function decide(string $id, bool $approve, string $actor, string $reason = ''): array
    {
        $ticket = $this->repo->findTicket($id);
        if (!$ticket) throw new \InvalidArgumentException('ticket not found');
        if (($ticket['approval_status'] ?? '') !== 'PENDING_USER_APPROVAL') throw new \RuntimeException('ticket already decided');
        $state = $approve ? 'APPROVED_NOT_EXECUTED' : 'REJECTED';
        $this->repo->updateTicket($id, ['approval_status' => $state, 'status' => $approve ? 'APPROVED' : 'CANCELLED', 'reason' => $reason]);
        $this->audit->emit($approve ? 'SPORTS_TICKET_APPROVED' : 'SPORTS_TICKET_REJECTED', 'Sports ticket decision; no external execution', ['ticketId' => $id, 'reason' => $reason], $actor);
        return ['ticketId' => $id, 'approvalStatus' => $state, 'externalExecution' => false];
    }
}
