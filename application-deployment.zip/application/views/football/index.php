<?php defined('BASEPATH') or exit('No direct script access allowed');
/**
 * Football Intelligence board.
 *
 * This page is intentionally arranged as one clear workflow:
 * date and actions → day overview → optional filters → ranked picks → every
 * fixture with its complete priced-market sheet → operational context. Numbers
 * are read from the stored board payload. A missing provider quote is named as
 * UNPRICED / DATA_UNAVAILABLE; it is never replaced with a model price.
 */
$d = $dashboard ?? [];
$board = $d['board'] ?? [];
$diagnostics = $d['diagnostics'] ?? [];
$diag = $diagnostics;
$perf = $d['performance'] ?? [];
// Categories remain part of the stored board contract. The unified odds board
// presents every fixture once rather than duplicating it into several sections.
$categories = $board['categories'] ?? [];
$live = $d['live'] ?? [];
$models = $d['models'] ?? [];
$caps = $caps ?? ['sync' => false, 'calibrate' => false, 'approve' => false, 'settle' => false];
$isAdmin = !empty($isAdmin);
$summary = $board['summary'] ?? ['fixtures' => 0, 'analyzed' => 0, 'qualified' => 0, 'limited' => 0, 'rejected' => 0];
$filters = is_array($board['filters'] ?? null) ? $board['filters'] : [];
$competitionBlock = is_array($filters['competitions'] ?? null) ? $filters['competitions'] : [];
$competitions = is_array($competitionBlock['competitions'] ?? null) ? $competitionBlock['competitions'] : [];
$premiumOptions = array_values(array_filter((array) ($competitionBlock['premiumCompetitions'] ?? []), static fn($entry): bool => is_array($entry) && (string) ($entry['externalId'] ?? '') !== ''));
$selectedCompetition = is_array($filters['competition'] ?? null) ? $filters['competition'] : [];
$selectedExternal = (string) ($selectedCompetition['externalId'] ?? '');
$premiumAllKeyword = \AIWorkforce\Football\MatchFeed::PREMIUM_LEAGUES;
$premiumAllScope = (string) ($selectedCompetition['state'] ?? '') === $premiumAllKeyword;
$marketBlock = is_array($board['market'] ?? null) ? $board['market'] : [];
$marketList = is_array($marketBlock['available'] ?? null) ? $marketBlock['available'] : [];
$selectedMarket = (string) ($marketBlock['key'] ?? 'MATCH_WINNER');
$marketRequested = trim((string) ($market ?? ''));
$providerOptions = is_array($providers['options'] ?? null) ? $providers['options'] : [];
$providerLocked = !empty($providerLocked) || !empty($providers['locked']);
$providerMode = (string) ($providerMode ?? ($providers['mode'] ?? 'AUTO'));
$providerRequestedRaw = trim((string) ($providerRequested ?? ''));
$selectedProvider = strtoupper(trim((string) ($provider ?? 'AUTO')));
$premium = is_array($competitionBlock['premium'] ?? null) ? $competitionBlock['premium'] : [];

$carry = [];
$competitionRequested = trim((string) ($selectedCompetition['requested'] ?? ''));
if ($competitionRequested !== '') $carry['competition'] = $competitionRequested;
if ($marketRequested !== '') $carry['market'] = $marketRequested;
if ($providerRequestedRaw !== '') $carry['provider'] = $providerRequestedRaw;

$dash = static fn(mixed $value, int $places = 1): string => is_numeric($value) ? number_format((float) $value, $places) : '—';
$pct = static fn(mixed $value, int $places = 1): string => is_numeric($value) ? number_format((float) $value * 100, $places) . '%' : '—';
$count = static fn(mixed $value): string => is_numeric($value) ? number_format((int) $value) : '—';
$percentPoints = static fn(mixed $value, int $places = 1): string => is_numeric($value) ? number_format((float) $value, $places) . '%' : '—';
$qualityScore = static fn(mixed $value): string => is_numeric($value) ? number_format((float) $value, 1) . '/100' : '—';
$goalError = static fn(mixed $value): string => is_numeric($value) ? number_format((float) $value, 2) . ' goals' : '—';
$odds = static fn(mixed $value): string => is_numeric($value) ? number_format((float) $value, 2) : '—';
$signedPct = static fn(mixed $value): string => is_numeric($value) ? ((float) $value >= 0 ? '+' : '') . number_format((float) $value * 100, 1) . '%' : '—';
$bandClass = static fn(string $band): string => match (strtoupper($band)) {
    'QUALIFIED', 'AVAILABLE', 'FRESH', 'CALIBRATED', 'LOW' => 'b-green',
    'LIMITED', 'LIMITED_DATA', 'PARTIAL_MARKET', 'STALE', 'MEDIUM' => 'b-amber',
    'HIGH', 'REJECTED', 'DATA_UNAVAILABLE', 'UNPRICED' => 'b-red',
    default => 'b-gray',
};
$stateClass = static fn(string $state): string => match (strtoupper($state)) {
    'READY', 'CONNECTED', 'AVAILABLE', 'ACTIVE', 'MEASURED', 'CALIBRATED', 'ONLINE', 'POPULATED' => 'up',
    'DEGRADED', 'LIMITED_DATA', 'LIMITED', 'PENDING', 'CADENCE', 'DRAFT', 'TRAINED', 'VALIDATED', 'APPROVED' => 'synth',
    default => 'down',
};
$kickoff = static function (mixed $iso, string $format = 'D j M · H:i'): string {
    $stamp = is_string($iso) && trim($iso) !== '' ? strtotime($iso) : false;
    return $stamp === false ? 'DATA_UNAVAILABLE' : gmdate($format, $stamp) . ' UTC';
};
$shortTime = static function (mixed $iso): string {
    $stamp = is_string($iso) && trim($iso) !== '' ? strtotime($iso) : false;
    return $stamp === false ? '—' : gmdate('H:i', $stamp) . ' UTC';
};
// Used by live fixtures specifically: it prints the fixture's stored kickoff,
// not the time the page was rendered.
$kickoffStamp = static function (mixed $iso): string {
    $stamp = is_string($iso) && trim($iso) !== '' ? strtotime($iso) : false;
    return $stamp === false ? 'DATA_UNAVAILABLE' : gmdate('D j M Y · H:i', $stamp) . ' UTC';
};
$pager = static function (array $pagination, string $viewDate, array $carry): string {
    $total = (int) ($pagination['totalMatches'] ?? 0);
    if ($total === 0) return '';
    $page = (int) ($pagination['page'] ?? 1);
    $pages = (int) ($pagination['totalPages'] ?? 1);
    $href = static function (int $target) use ($viewDate, $carry): string {
        return '/football?' . http_build_query(array_merge(['date' => $viewDate, 'page' => $target], $carry));
    };
    // Inactive edges render as a real disabled button rather than a styled
    // span: a span keeps the .btn `cursor: pointer` affordance, so it looks
    // clickable while doing nothing. A native disabled button is announced as
    // unavailable, is skipped by tab order and shows `not-allowed` on hover.
    $previous = !empty($pagination['hasPrevious'])
        ? '<a class="btn small" href="' . e($href((int) $pagination['previousPage'])) . '" rel="prev">&larr; Previous</a>'
        : '<button class="btn small" type="button" disabled title="You are on the first page">&larr; Previous</button>';
    $next = !empty($pagination['hasNext'])
        ? '<a class="btn small" href="' . e($href((int) $pagination['nextPage'])) . '" rel="next">Next &rarr;</a>'
        : '<button class="btn small" type="button" disabled title="You are on the last page">Next &rarr;</button>';
    // Past the last page the board holds nothing, so say that plainly and
    // offer a one-click way back to real content. "Page 9 of 2" with an empty
    // table reads as a broken screen.
    $status = $page > $pages
        ? '<b>Page ' . $page . ' is past the last page (' . $pages . ')</b><span>No matches on this page · '
            . $total . ' matches across ' . $pages . ' page' . ($pages === 1 ? '' : 's') . '</span>'
        : '<b>Page ' . $page . ' of ' . $pages . '</b><span>'
            . (int) ($pagination['from'] ?? 0) . '–' . (int) ($pagination['to'] ?? 0) . ' of ' . $total
            . ' matches · ' . (int) ($pagination['pageSize'] ?? 50) . ' matches per page</span>';
    return '<nav class="football-pager" aria-label="Match pages">'
        . '<div>' . $previous . '</div>'
        . '<div class="football-pager__status">' . $status . '</div>'
        . '<div>' . $next . '</div></nav>';
};
?>
<div class="football-console">
  <section class="football-hero" aria-labelledby="football-heading">
    <div class="football-hero__intro">
      <p class="football-eyebrow">TODAY'S FOOTBALL PREDICTIONS</p>
      <h2 id="football-heading">Match predictions and odds, in one place</h2>
      <p class="football-hero__copy">
        <?= e((string) ($board['dateLabel'] ?? $date ?? gmdate('Y-m-d'))) ?>. One board, read top to bottom: what is stored for the day, the ranked picks drawn from it, every fixture with its full odds sheet, and the measured result of everything already settled. Model probabilities and bookmaker prices are always reported in separate columns and never mixed. No bet is placed from this screen.
      </p>
    </div>
    <div class="football-hero__actions" aria-label="Football date navigation">
      <?php // Day navigation keeps the operator's competition / market /
            // provider selection (it re-reads stored rows, never regenerates).
            $dayHref = static fn(string $day): string => '/football?' . http_build_query(array_merge(['date' => $day], $carry)); ?>
      <a class="btn small" href="<?= e($dayHref((string) ($yesterday ?? gmdate('Y-m-d', time() - 86400)))) ?>">← Previous day</a>
      <a class="btn small" href="<?= e($carry === [] ? '/football' : '/football?' . http_build_query($carry)) ?>">Today</a>
      <a class="btn small" href="<?= e($dayHref((string) ($tomorrow ?? gmdate('Y-m-d', time() + 86400)))) ?>">Next day →</a>
    </div>
  </section>

  <section class="football-actionbar" aria-label="Football actions">
    <div class="football-actionbar__group">
      <form method="post" action="/football/sync" onsubmit="return confirm('Pull fixtures for this date from the connected provider now? Provider rate limits and daily quotas are respected.')">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken ?? '') ?>">
        <input type="hidden" name="date" value="<?= e((string) ($date ?? gmdate('Y-m-d'))) ?>">
        <button class="btn small primary" type="submit" <?= empty($caps['sync']) ? 'title="Requires the sports.manage permission — click to see the access message"' : '' ?>>Sync this date</button>
      </form>
      <form method="post" action="/football/predict" onsubmit="return confirm('Generate predictions for unmatched fixtures on this page? At most 50 new predictions are created; stored predictions are reused.')">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken ?? '') ?>">
        <input type="hidden" name="date" value="<?= e((string) ($date ?? gmdate('Y-m-d'))) ?>">
        <input type="hidden" name="page" value="<?= (int) ($page ?? 1) ?>">
        <input type="hidden" name="competition" value="<?= e((string) ($carry['competition'] ?? '')) ?>">
        <input type="hidden" name="market" value="<?= e((string) ($carry['market'] ?? '')) ?>">
        <input type="hidden" name="provider" value="<?= e((string) ($carry['provider'] ?? '')) ?>">
        <button class="btn small" type="submit" <?= empty($caps['sync']) ? 'title="Requires the sports.manage permission — click to see the access message"' : '' ?>>Generate this page (max 50)</button>
      </form>
    </div>
    <div class="football-actionbar__group">
      <a class="btn small" href="#football-live-panel">Live match</a>
      <a class="btn small" href="/football/models">Models &amp; calibration</a>
      <a class="btn small football-ticket-link" href="/sports">🎯 Odds prediction tickets</a>
    </div>
  </section>

  <?php if (!empty($notice)): ?><div class="notice ok"><?= e($notice) ?></div><?php endif; ?>
  <?php if (!empty($error)): ?><div class="notice err"><?= e($error) ?></div><?php endif; ?>
  <?php if (!empty($diag['demoMode'])): ?><div class="notice warnbox"><b>DEMO / SANDBOX DATA</b> — these football rows are simulated and are never mixed into real-world performance figures.</div><?php endif; ?>
  <?php if (!empty($diag['message'])): ?><div class="notice warnbox"><b>Football data provider not connected.</b> Live fixtures and prices are unavailable until a verified source is configured. Nothing below is fabricated to fill the gap.</div><?php endif; ?>

  <div class="football-layout">
    <div class="football-main stack">
      <?php /* Competition, premium-league, market and date are read-only
               selections over stored rows and are honoured for every signed-in
               viewer, so every viewer gets the controls. Only the data-provider
               pin is an administrator concern (the backend honours it for
               admins under MANUAL mode), so that one selector stays gated. */ ?>
        <section class="panel football-section" id="football-filters" aria-labelledby="football-filters-heading">
          <div class="football-section__heading">
            <div class="football-section__title">
              <span class="football-step football-step--control" aria-hidden="true">⚙</span>
              <div>
                <p class="football-eyebrow">Board view</p>
                <h3 id="football-filters-heading">Filter stored fixtures and markets</h3>
              </div>
            </div>
            <span class="badge <?= strtoupper($providerMode) === 'MANUAL' ? 'b-amber' : 'b-green' ?>"><?= e($providerMode) ?> · <?= strtoupper($providerMode) === 'MANUAL' ? 'operator selection' : 'admin managed' ?></span>
          </div>
          <div class="body">
            <p class="football-section-intro">These controls change what the three board sections below display. They only reorganize saved fixtures and stored odds — no provider request is spent. <?= !empty($refresh)
              ? 'The board read generates the missing predictions for the page in view (at most the configured batch); stored predictions are reused, never regenerated.'
              : 'This deployment reads without generating (?refresh=0 or WINDELS_FOOTBALL_GENERATE_ON_READ=false); the Generate this page action creates the missing predictions.' ?></p>
            <form method="get" action="/football" class="football-filter-form">
              <input type="hidden" name="page" value="1">
              <?php if ($isAdmin): ?>
              <label class="fld">Data provider
                <select class="sel" name="provider" <?= $providerLocked ? 'disabled' : '' ?> title="Provider choice controls synced data; reading this board only uses stored rows.">
                  <?php if ($providerOptions === []): ?><option value="">No feed connected</option><?php endif; ?>
                  <?php foreach ($providerOptions as $option): ?>
                    <?php $value = (string) ($option['value'] ?? ''); ?>
                    <option value="<?= e($value) ?>" <?= strtoupper($value) === $selectedProvider ? 'selected' : '' ?>><?= e((string) ($option['label'] ?? $value)) ?></option>
                  <?php endforeach; ?>
                </select>
                <?php if ($providerLocked): ?><input type="hidden" name="provider" value="AUTO"><?php endif; ?>
              </label>
              <?php endif; ?>
              <label class="fld">Competition
                <select class="sel" name="competition">
                  <option value="">All competitions</option>
                  <option value="<?= e($premiumAllKeyword) ?>" <?= $premiumAllScope ? 'selected' : '' ?>>All premium leagues</option>
                  <?php foreach ($competitions as $entry): ?>
                    <?php $value = (string) ($entry['externalId'] ?? ''); ?>
                    <option value="<?= e($value) ?>" <?= !$premiumAllScope && $selectedExternal === $value ? 'selected' : '' ?>><?= e((string) ($entry['name'] ?? 'Competition')) ?> · <?= (int) ($entry['matches'] ?? 0) ?> matches</option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label class="fld">Premium league
                <select class="sel" name="premium" onchange="this.form.competition.value=this.value">
                  <option value="">No premium-only filter</option>
                  <option value="<?= e($premiumAllKeyword) ?>" <?= $premiumAllScope ? 'selected' : '' ?>>All premium leagues</option>
                  <?php foreach ($premiumOptions as $entry): ?>
                    <?php $value = (string) ($entry['externalId'] ?? ''); ?>
                    <option value="<?= e($value) ?>" <?= !$premiumAllScope && $selectedExternal === $value ? 'selected' : '' ?>><?= e((string) ($entry['name'] ?? 'Premium league')) ?> · <?= (int) ($entry['matches'] ?? 0) ?> match<?= (int) ($entry['matches'] ?? 0) === 1 ? '' : 'es' ?><?= $value === (string) ($premium['externalId'] ?? '') ? ' · featured' : '' ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label class="fld">Odds market
                <select class="sel" name="market">
                  <option value="">All markets — match winner overview</option>
                  <?php foreach ($marketList as $entry): ?>
                    <?php $key = (string) ($entry['key'] ?? ''); ?>
                    <option value="<?= e($key) ?>" <?= $marketRequested !== '' && $selectedMarket === $key ? 'selected' : '' ?>><?= e((string) ($entry['label'] ?? $key)) ?><?= empty($entry['oddsAvailable']) && (string) ($entry['derivation'] ?? '') === 'NOT_MODELLED' ? ' · price not stored' : '' ?></option>
                  <?php endforeach; ?>
                </select>
              </label>
              <label class="fld">Date <input class="sel" type="date" name="date" value="<?= e((string) ($date ?? gmdate('Y-m-d'))) ?>"></label>
              <button class="btn primary" type="submit">Apply view</button>
            </form>
            <p class="football-help">Filters only reorganize saved fixtures and stored odds — they spend no provider request. The complete odds sheet remains available for every match below.</p>
          </div>
        </section>

      <?php
        /* The Day overview prints three scopes, each labeled as itself: the
           summary counts (the whole selection — the date, or the date narrowed
           to the chosen competition), the page block (what THIS read evaluated
           for the page in view), and the read stamp (when the payload was
           generated). A page-scoped figure is never dressed up as a
           date-wide one, and "withheld" is the engine's own refusal — the
           quality gate answered and chose not to store — not a gap. */
        $pageBlock = is_array($board['page'] ?? null) ? $board['page'] : [];
        $pagination = is_array($board['pagination'] ?? null) ? $board['pagination'] : [];
        $selectionState = (string) ($selectedCompetition['state'] ?? '');
        $selectionName = in_array($selectionState, ['NARROWED', 'PREMIUM_LEAGUES'], true)
            ? (string) ($selectedCompetition['name'] ?? '') : '';
        $withheldOnPage = (int) ($pageBlock['withheld'] ?? 0);
        $pageFixtures = (int) ($pagination['returned'] ?? 0);
        /* "Withheld" and "Awaiting analysis" must not describe the same match
           twice. A withheld match HAS been analyzed — the engine ran, scored the
           evidence below the floor and refused to store a row — so counting it
           again as "no prediction row yet" reported six fixtures as twelve
           states. Everything this read already answered for (withheld, closed,
           failed) is therefore taken out of the waiting count, which is left
           meaning exactly what it says: nobody has asked the engine yet. */
        $unanalyzed = max(0, (int) ($summary['fixtures'] ?? 0) - (int) ($summary['analyzed'] ?? 0));
        $answeredOnPage = min($unanalyzed, $withheldOnPage + (int) ($pageBlock['frozen'] ?? 0) + (int) ($pageBlock['failed'] ?? 0));
        $awaitingAnalysis = max(0, $unanalyzed - $answeredOnPage);
      ?>
      <section class="panel football-section" id="football-overview" aria-labelledby="day-overview-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <span class="football-step" aria-hidden="true">1</span>
            <div>
              <p class="football-eyebrow">Day overview</p>
              <h3 id="day-overview-heading">What is stored for <?= e((string) ($board['dateLabel'] ?? $board['date'] ?? $date ?? 'this date')) ?><?php if ((string) ($board['date'] ?? $date ?? '') !== ''): ?> (<?= e((string) ($board['date'] ?? $date)) ?>)<?php endif; ?><?= $selectionName !== '' ? ' — ' . e($selectionName) : '' ?></h3>
            </div>
          </div>
          <span class="football-section__meta" title="When this page read its stored board payload (UTC). Reload re-reads storage; no provider request is spent.">Board read <?= e($kickoff($d['generatedAt'] ?? null, 'D j M Y · H:i')) ?></span>
        </div>
        <div class="body">
          <p class="football-section-intro">The counts below describe saved rows for <?= $selectionName !== '' ? 'this selection — <b>' . e($selectionName) . '</b> on ' : '' ?>this date. A fixture is <b>qualified</b> when its stored evidence clears the data-quality floor, <b>limited</b> when it is usable with caution, and <b>withheld</b> when the engine refused to write a prediction because the evidence was too thin. <?= !empty($refresh)
            ? 'Reading this board generates the missing predictions for the page in view — at most the configured batch, stored ones are reused, never regenerated, and no provider request is spent.'
            : 'This read generated nothing: generation on read is off (?refresh=0 or WINDELS_FOOTBALL_GENERATE_ON_READ=false), so the Generate this page action stays the way predictions are created.' ?></p>
          <div class="stat-grid football-stat-grid">
            <div class="stat"><div class="k">Fixtures found</div><div class="v"><?= (int) ($summary['fixtures'] ?? 0) ?></div><div class="trend">stored for this date<?= $selectionName !== '' ? ' · ' . e($selectionName) : '' ?></div></div>
            <div class="stat"><div class="k">Analyzed</div><div class="v"><?= (int) ($summary['analyzed'] ?? 0) ?></div><div class="trend">prediction rows saved</div></div>
            <div class="stat"><div class="k">Qualified</div><div class="v up"><?= (int) ($summary['qualified'] ?? 0) ?></div><div class="trend">verified data quality</div></div>
            <div class="stat"><div class="k">Limited evidence</div><div class="v warn"><?= (int) ($summary['limited'] ?? 0) ?></div><div class="trend">usable with caution</div></div>
            <div class="stat"><div class="k">Withheld</div><div class="v down"><?= $withheldOnPage ?></div><div class="trend">evidence below the floor · this page</div></div>
            <div class="stat"><div class="k">Awaiting analysis</div><div class="v"><?= $awaitingAnalysis ?></div><div class="trend"><?= $answeredOnPage > 0
              ? 'no prediction row yet · excludes ' . $answeredOnPage . ' answered on this page'
              : 'no prediction row yet · whole selection' ?></div></div>
          </div>
          <?php if ($pagination !== []): ?>
            <div class="football-section__divider"></div>
            <?= $pager($pagination, (string) ($date ?? gmdate('Y-m-d')), $carry) ?>
            <?php
              // What this read made of the page's own fixtures, in the same
              // words the table below uses. Zero-valued clauses stay silent so
              // the line reads as a sentence, not a spreadsheet.
              $pageParts = [(int) ($pageBlock['predicted'] ?? 0) . ' with a stored prediction'];
              if ($withheldOnPage > 0) $pageParts[] = $withheldOnPage . ' withheld (evidence below the floor)';
              if ((int) ($pageBlock['frozen'] ?? 0) > 0) $pageParts[] = (int) $pageBlock['frozen'] . ' closed (kickoff already passed)';
              if ((int) ($pageBlock['deferred'] ?? 0) > 0) $pageParts[] = (int) $pageBlock['deferred'] . ' deferred to the next cycle';
              if ((int) ($pageBlock['failed'] ?? 0) > 0) $pageParts[] = (int) $pageBlock['failed'] . ' failed';
            ?>
            <p class="football-help">This page contains <?= $pageFixtures ?> stored fixture<?= $pageFixtures === 1 ? '' : 's' ?> — <?= implode(', ', $pageParts) ?>. <?= !empty($refresh)
              ? 'Reading a page generates only its own missing predictions (at most the configured batch); paging never refreshes prices and never regenerates a stored prediction.'
              : 'Paging only reads saved rows; it never refreshes prices and never generates a prediction.' ?></p>
          <?php endif; ?>
          <?php if (in_array((string) ($board['state'] ?? ''), ['NO_FIXTURES_STORED', 'NO_PREDICTIONS_STORED', 'PAGE_BEYOND_LAST'], true)): ?>
            <div class="empty-state"><p><?= e((string) ($board['message'] ?? 'No stored fixtures are available for this selection.')) ?></p></div>
          <?php endif; ?>
        </div>
      </section>

      <?php
        /* Section 2 — the ranked reading. The picks payload publishes the full
           accounting (considered / eligible / shown / beyondList / excluded
           with reasons, and per-pick evidence, confidence, risk, value class
           and warnings); this section prints all of it, so "5 of 9 eligible"
           is read off the page rather than implied, and every match the list
           did not take is named with the sentence that kept it out. */
        $picksBlock = is_array($board['picks'] ?? null) ? $board['picks'] : [];
        $picks = is_array($picksBlock['picks'] ?? null) ? $picksBlock['picks'] : [];
        // The complete ranked list: every eligible match on the page, ranked.
        // The console renders this — the configured top list (`picks`) is the
        // headline, not the whole table — so no eligible match is reduced to a
        // "+N beyond the list" counter.
        $picksAll = is_array($picksBlock['allPicks'] ?? null) ? $picksBlock['allPicks'] : $picks;
        $picksConsidered = (int) ($picksBlock['considered'] ?? 0);
        $picksEligible = (int) ($picksBlock['eligible'] ?? 0);
        $picksBeyond = (int) ($picksBlock['beyondList'] ?? 0);
        $picksLimit = (int) ($picksBlock['limit'] ?? 0);
        $picksExcludedRaw = is_array($picksBlock['excluded'] ?? null) ? $picksBlock['excluded'] : [];
        $picksExcluded = array_values(array_filter($picksExcludedRaw, 'is_array'));
        $picksMarketLabel = (string) ($picksBlock['market'] ?? '');
        $picksRule = is_array($picksBlock['rule'] ?? null) ? $picksBlock['rule'] : [];
      ?>
      <section class="panel football-section" id="football-picks" aria-labelledby="top-picks-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <span class="football-step" aria-hidden="true">2</span>
            <div>
              <p class="football-eyebrow">Ranked reading</p>
              <h3 id="top-picks-heading">Top WINDELS Picks</h3>
            </div>
          </div>
          <span class="football-section__meta" title="<?= e((string) ($picksRule['eligibility'] ?? 'Eligible matches on this page: analyzed, QUALIFIED or LIMITED data quality, an actual selection in the selected market, not withheld, not unstable.')) ?>"><?= $picksEligible ?> eligible on this page<?= $picksEligible > 0 ? ' · all ' . count($picksAll) . ' listed' : '' ?><?= $picksBeyond > 0 ? ' · top ' . $picksLimit . ' marked' : '' ?></span>
        </div>
        <div class="body">
          <p class="football-section-intro">The strongest comparisons drawn from the fixtures in section 3, ordered by intelligence score. Each row keeps the model probability and the bookmaker price in their own columns so the two readings are never confused. Every pick is the selected market's answer<?= $picksMarketLabel !== '' ? ' — <b>' . e($picksMarketLabel) . '</b>' : '' ?> — ranked evidence band first, then intelligence score, then the edge against the quoted price, then model confidence.</p>
          <?php if ($picksAll === []): ?>
            <p class="football-help">No fixtures currently satisfy the required prediction and data-quality thresholds. This is a finding, not a gap filled with a forced selection.</p>
          <?php else: ?>
            <div class="table-scroll">
              <table class="tbl football-table football-picks-table">
                <thead><tr><th>#</th><th>Match &amp; pick</th><th class="num">WINDELS probability</th><th class="num">Market odds</th><th class="num">WINDELS fair odds</th><th>Value</th><th>Evidence</th><th class="num">Confidence</th><th class="num">Intelligence</th><th>Risk</th><th>Movement</th></tr></thead>
                <tbody>
                  <?php foreach ($picksAll as $pick): ?>
                    <?php
                      $cardPageId = (int) ($pick['fixtureId'] ?? 0);
                      $move = (string) ($pick['stabilityState'] ?? '');
                      $pickBand = (string) ($pick['band'] ?? '');
                      $valueClass = (string) ($pick['valueClass'] ?? 'UNPRICED');
                      $valueTone = in_array($valueClass, ['STRONG_VALUE', 'POSITIVE_VALUE'], true) ? 'b-green'
                          : (in_array($valueClass, ['NEGATIVE_VALUE', 'AVOID'], true) ? 'b-red' : 'b-gray');
                      $riskLevel = strtoupper((string) ($pick['risk'] ?? 'UNKNOWN'));
                      $riskTone = $riskLevel === 'LOW' ? 'b-green' : ($riskLevel === 'MEDIUM' ? 'b-amber' : ($riskLevel === 'HIGH' ? 'b-red' : 'b-gray'));
                      $pickWarnings = is_array($pick['warnings'] ?? null) ? array_values(array_filter($pick['warnings'], static fn($w): bool => is_string($w) && trim($w) !== '')) : [];
                    ?>
                    <tr>
                      <td class="mono"><?= (int) ($pick['rank'] ?? 0) ?></td>
                      <td><?php if ($cardPageId > 0): ?><a href="/football/match/<?= $cardPageId ?>" class="football-match-link"><?php endif; ?><?= crest($pick['homeTeamLogo'] ?? null) ?><?= e((string) ($pick['homeTeam'] ?? '—')) ?> vs <?= crest($pick['awayTeamLogo'] ?? null) ?><?= e((string) ($pick['awayTeam'] ?? '—')) ?><?php if ($cardPageId > 0): ?></a><?php endif; ?><div class="dim football-cell-note"><?= e((string) ($pick['selectionLabel'] ?? '—')) ?> · <?= e((string) ($pick['kickoffLabel'] ?? '')) ?> · <?= e((string) ($pick['market'] ?? '')) ?></div></td>
                      <td class="num mono"><?= $pct($pick['probability'] ?? null) ?></td>
                      <td class="num mono"><?= $odds($pick['odds'] ?? null) ?></td>
                      <td class="num mono"><?= $odds($pick['fairOdds'] ?? null) ?></td>
                      <td><span class="badge <?= $valueTone ?>"><?= e((string) ($pick['valueLabel'] ?? 'No price to compare')) ?></span><div class="dim football-cell-note"><?= is_numeric($pick['expectedValue'] ?? null) ? 'Expected return ' . $signedPct($pick['expectedValue']) : 'Expected return —' ?><?= is_numeric($pick['edgePoints'] ?? null) ? ' · edge ' . ((float) $pick['edgePoints'] >= 0 ? '+' : '') . number_format((float) $pick['edgePoints'], 1) . 'pp' : '' ?></div></td>
                      <td><span class="badge <?= $pickBand === 'QUALIFIED' ? 'b-green' : 'b-amber' ?>"><?= e($pickBand !== '' ? $pickBand : '—') ?></span><div class="dim football-cell-note">quality <?= is_numeric($pick['dataQuality'] ?? null) ? (int) $pick['dataQuality'] . '/100' : '—' ?></div></td>
                      <td class="num mono"><?= is_numeric($pick['confidence'] ?? null) ? number_format((float) $pick['confidence'], 1) . '%' : '—' ?></td>
                      <td class="num mono"><?= is_numeric($pick['score'] ?? null) ? (int) $pick['score'] . '/100' : '—' ?><?php if ((string) ($pick['scoreBand'] ?? '') !== ''): ?><div class="dim football-cell-note"><?= e((string) $pick['scoreBand']) ?></div><?php endif; ?></td>
                      <td><span class="badge <?= $riskTone ?>"><?= e($riskLevel !== '' ? $riskLevel : 'UNKNOWN') ?></span></td>
                      <td><?php if ($move === \AIWorkforce\Football\StabilityMonitor::UNSTABLE): ?><span class="badge b-red" title="This prediction moved materially between stored readings.">Prediction unstable — significant model movement</span><?php elseif ($move === \AIWorkforce\Football\StabilityMonitor::MOVED): ?><span class="badge b-amber">Moved</span><?php else: ?><span class="badge b-gray"><?= e((string) ($pick['stabilityLabel'] ?? 'Stable / first reading')) ?></span><?php endif; ?><?php foreach ($pickWarnings as $pickWarning): ?><div class="dim football-cell-note"><?= e($pickWarning) ?></div><?php endforeach; ?></td>
                    </tr>
                    <?php if ($picksLimit > 0 && (int) ($pick['rank'] ?? 0) === $picksLimit && count($picksAll) > $picksLimit): ?>
                      <tr class="football-picks-divider"><td colspan="11">Beyond the top <?= $picksLimit ?> — still eligible on this page, ranked below the marked list</td></tr>
                    <?php endif; ?>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
          <?php if ($picksExcluded !== []): ?>
            <details class="football-odds-disclosure football-picks-exclusions">
              <summary>
                <span><b><?= count($picksExcluded) ?> match<?= count($picksExcluded) === 1 ? ' was' : 'es were' ?> not eligible on this page</b> <span class="dim">· each with the reason that kept it out</span></span>
                <span class="football-disclosure-action">Show reasons</span>
              </summary>
              <ul class="football-picks-exclusions__list">
                <?php foreach ($picksExcluded as $excludedPick): ?>
                  <li><b><?= e((string) ($excludedPick['homeTeam'] ?? '—')) ?> vs <?= e((string) ($excludedPick['awayTeam'] ?? '—')) ?></b><span class="dim mono"><?= e((string) ($excludedPick['kickoffLabel'] ?? '')) ?></span><span><?= e((string) ($excludedPick['reason'] ?? 'Not eligible.')) ?></span></li>
                <?php endforeach; ?>
              </ul>
            </details>
          <?php endif; ?>
          <p class="football-help"><?= $picksConsidered ?> match<?= $picksConsidered === 1 ? ' was' : 'es were' ?> considered on this page · <?= $picksEligible ?> eligible · all <?= count($picksAll) ?> listed<?= $picksLimit > 0 ? ' (top ' . $picksLimit . ' marked' . ($picksBeyond > 0 ? ', +' . $picksBeyond . ' ranked below it' : '') . ')' : '' ?>. <?= e((string) ($picksRule['ranking'] ?? 'Ranked by evidence band, then intelligence score, then edge against the quoted price, then model confidence.')) ?></p>
          <p class="football-help"><?= e((string) ($picksBlock['disclaimer'] ?? 'Rankings are analytical comparisons, not a promise of a result.')) ?></p>
        </div>
      </section>

      <?php $rows = is_array($board['rows'] ?? null) ? $board['rows'] : []; ?>
      <section class="panel football-section" id="football-fixtures" aria-labelledby="fixtures-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <span class="football-step" aria-hidden="true">3</span>
            <div>
              <p class="football-eyebrow">Fixture odds board</p>
              <h3 id="fixtures-heading">Every match and its available odds</h3>
            </div>
          </div>
          <span class="football-section__meta"><?= count($rows) ?> match<?= count($rows) === 1 ? '' : 'es' ?> on this page</span>
        </div>
        <div class="body">
          <p class="football-section-intro">Open any fixture for its complete market sheet. Every modelled selection includes the WINDELS probability and fair odds; every real bookmaker quote adds decimal odds, implied and margin-free probability, market fair odds, break-even point, model edge, expected return, quote range, source and timestamp. Missing prices stay clearly marked <b>UNPRICED</b>.</p>
          <?php if ($rows === []): ?>
            <div class="empty-state"><p>No fixtures match this page and filter selection.</p></div>
          <?php else: ?>
            <div class="football-search" id="football-fixture-search" hidden>
              <label class="visually-hidden" for="football-team-search">Search teams on this page</label>
              <input type="search" id="football-team-search" placeholder="Search teams or competition on this page…" autocomplete="off"
                     aria-controls="football-fixture-board" aria-describedby="football-search-count">
              <span class="football-search__count" id="football-search-count" aria-live="polite"><?= count($rows) ?> of <?= count($rows) ?> shown</span>
            </div>
            <div class="football-fixture-list" id="football-fixture-board">
              <?php foreach ($rows as $row): ?>
                <?php
                $rowPageId = (int) ($row['fixtureId'] ?? $row['fixtureDatabaseId'] ?? 0);
                if ($rowPageId <= 0) continue;
                $fixtureId = $rowPageId;
                $primary = is_array($row['market'] ?? null) ? $row['market'] : [];
                $allMarkets = is_array($row['marketCandidates'] ?? null) ? $row['marketCandidates'] : [];
                // OVER_1_5 and UNDER_1_5 are useful filter aliases, but both
                // evaluate the same two-sided bookmaker market. Show that
                // family once in the all-odds sheet so a match never repeats
                // identical Over/Under rows under two headings.
                $marketSheet = [];
                $seenFamilies = [];
                foreach ($allMarkets as $candidate) {
                    $candidatePricing = is_array($candidate['pricing'] ?? null) ? $candidate['pricing'] : [];
                    $family = (string) ($candidatePricing['family'] ?? $candidate['key'] ?? '');
                    $lineKey = isset($candidatePricing['line']) && is_numeric($candidatePricing['line'])
                        ? number_format((float) $candidatePricing['line'], 2, '.', '') : '';
                    $displayKey = $family . '|' . $lineKey;
                    if ($displayKey !== '|' && isset($seenFamilies[$displayKey])) continue;
                    $seenFamilies[$displayKey] = true;
                    $marketSheet[] = $candidate;
                }
                $pricedSelections = 0;
                $modelledSelections = 0;
                $pricedMarkets = 0;
                $latestOddsAt = null;
                foreach ($marketSheet as $candidate) {
                    $candidatePriced = false;
                    $candidatePricing = is_array($candidate['pricing'] ?? null) ? $candidate['pricing'] : [];
                    $candidatePricedAt = (string) ($candidatePricing['pricedAt'] ?? '');
                    if ($candidatePricedAt !== '' && ($latestOddsAt === null || $candidatePricedAt > $latestOddsAt)) $latestOddsAt = $candidatePricedAt;
                    foreach ((array) ($candidate['outcomes'] ?? []) as $outcome) {
                        if (is_numeric($outcome['probability'] ?? null)) $modelledSelections++;
                        if (($outcome['oddsState'] ?? '') === \AIWorkforce\Football\PredictionMarkets::STATE_AVAILABLE) {
                            $pricedSelections++;
                            $candidatePriced = true;
                        }
                    }
                    if ($candidatePriced) $pricedMarkets++;
                }
                $primaryValue = is_array($primary['value'] ?? null) ? $primary['value'] : [];
                $primaryPricing = is_array($primary['pricing'] ?? null) ? $primary['pricing'] : [];
                // Core prediction fields are read from the immutable stored
                // row, not derived in the template. A match without a stored
                // prediction remains visibly unavailable instead of receiving
                // an estimated display value.
                $rowPrediction = is_array($row['prediction'] ?? null) ? $row['prediction'] : [];
                $oneXtwo = is_array($rowPrediction['probabilities'] ?? null) ? $rowPrediction['probabilities'] : [];
                $expectedGoals = is_array($row['expectedGoals'] ?? null) ? $row['expectedGoals'] : [];
                $category = is_array($row['category'] ?? null) ? $row['category'] : [];
                $alternativeLabels = [];
                foreach ((array) ($rowPrediction['alternativeScores'] ?? []) as $alternative) {
                  if (!is_array($alternative)) continue;
                  $scoreline = (string) ($alternative['score'] ?? '');
                  if ($scoreline === '' && isset($alternative['home'], $alternative['away'])) $scoreline = (int) $alternative['home'] . '–' . (int) $alternative['away'];
                  if ($scoreline !== '') $alternativeLabels[] = $scoreline . (is_numeric($alternative['probability'] ?? null) ? ' (' . $pct($alternative['probability']) . ')' : '');
                }
                ?>
                <article class="football-fixture" id="fixture-<?= $fixtureId ?>">
                  <header class="football-fixture__header">
                    <div class="football-fixture__identity">
                      <div class="football-fixture__meta"><span><?= e((string) ($row['league'] ?? $row['competition'] ?? '—')) ?></span><span>·</span><span><?= e($kickoff($row['kickoffAt'] ?? $row['kickoff'] ?? null)) ?></span><span>·</span><span><?= e((string) ($row['status'] ?? 'UNKNOWN')) ?></span></div>
                      <h4><a href="/football/match/<?= $rowPageId ?>"><?= crest($row['homeTeamLogo'] ?? null, 22) ?><?= e((string) ($row['homeTeam'] ?? '—')) ?> <span>vs</span> <?= crest($row['awayTeamLogo'] ?? null, 22) ?><?= e((string) ($row['awayTeam'] ?? '—')) ?></a></h4>
                    </div>
                    <div class="football-fixture__badges">
                      <span class="badge <?= $bandClass((string) ($row['band'] ?? '')) ?>">DQ <?= (int) ($row['dataQualityScore'] ?? $row['dataQuality'] ?? 0) ?>/100</span>
                      <span class="badge <?= $bandClass((string) ($row['fixtureDataState'] ?? 'DATA_UNAVAILABLE')) ?>">Data <?= e((string) ($row['fixtureDataState'] ?? 'DATA_UNAVAILABLE')) ?></span>
                      <span class="badge <?= $bandClass((string) ($row['band'] ?? '')) ?>" title="<?= e((string) ($category['reason'] ?? 'A/B/C requires qualified data and the stored confidence band.')) ?>"><?= e((string) ($category['label'] ?? 'Unrated')) ?></span>
                      <span class="badge <?= $bandClass((string) ($row['riskStatus'] ?? $row['risk']['level'] ?? '')) ?>"><?= e((string) ($row['riskStatus'] ?? $row['risk']['level'] ?? 'UNKNOWN')) ?> risk</span>
                      <span class="badge <?= ($row['predictionStatus'] ?? '') === 'ANALYZED' ? 'b-green' : 'b-gray' ?>"><?= e((string) ($row['predictionStatus'] ?? 'NOT_ANALYZED')) ?></span>
                    </div>
                  </header>
                  <div class="football-fixture__summary">
                    <div><span class="football-summary-label">Overview market</span><b><?= e((string) ($primary['label'] ?? $marketBlock['label'] ?? 'Match Winner')) ?></b><span><?= e((string) ($primary['selectionLabel'] ?? 'No selection')) ?></span></div>
                    <div><span class="football-summary-label">WINDELS probability</span><b class="mono"><?= $pct($primary['probability'] ?? null) ?></b><span><?= e((string) ($primary['source'] ?? '')) ?></span></div>
                    <div><span class="football-summary-label">Bookmaker odds</span><b class="mono"><?= $odds($primary['odds'] ?? null) ?></b><span><?= is_numeric($primary['odds'] ?? null) ? 'verified provider price' : 'UNPRICED' ?></span></div>
                    <div><span class="football-summary-label">Potential edge</span><b class="mono <?= (float) ($primaryValue['expectedValue'] ?? -1) >= 0 ? 'up' : 'down' ?>"><?= $signedPct($primaryValue['expectedValue'] ?? null) ?></b><span><?= e((string) ($primaryValue['valueLabel'] ?? 'No value verdict')) ?></span></div>
                    <div><span class="football-summary-label">Most likely winner</span><b><?= e((string) ($row['resultLabel'] ?? '—')) ?></b><span>most likely 1X2 outcome</span></div>
                    <div><span class="football-summary-label">Home / draw / away</span><b class="mono"><?= $pct($oneXtwo['home'] ?? null) ?> / <?= $pct($oneXtwo['draw'] ?? null) ?> / <?= $pct($oneXtwo['away'] ?? null) ?></b><span>stored 1X2 probabilities</span></div>
                    <div><span class="football-summary-label">Most likely score</span><b class="mono"><?= e((string) ($rowPrediction['predictedScore']['label'] ?? '—')) ?></b><span>modal scoreline</span></div>
                    <div><span class="football-summary-label">Expected goals</span><b class="mono"><?= $dash($expectedGoals['home'] ?? null, 2) ?> – <?= $dash($expectedGoals['away'] ?? null, 2) ?></b><span><?= e((string) ($expectedGoals['method'] ?? 'DATA_UNAVAILABLE')) ?></span></div>
                    <div><span class="football-summary-label">Alternative scorelines</span><b class="mono"><?= e($alternativeLabels === [] ? '—' : implode(' · ', array_slice($alternativeLabels, 0, 3))) ?></b><span>next most likely scores</span></div>
                    <div><span class="football-summary-label">Confidence</span><b class="mono"><?= $dash($row['confidence'] ?? null) ?>%</b><span><?= e((string) ($row['band'] ?? '')) ?></span></div>
                  </div>
                  <details class="football-odds-disclosure">
                    <summary>
                      <span><b>Full odds &amp; fair-price sheet</b> <span class="dim">· <?= count($marketSheet) ?> market<?= count($marketSheet) === 1 ? '' : 's' ?> · <?= $modelledSelections ?> modelled selection<?= $modelledSelections === 1 ? '' : 's' ?> · <?= $pricedSelections ?> bookmaker quote<?= $pricedSelections === 1 ? '' : 's' ?> across <?= $pricedMarkets ?> market<?= $pricedMarkets === 1 ? '' : 's' ?></span></span>
                      <span class="football-disclosure-action">Open sheet</span>
                    </summary>
                    <div class="football-odds-sheet">
                      <?php if ($marketSheet === []): ?>
                        <p class="football-help">Analyze this fixture to build its market sheet. No probability or price is invented before a stored prediction exists.</p>
                      <?php elseif ($pricedSelections === 0): ?>
                        <div class="football-odds-status"><span class="badge b-amber">BOOKMAKER ODDS UNAVAILABLE</span><p>The model-derived probabilities and WINDELS fair odds remain available below. No provider price is substituted for the missing quotes.</p></div>
                      <?php endif; ?>
                      <?php foreach ($marketSheet as $candidate): ?>
                        <?php
                        $outcomes = is_array($candidate['outcomes'] ?? null) ? $candidate['outcomes'] : [];
                        $pricing = is_array($candidate['pricing'] ?? null) ? $candidate['pricing'] : [];
                        $providerOnly = (string) ($candidate['source'] ?? '') === \AIWorkforce\Football\PredictionMarkets::SOURCE_ODDS;
                        ?>
                        <section class="football-market-card">
                          <header>
                            <div>
                              <p><?= e((string) ($candidate['group'] ?? 'Market')) ?></p>
                              <h5><?= e((string) ($candidate['label'] ?? $candidate['key'] ?? 'Market')) ?></h5>
                              <small><?= count($outcomes) ?> selection<?= count($outcomes) === 1 ? '' : 's' ?> · <?= e((string) ($candidate['basis'] ?? 'stored market data')) ?></small>
                            </div>
                            <div class="football-market-card__badges">
                              <span class="badge <?= $providerOnly ? 'b-amber' : 'b-blue' ?>"><?= $providerOnly ? 'Provider price only' : 'WINDELS modelled' ?></span>
                              <span class="badge <?= $bandClass((string) ($pricing['state'] ?? 'DATA_UNAVAILABLE')) ?>"><?= e((string) ($pricing['state'] ?? 'UNPRICED')) ?></span>
                              <?php if (!empty($pricing['priceStale'])): ?><span class="badge b-red">STALE PRICE</span><?php endif; ?>
                              <span class="badge <?= $bandClass((string) ($candidate['riskLevel'] ?? '')) ?>"><?= e((string) ($candidate['riskLevel'] ?? 'UNKNOWN')) ?> risk</span>
                            </div>
                          </header>
                          <div class="table-scroll">
                            <table class="tbl football-odds-table football-odds-table--complete">
                              <thead><tr><th>Selection</th><th>WINDELS estimate</th><th>Bookmaker quote &amp; information</th><th>Margin-free market</th><th>Value &amp; edge</th></tr></thead>
                              <tbody>
                                <?php foreach ($outcomes as $outcome): ?>
                                  <?php
                                  $expected = $outcome['expectedValue'] ?? null;
                                  $valueClass = (string) ($outcome['valueClass'] ?? 'UNPRICED');
                                  $valueTone = in_array($valueClass, ['STRONG_VALUE', 'POSITIVE_VALUE'], true) ? 'b-green'
                                      : (in_array($valueClass, ['NEGATIVE_VALUE', 'AVOID'], true) ? 'b-red' : 'b-gray');
                                  $hasQuote = is_numeric($outcome['odds'] ?? null);
                                  ?>
                                  <tr>
                                    <td class="football-selection-cell"><b><?= e((string) ($outcome['label'] ?? $outcome['selection'] ?? '—')) ?></b><small class="mono"><?= e((string) ($outcome['selection'] ?? '')) ?></small><?php if (!empty($outcome['note'])): ?><small><?= e((string) $outcome['note']) ?></small><?php endif; ?></td>
                                    <td class="football-odds-metric"><b class="mono"><?= $pct($outcome['probability'] ?? null) ?></b><small>WINDELS probability</small><span class="mono">fair odds <?= $odds($outcome['windelsFairOdds'] ?? null) ?></span></td>
                                    <td class="football-quote football-odds-metric">
                                      <?php if ($hasQuote): ?>
                                        <b class="mono"><?= $odds($outcome['odds']) ?></b><small>Bookmaker odds · implied <?= $pct($outcome['impliedProbability'] ?? null) ?></small>
                                        <span><?= e((string) ($outcome['oddsSource'] ?? 'Source unavailable')) ?></span>
                                        <small><?= e($kickoff($outcome['oddsObservedAt'] ?? null, 'Y-m-d H:i')) ?></small>
                                        <small><?= max(1, (int) ($outcome['quoteCount'] ?? 1)) ?> quote<?= (int) ($outcome['quoteCount'] ?? 1) === 1 ? '' : 's' ?> · range <?= $odds($outcome['oddsLow'] ?? $outcome['odds']) ?>–<?= $odds($outcome['oddsHigh'] ?? $outcome['odds']) ?></small>
                                      <?php else: ?>
                                        <span class="badge b-gray">UNPRICED</span><small>No bookmaker quote stored</small>
                                      <?php endif; ?>
                                    </td>
                                    <td class="football-odds-metric">
                                      <?php if (is_numeric($outcome['fairProbability'] ?? null)): ?>
                                        <b class="mono"><?= $pct($outcome['fairProbability']) ?></b><small>fair probability after margin</small><span class="mono">market fair odds <?= $odds($outcome['fairOdds'] ?? null) ?></span>
                                      <?php else: ?>
                                        <b class="mono">—</b><small>Needs a complete price sheet</small><span>Break-even <?= $pct($outcome['breakEvenProbability'] ?? null) ?></span>
                                      <?php endif; ?>
                                    </td>
                                    <td class="football-value-cell">
                                      <span class="badge <?= $valueTone ?>"><?= e((string) ($outcome['valueLabel'] ?? 'No price to compare')) ?></span>
                                      <b class="mono <?= is_numeric($expected) && (float) $expected >= 0 ? 'up' : (is_numeric($expected) ? 'down' : 'dim') ?>">Expected return <?= $signedPct($expected) ?></b>
                                      <small class="mono">Edge vs quote <?= is_numeric($outcome['edgePoints'] ?? null) ? (((float) $outcome['edgePoints'] >= 0 ? '+' : '') . $dash($outcome['edgePoints'], 2) . 'pp') : '—' ?></small>
                                      <small class="mono">Edge after margin <?= is_numeric($outcome['edgeAgainstFairPoints'] ?? null) ? (((float) $outcome['edgeAgainstFairPoints'] >= 0 ? '+' : '') . $dash($outcome['edgeAgainstFairPoints'], 2) . 'pp') : '—' ?></small>
                                      <?php if (!empty($outcome['valueReason'])): ?><details class="football-value-explanation"><summary>Why this rating</summary><p><?= e((string) $outcome['valueReason']) ?></p></details><?php endif; ?>
                                    </td>
                                  </tr>
                                <?php endforeach; ?>
                              </tbody>
                            </table>
                          </div>
                          <footer>
                            <span>Coverage <?= $pct($candidate['coverage'] ?? null) ?> · <?= (int) ($pricing['legsPriced'] ?? 0) ?>/<?= (int) ($pricing['legsExpected'] ?? 0) ?> expected legs priced</span>
                            <span><?php if (is_numeric($pricing['overround'] ?? null)): ?>Overround <?= $pct($pricing['overround']) ?> · market margin <?= $dash($pricing['marginPoints'] ?? null, 2) ?>pp · <?= e((string) ($pricing['marginMethod'] ?? '')) ?><?php else: ?>Margin removal DATA_UNAVAILABLE<?php endif; ?><?php if (!empty($pricing['pricedAt'])): ?> · latest <?= e($kickoff($pricing['pricedAt'], 'Y-m-d H:i')) ?><?php endif; ?></span>
                          </footer>
                        </section>
                      <?php endforeach; ?>
                      <p class="football-odds-sheet__note">Bookmaker odds are provider quotes. WINDELS fair odds are 1 ÷ model probability; expected return is shown only where a model probability and a valid price can be compared. Market margin is calculated only for a complete mutually exclusive price sheet.</p>
                    </div>
                  </details>
                  <footer class="football-fixture__footer"><span>Match ID: <?= $rowPageId > 0 ? $rowPageId : '—' ?></span><span>Provider <b class="mono"><?= e((string) ($row['providerCode'] ?? '—')) ?></b></span><span>Latest odds <b class="mono"><?= e($kickoff($latestOddsAt, 'Y-m-d H:i')) ?></b></span><a href="/football/match/<?= $fixtureId ?>">Open full match analysis →</a></footer>
                </article>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if ($pagination !== []): ?><div class="football-section__divider"></div><?= $pager($pagination, (string) ($date ?? gmdate('Y-m-d')), $carry) ?><?php endif; ?>
        </div>
      </section>

    </div>

    <aside class="football-side stack" aria-label="Football performance and operational context">
      <section class="panel football-section football-performance-panel" id="football-performance" aria-labelledby="performance-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <div id="performance-heading">
              <p class="football-eyebrow">Measured results</p>
              <h3>30-day performance (settled predictions)</h3>
            </div>
          </div>
          <span class="football-section__meta">30 days</span>
        </div>
        <div class="body">
          <p class="football-section-intro">Measured from stored settlements only. Unsettled predictions are excluded, and unavailable measurements remain blank rather than being estimated.</p>
          <dl class="football-performance-list">
            <div><dt>Predictions evaluated</dt><dd class="mono"><?= $count($perf['evaluatedPredictions'] ?? null) ?></dd></div>
            <div><dt>Correct results</dt><dd class="mono"><?= $count($perf['correctResults'] ?? null) ?></dd></div>
            <div><dt>Result accuracy</dt><dd class="mono"><?= $pct($perf['resultAccuracy'] ?? null) ?></dd></div>
            <div><dt>Correct exact scores</dt><dd class="mono"><?= $count($perf['correctScores'] ?? null) ?></dd></div>
            <div><dt>Correct-score accuracy</dt><dd class="mono"><?= $pct($perf['exactScoreAccuracy'] ?? null, 2) ?></dd></div>
            <div><dt>Avg confidence</dt><dd class="mono"><?= $percentPoints($perf['averageConfidence'] ?? null) ?></dd></div>
            <div><dt>Brier score</dt><dd class="mono"><?= $dash($perf['brier'] ?? null, 4) ?></dd></div>
            <div><dt>Log loss</dt><dd class="mono"><?= $dash($perf['logLoss'] ?? null, 4) ?></dd></div>
            <div><dt>ECE</dt><dd class="mono"><?= $dash($perf['ece'] ?? null, 4) ?></dd></div>
            <div><dt>Avg data quality</dt><dd class="mono"><?= $qualityScore($perf['averageDataQuality'] ?? null) ?></dd></div>
            <div><dt>Avg goal error</dt><dd class="mono"><?= $goalError($perf['averageGoalError'] ?? null) ?></dd></div>
            <div><dt>Approved calibrations</dt><dd class="mono"><?= $count($models['approvedCalibrationCount'] ?? null) ?></dd></div>
          </dl>
          <?php if (($perf['state'] ?? '') !== 'MEASURED'): ?><p class="football-help"><?= e((string) ($perf['message'] ?? 'No settled predictions yet. Historical performance metrics will appear after predicted matches have completed.')) ?></p><?php endif; ?>
          <?php if (!empty($perf['note'])): ?><p class="football-help"><?= e((string) $perf['note']) ?></p><?php endif; ?>
        </div>
      </section>

      <section class="panel football-section football-reading-guide" aria-labelledby="football-guide-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <div>
              <p class="football-eyebrow">Reading the board</p>
              <h3 id="football-guide-heading">Keep the numbers separate</h3>
            </div>
          </div>
        </div>
        <div class="body">
          <p class="football-section-intro">Four values appear on every row. They answer different questions and are never blended into one number.</p>
          <dl>
            <div><dt>WINDELS probability</dt><dd>The model’s estimated chance from stored match data.</dd></div>
            <div><dt>Market odds</dt><dd>The decimal bookmaker price supplied by the provider.</dd></div>
            <div><dt>WINDELS fair odds</dt><dd>1 ÷ model probability. This is not a bookmaker offer.</dd></div>
            <div><dt>Potential edge</dt><dd>The model/price comparison, not a guarantee and not an instruction to bet. No selection is guaranteed.</dd></div>
          </dl>
        </div>
      </section>

      <section class="panel football-section" id="football-live-panel" aria-labelledby="live-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <div>
              <p class="football-eyebrow">Live now</p>
              <h3 id="live-heading">Live Match</h3>
            </div>
          </div>
        </div>
        <div class="body">
          <div class="football-livebar" aria-live="polite">
            <span class="dot synth" id="football-live-poll-dot" title="Auto-refresh status"></span>
            <span id="football-live-poll-note">Auto-refresh on — live match updates appear here automatically, immediately after the provider reports them.</span>
          </div>
          <?php // Only a fixture a provider is currently reporting in play belongs
          // here. The live board already withholds anything whose last live
          // confirmation aged out; this repeats the status test so a payload
          // built elsewhere can never put a finished match on the panel.
          $liveMatches = array_values(array_filter(is_array($live['matches'] ?? null) ? $live['matches'] : [], static function ($match): bool {
              $fixture = is_array($match['fixture'] ?? null) ? $match['fixture'] : [];
              return in_array(strtoupper((string) ($fixture['status'] ?? '')), \AIWorkforce\Football\FixtureSyncService::LIVE_STATUSES, true);
          })); ?>
          <div class="football-live-list" id="football-live-list">
            <?php if ($liveMatches === []): ?>
              <p class="football-help" id="football-live-empty">No match is currently live.</p>
            <?php else: ?>
              <?php foreach ($liveMatches as $liveMatch): ?>
                <?php $fx = is_array($liveMatch['fixture'] ?? null) ? $liveMatch['fixture'] : []; $liveState = is_array($liveMatch['live'] ?? null) ? $liveMatch['live'] : []; ?>
                <div data-football-live-id="<?= (int) ($fx['id'] ?? 0) ?>">
                  <b><?= crest($fx['homeTeamLogo'] ?? null) ?><?= e((string) ($fx['homeTeam'] ?? '—')) ?> <?= isset($liveState['score']['home']) && is_numeric($liveState['score']['home']) ? (int) $liveState['score']['home'] : '—' ?>–<?= isset($liveState['score']['away']) && is_numeric($liveState['score']['away']) ? (int) $liveState['score']['away'] : '—' ?> <?= crest($fx['awayTeamLogo'] ?? null) ?><?= e((string) ($fx['awayTeam'] ?? '—')) ?></b>
                  <span><?= e((string) ($fx['competition'] ?? '—')) ?> · <?= e((string) ($liveState['state'] ?? 'LIVE')) ?><?= isset($liveState['minute']) && is_numeric($liveState['minute']) ? ' · ' . (int) $liveState['minute'] . "'" : '' ?></span>
                  <span class="mono">Kickoff <?= e($kickoffStamp($fx['kickoff'] ?? null)) ?></span>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </section>

      <section class="panel football-section" aria-labelledby="feed-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <div>
              <p class="football-eyebrow">Data health</p>
              <h3 id="feed-heading">Data feed</h3>
            </div>
          </div>
        </div>
        <div class="body">
          <?php if (empty($diag['checks'])): ?><p class="football-help">Diagnostics are unavailable; the module could not read its own stored state.</p><?php else: ?>
            <div class="football-check-list">
              <?php foreach ($diag['checks'] as $check): ?><div><span class="dot <?= $stateClass((string) ($check['state'] ?? '')) ?>"></span><div><b><?= e((string) ($check['key'] ?? 'Check')) ?></b><small><?= e((string) ($check['detail'] ?? $check['value'] ?? '—')) ?></small></div></div><?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if (!empty($diag['blockers'])): ?><p class="football-help"><b>Blockers:</b> <?= e(implode(', ', (array) $diag['blockers'])) ?></p><?php endif; ?>
          <form method="post" action="/football/settle" class="football-inline-form">
            <input type="hidden" name="csrf_token" value="<?= e($csrfToken ?? '') ?>">
            <button class="btn small" type="submit" <?= empty($caps['settle']) ? 'title="Requires the sports.settle permission — click to see the access message"' : '' ?>>Run settlement sweep<?= empty($caps['settle']) ? ' (needs sports.settle)' : '' ?></button>
          </form>
        </div>
      </section>

      <section class="panel football-section" aria-labelledby="model-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <div>
              <p class="football-eyebrow">Governance</p>
              <h3 id="model-heading">Model &amp; calibration</h3>
            </div>
          </div>
        </div>
        <div class="body">
          <dl class="football-key-values">
            <div><dt>State</dt><dd><span class="dot <?= $stateClass((string) ($models['state'] ?? '')) ?>"></span> <?= e((string) ($models['label'] ?? 'No model loaded')) ?></dd></div>
            <div><dt>Active version</dt><dd class="mono"><?= e((string) ($models['activeModel']['version'] ?? '—')) ?></dd></div>
            <div><dt>Calibration</dt><dd class="mono"><?= e((string) ($models['calibration']['calibrationVersion'] ?? ($models['calibration']['status'] ?? 'CALIBRATION_PENDING'))) ?></dd></div>
          </dl>
          <?php if (!empty($models['reason'])): ?><p class="football-help"><?= e((string) $models['reason']) ?></p><?php endif; ?>
          <a class="btn small" href="/football/models">Open models &amp; calibration</a>
        </div>
      </section>

      <section class="panel football-section" aria-labelledby="schedule-heading">
        <div class="football-section__heading">
          <div class="football-section__title">
            <div>
              <p class="football-eyebrow">Automation</p>
              <h3 id="schedule-heading">Refresh schedule</h3>
            </div>
          </div>
        </div>
        <div class="body">
          <p class="football-help">Jobs are provider-aware and run only when due, data is available and the provider is not in backoff.</p>
          <div class="football-schedule-list">
            <?php foreach ((array) ($diag['cadence']['jobs'] ?? []) as $job): ?><div><span class="mono"><?= e(str_replace('football-', '', (string) ($job['job'] ?? 'job'))) ?></span><span><?= !empty($job['due']) ? '<b class="up">Due</b>' : e((string) ($job['reason'] ?? 'Waiting')) ?></span><small><?= (int) ($job['interval'] ?? 0) ?>s</small></div><?php endforeach; ?>
          </div>
        </div>
      </section>
    </aside>
  </div>
</div>

<script id="football-live-js">
(function(){
  // The browser reads the stored live board frequently; the provider-aware
  // football-live scheduler owns the rate-limited provider sweep. This keeps
  // every viewer current without turning each open page into provider traffic.
  var list = document.getElementById('football-live-list');
  if(!list) return;
  var dot = document.getElementById('football-live-poll-dot');
  var note = document.getElementById('football-live-poll-note');
  var timer = null;
  var inFlight = null;
  var snapshots = {};
  // The stored live board is a local read, so polling it often is cheap and is
  // what makes an update appear as soon as the provider sweep has written it.
  // The rate-limited provider call stays with the football-live scheduler.
  var pollEveryMs = 5000;
  // After a change the match is moving: look again sooner so the next goal or
  // minute lands quickly, then settle back to the idle cadence.
  var activeMs = 3000;
  var backoffMs = pollEveryMs;
  var maxBackoffMs = 60000;
  var ready = false;
  var liveMessage = 'Auto-refresh on — live match updates appear here automatically, immediately after the provider reports them.';

  function esc(value){
    return String(value == null ? '' : value).replace(/[&<>"']/g, function(character){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character];
    });
  }

  function numberOrDash(value){
    return value !== null && value !== '' && isFinite(Number(value)) ? String(Math.trunc(Number(value))) : '—';
  }

  function kickoffStamp(value){
    var timestamp = value ? Date.parse(value) : NaN;
    if(isNaN(timestamp)) return 'DATA_UNAVAILABLE';
    var date = new Date(timestamp);
    var days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var pad = function(number){ return String(number).padStart(2, '0'); };
    return days[date.getUTCDay()] + ' ' + date.getUTCDate() + ' ' + months[date.getUTCMonth()] + ' ' + date.getUTCFullYear()
      + ' · ' + pad(date.getUTCHours()) + ':' + pad(date.getUTCMinutes()) + ' UTC';
  }

  function crest(url){
    return url ? '<img class="football-live-crest" src="' + esc(url) + '" alt="" width="18" height="18" loading="lazy">' : '';
  }

  function isLiveMatch(match){
    var fixture = match.fixture || {};
    var live = match.live || {};
    var status = String(fixture.status || '').toUpperCase();
    var state = String(live.state || '').toUpperCase();
    return ['LIVE','HALFTIME','EXTRA_TIME','PENALTIES'].indexOf(status) >= 0
      || ['IN_PLAY','LIVE','HALFTIME','EXTRA_TIME','PENALTIES','LIMITED_DATA'].indexOf(state) >= 0;
  }

  function snapshot(match){
    var fixture = match.fixture || {};
    var state = match.live || {};
    var score = state.score || {};
    return [numberOrDash(score.home), numberOrDash(score.away), numberOrDash(state.minute), state.state || '',
      fixture.homeTeam || '', fixture.awayTeam || '', fixture.competition || '', fixture.kickoff || ''].join('|');
  }

  function cardInner(match){
    var fixture = match.fixture || {};
    var state = match.live || {};
    var score = state.score || {};
    var minute = state.minute !== null && state.minute !== undefined && isFinite(Number(state.minute))
      ? ' · ' + Math.trunc(Number(state.minute)) + "'" : '';
    return '<b>' + crest(fixture.homeTeamLogo) + esc(fixture.homeTeam || '—') + ' '
      + numberOrDash(score.home) + '–' + numberOrDash(score.away) + ' '
      + crest(fixture.awayTeamLogo) + esc(fixture.awayTeam || '—') + '</b>'
      + '<span>' + esc(fixture.competition || '—') + ' · ' + esc(state.state || 'LIVE') + minute + '</span>'
      + '<span class="mono">Kickoff ' + esc(kickoffStamp(fixture.kickoff)) + '</span>';
  }

  function emptyCard(){
    var empty = document.createElement('p');
    empty.className = 'football-help';
    empty.id = 'football-live-empty';
    empty.textContent = 'No match is currently live.';
    return empty;
  }

  /**
   * Reconcile the list against the matches the provider is reporting NOW.
   *
   * The list is keyed by fixture id and rebuilt by moving, updating and
   * REMOVING nodes rather than being reprinted wholesale: a match the payload
   * no longer contains is deleted from the DOM in the same pass that updates
   * the ones still live. That removal is the point — the panel is a mirror of
   * the current live set, never an accumulation of everything once seen.
   */
  function render(matches){
    var next = {};
    var changed = 0;
    var existing = {};
    Array.prototype.forEach.call(list.querySelectorAll('[data-football-live-id]'), function(node){
      existing[node.getAttribute('data-football-live-id')] = node;
    });

    matches.forEach(function(match){
      var id = String((match.fixture || {}).id || 0);
      next[id] = snapshot(match);
      if(ready && snapshots[id] !== next[id]) changed++;
    });
    // Anything that was on the panel and is not in this payload has left the
    // live set: count it as a change so the status line reports the takedown.
    Object.keys(snapshots).forEach(function(id){
      if(ready && next[id] === undefined) changed++;
    });

    var emptyNote = document.getElementById('football-live-empty');
    if(!matches.length){
      // Every stale card goes, including when the answer is "none live".
      Object.keys(existing).forEach(function(id){ existing[id].remove(); });
      if(!emptyNote) list.appendChild(emptyCard());
      snapshots = next;
      ready = true;
      return changed;
    }
    if(emptyNote) emptyNote.remove();

    var previous = null;
    matches.forEach(function(match){
      var id = String((match.fixture || {}).id || 0);
      var node = existing[id];
      if(node){
        // Repaint only when this match actually changed, so a card that is
        // merely still live does not flash on every poll.
        if(snapshots[id] !== next[id]){
          node.innerHTML = cardInner(match);
          node.classList.remove('football-live-updated');
          void node.offsetWidth;                 // restart the highlight
          node.classList.add('football-live-updated');
        }
        delete existing[id];
      } else {
        node = document.createElement('div');
        node.setAttribute('data-football-live-id', id);
        node.innerHTML = cardInner(match);
        if(ready) node.classList.add('football-live-updated');
      }
      // Keep the provider's ordering without rebuilding untouched nodes.
      var shouldBe = previous ? previous.nextSibling : list.firstChild;
      if(node !== shouldBe) list.insertBefore(node, shouldBe);
      previous = node;
    });
    // Whatever is still in `existing` was not reported live in this payload.
    Object.keys(existing).forEach(function(id){ existing[id].remove(); });

    snapshots = next;
    ready = true;
    return changed;
  }

  function setStatus(message, state){
    if(note) note.textContent = message;
    if(dot) dot.className = 'dot ' + state;
  }

  function schedule(delay){
    clearTimeout(timer);
    timer = setTimeout(poll, delay);
  }

  function poll(){
    // A hidden tab is not watching: skip the read rather than queue work, and
    // refresh the moment it comes back (see visibilitychange below).
    if(document.hidden){ schedule(pollEveryMs); return; }
    if(inFlight) return;
    inFlight = true;
    // Add a cache key as a second line of defence for shared hosts whose proxy
    // ignores Fetch's cache mode or the response headers. The endpoint still
    // performs the provider-aware cadence gate; this only guarantees that the
    // browser asks for the current stored board.
    fetch('/api/football/fixtures/live' + '?poll=' + encodeURIComponent(Date.now()), {credentials: 'same-origin', cache: 'no-store', headers: {'Accept': 'application/json', 'Cache-Control': 'no-cache'}})
      .then(function(response){
        if(!response.ok) throw new Error('HTTP ' + response.status);
        return response.json();
      })
      .then(function(data){
        var matches = Array.isArray(data.matches) ? data.matches.filter(isLiveMatch) : [];
        var changed = render(matches);
        backoffMs = pollEveryMs;
        var provider = data.provider || {};
        var sweep = data.sweep || {};
        if(sweep.reason === 'PROVIDER_NOT_CONFIGURED' || sweep.reason === 'MODULE_DISABLED'){
          // Nothing is fetching and nothing can: say which, rather than leaving
          // an empty panel implying no football is being played anywhere.
          setStatus(sweep.reason === 'MODULE_DISABLED'
            ? 'Live updates are off — the football module is disabled.'
            : 'Live updates are unavailable — no football data provider is connected.', 'down');
        } else if(provider.state === 'BEHIND' || provider.state === 'NEVER_RUN'){
          // The rows are current as stored, but the sweep that writes them is
          // not running. Saying "nothing is live" here would be a guess, so the
          // panel reports the feed state instead of implying an empty schedule.
          setStatus('Live feed is behind — the provider sweep has not reported recently. Showing the last confirmed live matches only.', 'down');
        } else if(!matches.length){
          setStatus('Auto-refresh on — no match is currently live. New matches appear here as soon as the provider reports them.', 'synth');
        } else {
          setStatus(liveMessage + (changed ? ' Updated just now.' : ''), 'up');
        }
        // Follow a moving match closely; idle back when nothing changed.
        schedule(changed ? activeMs : pollEveryMs);
      })
      .catch(function(error){
        var message = String(error && error.message || '');
        if(message.indexOf('403') >= 0){
          // A permission problem will not fix itself on the next tick.
          setStatus('Live auto-refresh needs the sports.view permission.', 'down');
          clearTimeout(timer);
          return;
        }
        if(message.indexOf('401') >= 0){
          setStatus('Live auto-refresh stopped — the session ended. Reload the page to sign in again.', 'down');
          clearTimeout(timer);
          return;
        }
        // Transient failure: keep the cards that are on screen, say so, and
        // back off so a struggling server is not hammered by every open tab.
        backoffMs = Math.min(maxBackoffMs, Math.max(pollEveryMs, backoffMs * 2));
        setStatus('Auto-refresh interrupted — retrying in ' + Math.round(backoffMs / 1000) + 's.', 'down');
        schedule(backoffMs);
      })
      .then(function(){ inFlight = false; }, function(){ inFlight = false; });
  }

  document.addEventListener('visibilitychange', function(){
    if(!document.hidden){ clearTimeout(timer); poll(); }
  });
  setStatus(liveMessage, 'synth');
  poll();
})();
</script>

<script id="football-search-js">
(function(){
  // Team / competition finder over the fixtures ALREADY rendered on this page.
  // A pure client-side view: no request is made, no prediction is generated,
  // and clearing the box restores every row exactly as the server sent it.
  // The control is hidden until this script runs, so a no-JS visitor never
  // sees a dead input.
  var wrap = document.getElementById('football-fixture-search');
  var input = document.getElementById('football-team-search');
  var board = document.getElementById('football-fixture-board');
  var count = document.getElementById('football-search-count');
  if(!wrap || !input || !board) return;
  wrap.hidden = false;
  var cards = Array.prototype.slice.call(board.querySelectorAll('.football-fixture'));
  var total = cards.length;
  var haystacks = cards.map(function(card){
    var identity = card.querySelector('.football-fixture__identity');
    return (identity ? identity.textContent : card.textContent).toLowerCase();
  });
  function apply(){
    var needle = input.value.trim().toLowerCase();
    var shown = 0;
    cards.forEach(function(card, index){
      var hit = needle === '' || haystacks[index].indexOf(needle) >= 0;
      card.classList.toggle('is-filtered-out', !hit);
      if(hit) shown++;
    });
    if(count) count.textContent = needle === ''
      ? total + ' of ' + total + ' shown'
      : shown + ' of ' + total + ' match' + (shown === 1 ? '' : 'es') + ' "' + input.value.trim() + '" on this page';
  }
  input.addEventListener('input', apply);
  input.addEventListener('search', apply);
})();
</script>
