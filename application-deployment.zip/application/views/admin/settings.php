<?php defined('BASEPATH') or exit('No direct script access allowed');
$set = $settings ?? [];
$general = $set['general'] ?? [];
$ai = $set['ai'] ?? [];
$football = $set['football'] ?? [];
$footballMode = strtoupper(trim((string) ($football['football_provider_mode'] ?? 'AUTO'))) === 'MANUAL' ? 'MANUAL' : 'AUTO';
$footballManual = (string) ($football['football_manual_provider'] ?? '');
// This value is independently bounded in the admin write path and in the
// prediction services; normalizing here only keeps a malformed stored value
// from being presented as a valid setting.
$footballBatchSize = max(1, min(50, (int) ($football['football_analysis_batch_size'] ?? 50)));
$security = $set['security'] ?? [];
$accounts = $set['accounts'] ?? [];
$seo = $set['seo'] ?? [];
$ann = $set['announcement'] ?? [];
$smtp = $smtp ?? [];
$signupSet = $set['signup'] ?? [];
$signup = is_array($signup ?? null) ? $signup : [];
$signupWarnings = is_array($signupWarnings ?? null) ? $signupWarnings : [];
?>
<div class="page-head">
  <div>
    <p class="eyebrow">Administration</p>
    <h2>System Settings</h2>
    <p>Settings are grouped by category. SMTP passwords and API keys stay in the server environment and are never shown here.</p>
  </div>
</div>

<section class="panel" id="general">
  <h3>General</h3>
  <div class="body">
    <form method="post" action="/admin/settings/save" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="general">
      <label>Product name<input name="product_name" maxlength="120" value="<?= e($general['product_name'] ?? 'WINDELS AI WORKFORCE') ?>"></label>
      <label>Contact name<input name="contact_name" maxlength="120" value="<?= e($general['contact_name'] ?? '') ?>"></label>
      <label>Contact email<input type="email" name="contact_email" maxlength="190" value="<?= e($general['contact_email'] ?? '') ?>"></label>
      <button class="btn primary" type="submit">Save general</button>
    </form>
  </div>
</section>

<section class="panel" id="ai" style="margin-top:14px">
  <h3>AI</h3>
  <div class="body">
    <p class="dim">Feature flags stored for operators. They do not invent usage numbers.</p>
    <form method="post" action="/admin/settings/save" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="ai">
      <label class="choice"><input type="checkbox" name="ai_analysis_enabled" value="1" <?= ($ai['ai_analysis_enabled'] ?? '1') === '1' ? 'checked' : '' ?>> AI analysis marked available</label>
      <label class="choice"><input type="checkbox" name="language_learning_enabled" value="1" <?= ($ai['language_learning_enabled'] ?? '1') === '1' ? 'checked' : '' ?>> Language learning marked available</label>
      <button class="btn primary" type="submit">Save AI flags</button>
    </form>
  </div>
</section>

<section class="panel" id="football" style="margin-top:14px">
  <h3>Football Data Provider</h3>
  <div class="body">
    <p class="dim">Controls the <span class="mono">Data Provider</span> selector on the <a href="/football">/football</a> console and the matching API parameters. The switch takes effect on the next request — no deploy needed.</p>
    <div class="stat-grid" style="margin:10px 0">
      <div class="stat"><div class="k">Current mode</div><div class="v"><span class="badge <?= $footballMode === 'AUTO' ? 'b-green' : 'b-amber' ?>"><?= e($footballMode) ?></span></div><div class="trend" style="font-size:11px"><?= $footballMode === 'AUTO' ? 'locked to Auto / Smart' : 'operator may choose the feed' ?></div></div>
      <div class="stat"><div class="k">Manual default</div><div class="v" style="font-size:13px"><?= $footballManual === '' ? 'Auto / Smart' : e($footballManual) ?></div><div class="trend" style="font-size:11px">pre-selection when MANUAL</div></div>
      <div class="stat"><div class="k">Prediction batch</div><div class="v"><?= (int) $footballBatchSize ?></div><div class="trend" style="font-size:11px">maximum stored fixtures per analysis cycle (1–50)</div></div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
      <form method="post" action="/admin/settings/football-toggle" style="display:inline">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
        <input type="hidden" name="mode" value="AUTO">
        <button class="btn <?= $footballMode === 'AUTO' ? 'primary' : '' ?>" type="submit" <?= $footballMode === 'AUTO' ? 'disabled title="Already in Auto mode"' : '' ?>>⚙️ Auto (default)</button>
      </form>
      <form method="post" action="/admin/settings/football-toggle" style="display:inline">
        <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
        <input type="hidden" name="mode" value="MANUAL">
        <button class="btn <?= $footballMode === 'MANUAL' ? 'primary' : '' ?>" type="submit" <?= $footballMode === 'MANUAL' ? 'disabled title="Already in Manual mode"' : '' ?>>✋ Manual</button>
      </form>
    </div>
    <form method="post" action="/admin/settings/save" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="football">
      <label>Mode<select name="football_provider_mode">
        <option value="AUTO" <?= $footballMode === 'AUTO' ? 'selected' : '' ?>>AUTO — lock /football to Auto / Smart (default)</option>
        <option value="MANUAL" <?= $footballMode === 'MANUAL' ? 'selected' : '' ?>>MANUAL — operators can choose the feed</option>
      </select></label>
      <label>Default provider when MANUAL (pre-selected in the dropdown)<select name="football_manual_provider">
        <?php foreach (['' => 'Auto / Smart', 'MULTI' => 'Multi-Provider', 'api-football' => 'API-Football', 'thesportsdb' => 'TheSportsDB', 'sportmonks' => 'SportMonks', 'http-provider' => 'HTTP-Provider'] as $pv => $pl): ?>
        <option value="<?= e($pv) ?>" <?= $footballManual === $pv ? 'selected' : '' ?>><?= e($pl) ?></option>
        <?php endforeach; ?>
      </select></label>
      <label>Prediction analysis batch size
        <input type="number" name="football_analysis_batch_size" min="1" max="50" step="1" list="football-batch-sizes" value="<?= (int) $footballBatchSize ?>" required>
        <small class="dim">Maximum stored fixtures evaluated in one cycle. Use 10, 20, 50, or another whole number from 1–50. Fewer fixtures with sufficient provider data produce fewer predictions; the system never fills a batch with synthetic matches.</small>
      </label>
      <datalist id="football-batch-sizes"><option value="10"><option value="20"><option value="50"></datalist>
      <button class="btn primary" type="submit">Save football settings</button>
    </form>
  </div>
</section>

<section class="panel" id="email" style="margin-top:14px">
  <h3>Email</h3>
  <div class="body">
    <p class="dim">Outbound mail is configured on the server only. Credentials are never stored in this form or returned to the browser.</p>
    <div class="stat-grid" style="margin:10px 0">
      <div class="stat"><div class="k">Status</div><div class="v"><span class="badge <?= !empty($smtp['enabled']) ? 'b-green' : 'b-gray' ?>"><?= !empty($smtp['enabled']) ? 'ENABLED' : 'DISABLED' ?></span></div></div>
      <div class="stat"><div class="k">Host</div><div class="v" style="font-size:13px"><?= e($smtp['host'] ?? '—') ?></div></div>
      <div class="stat"><div class="k">Port / TLS</div><div class="v" style="font-size:13px"><?= e((string) ($smtp['port'] ?? '—')) ?> · <?= e(strtoupper((string) ($smtp['crypto'] ?? '')) ?: '—') ?></div></div>
      <div class="stat"><div class="k">Auth</div><div class="v"><span class="badge <?= !empty($smtp['usernameConfigured']) && !empty($smtp['passwordConfigured']) ? 'b-green' : 'b-gray' ?>"><?= (!empty($smtp['usernameConfigured']) && !empty($smtp['passwordConfigured'])) ? 'READY' : 'MISSING' ?></span></div></div>
    </div>
    <?php if (!empty($smtpOk)): ?><div class="notice ok"><?= e($smtpOk) ?></div><?php endif; ?>
    <?php if (!empty($smtpError)): ?><div class="notice err"><?= e($smtpError) ?></div><?php endif; ?>
    <form method="post" action="/admin/test-email" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <label>Send a test email to<input type="email" name="to" required placeholder="you@example.com"></label>
      <label>Format<select name="variant"><option value="html">HTML</option><option value="plain">Plain text</option></select></label>
      <button class="btn primary" type="submit">Send test email</button>
    </form>
  </div>
</section>

<section class="panel" id="security" style="margin-top:14px">
  <h3>Security</h3>
  <div class="body">
    <form method="post" action="/admin/settings/save" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="security">
      <label>Failed login attempts before lockout<input type="number" name="login_max_attempts" min="3" max="20" value="<?= e($security['login_max_attempts'] ?? '5') ?>"></label>
      <label>Lockout duration (seconds)<input type="number" name="login_lockout_seconds" min="60" max="86400" value="<?= e($security['login_lockout_seconds'] ?? '900') ?>"></label>
      <button class="btn primary" type="submit">Save security</button>
    </form>
    <p class="dim" style="margin-top:12px">Session cookie: <?= (int) ($session['expiration'] ?? 0) ?>s · HttpOnly <?= !empty($session['httponly']) ? 'on' : 'off' ?> · SameSite <?= e($session['samesite'] ?? '') ?> · Secure <?= !empty($session['secure']) ? 'on' : 'off' ?>. Those values come from server configuration and are not edited here.</p>
  </div>
</section>

<section class="panel" id="accounts" style="margin-top:14px">
  <h3>User Accounts</h3>
  <div class="body">
    <form method="post" action="/admin/settings/save" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="accounts">
      <label class="choice"><input type="checkbox" name="registration_enabled" value="1" <?= ($accounts['registration_enabled'] ?? '1') === '1' ? 'checked' : '' ?>> Allow public registration</label>
      <button class="btn primary" type="submit">Save account settings</button>
    </form>
  </div>
</section>

<section class="panel" id="signup" style="margin-top:14px">
  <h3>Sign-up Protection</h3>
  <div class="body">
    <p class="dim">Email validation and reCAPTCHA for the public <span class="mono">/register</span> page. Both checks are enforced on the server; the browser widget is only a convenience. The reCAPTCHA secret is encrypted before it is stored and is never shown again here.</p>
    <div class="stat-grid" style="margin:10px 0">
      <div class="stat"><div class="k">reCAPTCHA</div><div class="v"><span class="badge <?= ($signup['captchaState'] ?? 'OFF') === 'ACTIVE' ? 'b-green' : (($signup['captchaState'] ?? 'OFF') === 'MISCONFIGURED' ? 'b-red' : 'b-gray') ?>"><?= e((string) ($signup['captchaState'] ?? 'OFF')) ?></span></div><div class="trend" style="font-size:11px"><?= e((string) ($signup['captchaLabel'] ?? 'Off')) ?></div></div>
      <div class="stat"><div class="k">Site key</div><div class="v"><span class="badge <?= !empty($signup['siteKeyConfigured']) ? 'b-green' : 'b-gray' ?>"><?= !empty($signup['siteKeyConfigured']) ? 'SET' : 'MISSING' ?></span></div></div>
      <div class="stat"><div class="k">Secret key</div><div class="v"><span class="badge <?= !empty($signup['secretConfigured']) ? 'b-green' : 'b-gray' ?>"><?= !empty($signup['secretConfigured']) ? 'SET' : 'MISSING' ?></span></div><div class="trend" style="font-size:11px"><?= !empty($signup['keysFromEnv']) ? 'from server environment' : 'stored encrypted' ?></div></div>
      <div class="stat"><div class="k">Email check</div><div class="v" style="font-size:13px"><?= ($signup['emailMode'] ?? 'mx') === 'mx' ? 'Syntax + domain (MX)' : 'Syntax only' ?></div><div class="trend" style="font-size:11px"><?= !empty($signup['blockDisposable']) ? 'disposable inboxes blocked' : 'disposable inboxes allowed' ?> · <?= (int) ($signup['blockedDomains'] ?? 0) ?> blocked · <?= (int) ($signup['allowedDomains'] ?? 0) ?> allowed</div></div>
    </div>
    <?php if (!empty($signup['signupBlocked'])): ?><div class="notice err"><b>Sign-up is currently blocked.</b> reCAPTCHA is switched on but a key is missing — visitors see "Registration is temporarily unavailable" until both keys are set (or reCAPTCHA is switched off).</div><?php endif; ?>
    <?php foreach ($signupWarnings as $w): ?><div class="notice warnbox"><?= e((string) $w) ?></div><?php endforeach; ?>
    <form method="post" action="/admin/settings/save" class="admin-form" autocomplete="off">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="signup">
      <h4 style="margin:12px 0 4px">Email validation</h4>
      <label>Validation level<select name="email_validation_mode">
        <option value="mx" <?= ($signupSet['email_validation_mode'] ?? 'mx') === 'mx' ? 'selected' : '' ?>>Syntax + domain must accept mail (MX / A record lookup) — recommended</option>
        <option value="syntax" <?= ($signupSet['email_validation_mode'] ?? 'mx') === 'syntax' ? 'selected' : '' ?>>Syntax only (no DNS lookup)</option>
      </select></label>
      <label class="choice"><input type="checkbox" name="email_block_disposable" value="1" <?= ($signupSet['email_block_disposable'] ?? '1') === '1' ? 'checked' : '' ?>> Block temporary / disposable email providers (built-in list of <?= count(\AIWorkforce\SignupProtection::DISPOSABLE_DOMAINS) ?> domains)</label>
      <label>Additional blocked domains (one per line)<textarea name="email_blocked_domains" rows="3" maxlength="2000" placeholder="spam-domain.example&#10;another.example"><?= e((string) ($signupSet['email_blocked_domains'] ?? '')) ?></textarea></label>
      <label>Allowed domains only — leave blank to accept any domain (one per line)<textarea name="email_allowed_domains" rows="2" maxlength="2000" placeholder="yourcompany.com"><?= e((string) ($signupSet['email_allowed_domains'] ?? '')) ?></textarea></label>

      <h4 style="margin:16px 0 4px">reCAPTCHA</h4>
      <p class="dim" style="margin:0 0 6px">Create keys at <span class="mono">google.com/recaptcha/admin</span> for this domain. v2 shows the "I'm not a robot" checkbox; v3 is invisible and scores each request. Server variables <span class="mono">VP_RECAPTCHA_SITE_KEY</span> / <span class="mono">VP_RECAPTCHA_SECRET</span> override the values stored here.</p>
      <label>Provider<select name="captcha_provider">
        <?php foreach (\AIWorkforce\SignupProtection::PROVIDERS as $pv): ?>
        <option value="<?= e($pv) ?>" <?= ($signupSet['captcha_provider'] ?? 'off') === $pv ? 'selected' : '' ?>><?= e(\AIWorkforce\SignupProtection::providerLabel($pv)) ?></option>
        <?php endforeach; ?>
      </select></label>
      <label>Site key (public)<input name="captcha_site_key" maxlength="200" autocomplete="off" spellcheck="false" placeholder="6Lc…" value="<?= e((string) ($signupSet['captcha_site_key'] ?? '')) ?>"></label>
      <label>Secret key<input type="password" name="captcha_secret" maxlength="200" autocomplete="new-password" placeholder="<?= !empty($signup['secretConfigured']) ? 'Stored — leave blank to keep, type a new one to rotate' : 'Paste the secret key' ?>"></label>
      <label class="choice"><input type="checkbox" name="captcha_secret_clear" value="1"> Remove the stored secret key</label>
      <label>Minimum score (v3 only, 0.1 = lenient · 0.9 = strict)<input type="number" name="captcha_min_score" min="0.1" max="0.9" step="0.1" value="<?= e((string) ($signupSet['captcha_min_score'] ?? '0.5')) ?>"></label>
      <button class="btn primary" type="submit">Save sign-up protection</button>
    </form>
  </div>
</section>

<section class="panel" id="seo" style="margin-top:14px">
  <h3>SEO</h3>
  <div class="body">
    <p class="dim">Public-site search settings. Any field left blank falls back to the server default (config/env). These drive the page titles, meta tags, robots.txt and sitemap.xml.</p>
    <form method="post" action="/admin/settings/save" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="seo">
      <label>Site name<input name="seo_site_name" maxlength="120" placeholder="WINDELS AI WORKFORCE" value="<?= e($seo['seo_site_name'] ?? '') ?>"></label>
      <label>Title suffix (appended to every page title)<input name="seo_title_suffix" maxlength="120" placeholder=" · WINDELS AI WORKFORCE" value="<?= e($seo['seo_title_suffix'] ?? '') ?>"></label>
      <label>Meta description<input name="seo_description" maxlength="500" placeholder="Shown on search result pages (about 150 characters)" value="<?= e($seo['seo_description'] ?? '') ?>"></label>
      <label>Meta keywords (comma separated)<input name="seo_keywords" maxlength="500" placeholder="Leave blank to use the server default" value="<?= e($seo['seo_keywords'] ?? '') ?>"></label>
      <label>Crawl directive<select name="seo_robots">
        <option value="">Server default</option>
        <?php foreach (['index,follow' => 'index,follow — index everything', 'noindex,follow' => 'noindex,follow — hide from search, follow links', 'index,nofollow' => 'index,nofollow — index, ignore links', 'noindex,nofollow' => 'noindex,nofollow — hide completely'] as $v => $label): ?>
        <option value="<?= e($v) ?>" <?= ($seo['seo_robots'] ?? '') === $v ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select></label>
      <label>Canonical base URL (also used for sitemap.xml)<input name="seo_canonical" maxlength="190" placeholder="https://example.com/" value="<?= e($seo['seo_canonical'] ?? '') ?>"></label>
      <label>Social share image URL (og:image)<input name="seo_og_image" maxlength="500" placeholder="https://example.com/assets/images/share.png" value="<?= e($seo['seo_og_image'] ?? '') ?>"></label>
      <label>Browser theme color<input name="seo_theme_color" maxlength="20" placeholder="#07090e" value="<?= e($seo['seo_theme_color'] ?? '') ?>"></label>
      <button class="btn primary" type="submit">Save SEO</button>
    </form>
  </div>
</section>

<section class="panel" id="announcement" style="margin-top:14px">
  <h3>Announcement Bar</h3>
  <div class="body">
    <p class="dim">The scrolling message bar at the top of every page. One message per line; blank lines are ignored. Switch the bar off — or clear every line — to show nothing.</p>
    <form method="post" action="/admin/settings/save" class="admin-form">
      <input type="hidden" name="csrf_token" value="<?= e($csrfToken) ?>">
      <input type="hidden" name="category" value="announcement">
      <label class="choice"><input type="checkbox" name="announcement_enabled" value="1" <?= ($ann['announcement_enabled'] ?? '1') === '1' ? 'checked' : '' ?>> Show the announcement bar</label>
      <label>Messages (one per line)<textarea name="announcement_messages" rows="4" maxlength="2000" placeholder="Welcome to WINDELS AI WORKFORCE — your AI-powered workforce platform."><?= e($ann['announcement_messages'] ?? '') ?></textarea></label>
      <button class="btn primary" type="submit">Save announcement</button>
    </form>
  </div>
</section>
